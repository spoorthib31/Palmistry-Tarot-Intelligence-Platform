import React, { useState, useEffect } from 'react';
import { 
  Compass, Download, Sparkles, RefreshCw, Sun, Moon, 
  Flame, Gem, CheckCircle2, FileText, ChevronRight
} from 'lucide-react';
import { apiService } from '../services/api';
import { SynthesisResult, PalmFeatures, TarotSpreadResult } from '../types';
import { ScoreRadar } from '../components/ScoreRadar';
import { cosmicAudio } from '../services/audioSynthesizer';

interface SpiritualBlueprintProps {
  palmFeatures?: PalmFeatures | null;
  tarotSpread?: TarotSpreadResult | null;
  onNavigateToPalm: () => void;
  onNavigateToTarot: () => void;
}

export const SpiritualBlueprint: React.FC<SpiritualBlueprintProps> = ({
  palmFeatures,
  tarotSpread,
  onNavigateToPalm,
  onNavigateToTarot
}) => {
  const [zodiacSign, setZodiacSign] = useState<string>('Scorpio');
  const [lifePathNumber, setLifePathNumber] = useState<number>(7);
  const [question, setQuestion] = useState<string>('What is my spiritual destiny and how can I align my higher timeline?');
  const [result, setResult] = useState<SynthesisResult | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const zodiacSigns = [
    "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
    "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"
  ];

  const handleGenerate = async () => {
    setLoading(true);
    cosmicAudio.playTibetanChime();
    try {
      const res = await apiService.generateSynthesis({
        palm_features: palmFeatures,
        tarot_spread: tarotSpread,
        zodiac_sign: zodiacSign,
        life_path_number: lifePathNumber,
        spiritual_question: question
      });
      setResult(res);
    } catch (err: any) {
      alert(err.message || "Synthesis generation failed.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Auto-generate if either palm or tarot is already loaded
    if (!result) {
      handleGenerate();
    }
  }, []);

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-950/60 border border-indigo-500/30 text-xs font-serif text-indigo-300 shadow-cosmic-glow">
          <Compass className="w-3.5 h-3.5" />
          <span>Multi-Modal Spiritual Synthesis Engine</span>
        </div>
        <h2 className="font-serif text-3xl sm:text-4xl font-bold text-slate-100">
          Cosmic Blueprint & Spiritual Dossier
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto">
          Unifying physical chiromancy, archetypal tarot wisdom, western astrology, and Pythagorean numerology into your sovereign spiritual roadmap.
        </p>
      </div>

      {/* Input / Modifiers Bar */}
      <div className="glass-panel rounded-3xl p-6 border border-purple-500/30 space-y-4 shadow-cosmic-glow">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          
          {/* Zodiac Selector */}
          <div>
            <label className="text-xs font-serif font-bold text-amber-300 block mb-1">
              Sun Zodiac Sign
            </label>
            <select
              value={zodiacSign}
              onChange={(e) => setZodiacSign(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-cosmic-950 border border-purple-500/30 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
            >
              {zodiacSigns.map((z) => (
                <option key={z} value={z}>{z}</option>
              ))}
            </select>
          </div>

          {/* Life Path Number */}
          <div>
            <label className="text-xs font-serif font-bold text-amber-300 block mb-1">
              Numerology Life Path
            </label>
            <select
              value={lifePathNumber}
              onChange={(e) => setLifePathNumber(parseInt(e.target.value))}
              className="w-full px-3 py-2 rounded-xl bg-cosmic-950 border border-purple-500/30 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 22].map((num) => (
                <option key={num} value={num}>Number {num} {num === 7 ? '(The Mystic Seeker)' : num === 11 ? '(Master Intuitive)' : ''}</option>
              ))}
            </select>
          </div>

          {/* Re-Synthesize Button */}
          <div className="flex items-end">
            <button
              onClick={handleGenerate}
              disabled={loading}
              className="w-full py-2.5 rounded-xl font-serif font-bold text-xs gold-gradient-btn text-cosmic-950 flex items-center justify-center gap-2 shadow-gold-glow disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>{loading ? 'Re-Synthesizing...' : 'Update Blueprint'}</span>
            </button>
          </div>

        </div>

        {/* Status of Linked Multi-Modal Feeds */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-purple-500/20 text-xs">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${palmFeatures ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
              <span className="text-slate-300">
                Palm Chiromancy: <strong className="text-purple-300">{palmFeatures ? `${palmFeatures.hand_type} Hand Loaded` : 'Sample Active'}</strong>
              </span>
              {!palmFeatures && (
                <button onClick={onNavigateToPalm} className="text-amber-400 hover:underline text-[11px]">
                  (Scan Real Hand)
                </button>
              )}
            </div>

            <div className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${tarotSpread ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
              <span className="text-slate-300">
                Tarot Spread: <strong className="text-purple-300">{tarotSpread ? `${tarotSpread.drawn_cards.length} Cards Loaded` : 'Trinity Active'}</strong>
              </span>
              {!tarotSpread && (
                <button onClick={onNavigateToTarot} className="text-amber-400 hover:underline text-[11px]">
                  (Draw Spread)
                </button>
              )}
            </div>
          </div>

          {result?.pdf_download_url && (
            <a
              href={result.pdf_download_url}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-900/60 border border-purple-400/40 text-amber-300 hover:text-white hover:border-amber-400 transition-all font-serif font-bold text-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF Dossier</span>
            </a>
          )}
        </div>
      </div>

      {/* Blueprint Results Dashboard */}
      {result && !loading && (
        <div className="space-y-8">
          
          {/* Main Top Overview Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Seeker Cosmic Persona */}
            <div className="glass-card rounded-2xl p-6 border border-purple-500/20 space-y-3">
              <span className="text-[10px] text-amber-300 uppercase tracking-wider font-serif font-bold block">
                Astrological Placement
              </span>
              <h3 className="font-serif text-2xl font-bold text-slate-100">
                {result.astrological_profile.zodiac_sign} (Sun)
              </h3>
              <p className="text-xs text-purple-200">
                Archetype: <strong>{result.astrological_profile.archetype}</strong> • Ruling: <strong>{result.astrological_profile.ruling_planet}</strong>
              </p>
              <p className="text-xs text-slate-400 leading-relaxed">
                {result.astrological_profile.summary}
              </p>
            </div>

            {/* Numerology Core */}
            <div className="glass-card rounded-2xl p-6 border border-purple-500/20 space-y-3">
              <span className="text-[10px] text-amber-300 uppercase tracking-wider font-serif font-bold block">
                Pythagorean Numerology
              </span>
              <h3 className="font-serif text-2xl font-bold text-slate-100">
                Life Path {result.numerology_profile.life_path_number}
              </h3>
              <p className="text-xs text-purple-200">
                {result.numerology_profile.title}
              </p>
              <p className="text-xs text-slate-400 leading-relaxed">
                {result.numerology_profile.core_lesson}
              </p>
            </div>

            {/* Overall Harmony Index */}
            <div className="glass-card rounded-2xl p-6 border border-amber-500/30 flex flex-col justify-between shadow-gold-glow">
              <div>
                <span className="text-[10px] text-amber-300 uppercase tracking-wider font-serif font-bold block">
                  Unified Harmony Index
                </span>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-4xl font-serif font-bold gold-gradient-text">
                    {result.overall_harmony_score.toFixed(1)}%
                  </span>
                  <span className="text-xs text-emerald-400 font-bold">Resonant</span>
                </div>
              </div>
              
              <div className="bg-purple-950/60 p-3 rounded-xl border border-purple-500/20 text-xs text-purple-200 mt-2">
                Top Strength: <strong className="text-amber-300">{result.life_category_guidance.top_strength.name}</strong>
              </div>
            </div>

          </div>

          {/* Unified Narrative Synthesis Dossier */}
          <div className="glass-panel rounded-3xl p-6 lg:p-8 border border-purple-500/30 space-y-4 shadow-cosmic-glow">
            <div className="flex items-center gap-2 border-b border-purple-500/20 pb-3">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <h3 className="font-serif font-bold text-lg text-slate-100">
                Comprehensive Soul Synthesis Dossier
              </h3>
            </div>
            
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {result.unified_dossier}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="bg-cosmic-950/70 p-4 rounded-2xl border border-purple-900/40 space-y-1">
                <span className="text-xs font-serif font-bold text-amber-300 block">
                  Chiromancy Foundation ({result.palm_synthesis.hand_type} Hand)
                </span>
                <p className="text-xs text-slate-400">
                  {result.palm_synthesis.hand_type_desc || "Grounded elemental structure anchoring physical and emotional stamina."}
                </p>
              </div>

              <div className="bg-cosmic-950/70 p-4 rounded-2xl border border-purple-900/40 space-y-1">
                <span className="text-xs font-serif font-bold text-indigo-300 block">
                  Tarot Archetypal Catalyst ({result.tarot_synthesis.spread_name})
                </span>
                <p className="text-xs text-slate-400">
                  {result.tarot_synthesis.holistic_interpretation || "Dynamic forces aligning conscious willpower with intuitive destiny."}
                </p>
              </div>
            </div>
          </div>

          {/* 7-Dimension Matrix & Prescribed Rituals */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left: 7-Dimension Score Radar */}
            <div className="lg:col-span-6">
              <ScoreRadar 
                scores={result.dimension_scores} 
                overallScore={result.overall_harmony_score} 
              />
            </div>

            {/* Right: Prescribed Rituals, Crystals & Affirmations */}
            <div className="lg:col-span-6 space-y-6">
              
              {/* Personalized Rituals */}
              <div className="glass-card rounded-2xl p-5 border border-purple-500/20 space-y-3">
                <h4 className="font-serif font-bold text-sm text-amber-300 flex items-center gap-2">
                  <Flame className="w-4 h-4 text-amber-400" />
                  Prescribed Daily Alignment Rituals
                </h4>

                <div className="space-y-3">
                  {result.personalized_rituals.map((r, i) => (
                    <div key={i} className="bg-cosmic-950/60 p-3.5 rounded-xl border border-purple-900/40 text-xs space-y-1">
                      <div className="flex items-center justify-between font-serif font-bold text-slate-200">
                        <span>{r.title}</span>
                        <span className="text-[10px] text-amber-300 font-mono">{r.duration}</span>
                      </div>
                      <p className="text-slate-300 text-[11px] leading-relaxed">
                        {r.instructions}
                      </p>
                      <p className="text-[10px] text-purple-300/80 italic">
                        Purpose: {r.purpose}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Crystals & Remedies */}
              <div className="glass-card rounded-2xl p-5 border border-purple-500/20 space-y-3">
                <h4 className="font-serif font-bold text-sm text-indigo-300 flex items-center gap-2">
                  <Gem className="w-4 h-4 text-indigo-400" />
                  Recommended Crystal Allies
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {result.recommended_crystals.map((c, i) => (
                    <div key={i} className="bg-indigo-950/40 p-3 rounded-xl border border-indigo-500/20 text-xs">
                      <span className="font-serif font-bold text-slate-100 block mb-0.5">{c.name}</span>
                      <p className="text-[11px] text-slate-400">{c.purpose}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Affirmation Card */}
              {result.affirmations.length > 0 && (
                <div className="bg-gradient-to-r from-purple-950/80 to-indigo-950/80 p-4 rounded-2xl border border-amber-500/30 text-center shadow-gold-glow">
                  <span className="text-[10px] font-serif uppercase tracking-widest text-amber-300 font-bold block mb-1">
                    Your Core Cosmic Affirmation
                  </span>
                  <p className="font-serif text-xs sm:text-sm text-slate-100 italic">
                    "{result.affirmations[0]}"
                  </p>
                </div>
              )}

            </div>

          </div>

        </div>
      )}

    </div>
  );
};
