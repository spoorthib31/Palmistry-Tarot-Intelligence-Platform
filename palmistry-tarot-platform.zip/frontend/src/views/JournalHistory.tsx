import React, { useState, useEffect } from 'react';
import { 
  History, Sparkles, Hand, Layers, Compass, 
  Trash2, Eye, Calendar, Award, Star
} from 'lucide-react';
import { apiService } from '../services/api';
import { ReadingSummary, User } from '../types';

interface JournalHistoryProps {
  currentUser: User | null;
  onOpenAuth: () => void;
}

export const JournalHistory: React.FC<JournalHistoryProps> = ({
  currentUser,
  onOpenAuth
}) => {
  const [readings, setReadings] = useState<ReadingSummary[]>([]);
  const [selectedReading, setSelectedReading] = useState<any | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [filterType, setFilterType] = useState<string>('all');

  const fetchReadings = async () => {
    if (!currentUser) return;
    setLoading(true);
    try {
      const data = await apiService.getReadings();
      setReadings(data);
    } catch (err) {
      console.warn('Could not fetch readings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReadings();
  }, [currentUser]);

  const viewDetail = async (id: number) => {
    try {
      const detail = await apiService.getReadingDetail(id);
      setSelectedReading(detail);
    } catch (err: any) {
      alert("Failed to load reading details.");
    }
  };

  const deleteReadingItem = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Are you sure you wish to dissolve this reading from your journal?")) return;
    try {
      await apiService.deleteReading(id);
      setReadings(readings.filter(r => r.id !== id));
      if (selectedReading?.id === id) setSelectedReading(null);
    } catch (err: any) {
      alert("Could not delete reading.");
    }
  };

  if (!currentUser) {
    return (
      <div className="glass-panel rounded-3xl p-12 text-center max-w-lg mx-auto border border-purple-500/30 space-y-4 shadow-cosmic-glow animate-in fade-in">
        <History className="w-12 h-12 text-amber-400 mx-auto animate-pulse-slow" />
        <h3 className="font-serif text-2xl font-bold text-slate-100">
          Seeker Spiritual Journal
        </h3>
        <p className="text-xs text-slate-400">
          Please enter the portal or sign in to track your personal readings, timeline evolution, and spiritual growth milestones.
        </p>
        <button
          onClick={onOpenAuth}
          className="px-6 py-2.5 rounded-xl font-serif font-bold text-xs gold-gradient-btn text-cosmic-950"
        >
          Enter Portal / Sign In
        </button>
      </div>
    );
  }

  const filtered = readings.filter(r => {
    if (filterType === 'all') return true;
    return r.reading_type === filterType;
  });

  const getIcon = (type: string) => {
    if (type === 'palm') return <Hand className="w-4 h-4 text-rose-400" />;
    if (type === 'tarot') return <Layers className="w-4 h-4 text-amber-400" />;
    return <Compass className="w-4 h-4 text-indigo-400" />;
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-6xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 glass-card p-6 rounded-3xl border border-purple-500/20">
        <div>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-slate-100 flex items-center gap-2">
            <History className="w-6 h-6 text-amber-400" />
            Spiritual Journal & Reading History
          </h2>
          <span className="text-xs text-slate-400">
            {readings.length} total readings archived for {currentUser.full_name}
          </span>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 bg-cosmic-950 p-1 rounded-2xl border border-purple-500/30 text-xs">
          {['all', 'palm', 'tarot', 'synthesized_holistic'].map((f) => (
            <button
              key={f}
              onClick={() => setFilterType(f)}
              className={`px-3 py-1.5 rounded-xl capitalize font-medium transition-all ${
                filterType === f 
                  ? 'bg-purple-600 text-white shadow-cosmic-glow' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {f.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Grid Layout: History List & Selected Item Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Readings List */}
        <div className="lg:col-span-5 space-y-3">
          {loading && (
            <div className="text-center p-8 text-slate-400 text-xs">Loading readings from the archives...</div>
          )}

          {!loading && filtered.length === 0 && (
            <div className="glass-card rounded-2xl p-8 text-center text-slate-400 text-xs border border-purple-500/20">
              No readings found in this category. Perform a Palm Scan or Tarot Draw to begin recording your journey.
            </div>
          )}

          {filtered.map((r) => {
            const isSelected = selectedReading?.id === r.id;
            return (
              <div
                key={r.id}
                onClick={() => viewDetail(r.id)}
                className={`glass-card p-4 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                  isSelected 
                    ? 'border-amber-400 bg-purple-950/60 shadow-gold-glow scale-[1.02]' 
                    : 'border-purple-500/20 hover:border-purple-400/50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-cosmic-950 flex items-center justify-center border border-purple-500/30">
                    {getIcon(r.reading_type)}
                  </div>
                  <div>
                    <h4 className="font-serif font-bold text-xs sm:text-sm text-slate-100">{r.title}</h4>
                    <div className="flex items-center gap-2 text-[10px] text-slate-400">
                      <span>{new Date(r.created_at).toLocaleDateString()}</span>
                      <span>•</span>
                      <span className="text-amber-300 font-mono">Score: {r.overall_score.toFixed(0)}%</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={(e) => deleteReadingItem(r.id, e)}
                  title="Delete"
                  className="p-2 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Selected Reading Detail Preview */}
        <div className="lg:col-span-7">
          {selectedReading ? (
            <div className="glass-panel rounded-3xl p-6 border border-purple-500/30 space-y-4 shadow-cosmic-glow">
              <div className="flex items-center justify-between border-b border-purple-500/20 pb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-amber-400" />
                  <div>
                    <h3 className="font-serif font-bold text-lg text-slate-100">{selectedReading.title}</h3>
                    <span className="text-[10px] text-slate-400">{new Date(selectedReading.created_at).toLocaleString()}</span>
                  </div>
                </div>
                <span className="text-xl font-bold font-serif gold-gradient-text">
                  {selectedReading.overall_score?.toFixed(1)}%
                </span>
              </div>

              {/* Interpretation preview */}
              {selectedReading.ai_interpretation && (
                <div className="bg-cosmic-950/70 p-4 rounded-2xl border border-purple-900/40 text-xs text-slate-300 leading-relaxed">
                  <span className="font-serif font-bold text-amber-300 block mb-1">Oracle Interpretation:</span>
                  <p>{selectedReading.ai_interpretation.dossier || selectedReading.ai_interpretation.holistic || JSON.stringify(selectedReading.ai_interpretation)}</p>
                </div>
              )}

              {/* Consultant Notes & Feedback */}
              {selectedReading.reader_notes && (
                <div className="bg-indigo-950/40 p-3.5 rounded-2xl border border-indigo-500/30 text-xs">
                  <span className="font-serif font-bold text-indigo-300 block mb-1">Consultant Notes:</span>
                  <p className="text-slate-300">{selectedReading.reader_notes}</p>
                </div>
              )}

              {/* Recommendations */}
              {selectedReading.recommendations && (
                <div className="text-xs space-y-1">
                  <span className="font-serif font-bold text-emerald-400 block">Guidance & Remedies:</span>
                  <p className="text-slate-400">{JSON.stringify(selectedReading.recommendations)}</p>
                </div>
              )}
            </div>
          ) : (
            <div className="glass-card rounded-3xl p-12 text-center text-slate-400 text-xs border border-purple-500/20 flex flex-col items-center justify-center h-full min-h-[300px]">
              <Eye className="w-8 h-8 text-purple-400 mb-2 opacity-60" />
              <p>Select any reading from the list to inspect full details and consultant annotations.</p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
