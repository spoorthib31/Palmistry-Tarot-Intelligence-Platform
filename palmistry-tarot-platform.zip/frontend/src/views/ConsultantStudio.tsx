import React, { useState, useEffect } from 'react';
import { Shield, Sparkles, Edit3, CheckCircle2, MessageSquare } from 'lucide-react';
import { apiService } from '../services/api';
import { ReadingSummary, User } from '../types';

interface ConsultantStudioProps {
  currentUser: User | null;
}

export const ConsultantStudio: React.FC<ConsultantStudioProps> = ({
  currentUser
}) => {
  const [readings, setReadings] = useState<ReadingSummary[]>([]);
  const [selectedReading, setSelectedReading] = useState<any | null>(null);
  const [notes, setNotes] = useState<string>('');
  const [rating, setRating] = useState<number>(5);
  const [saving, setSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  const loadConsultantReadings = async () => {
    try {
      const data = await apiService.getReadings();
      setReadings(data);
    } catch (e) {
      console.warn('Could not load readings:', e);
    }
  };

  useEffect(() => {
    loadConsultantReadings();
  }, []);

  const handleSelect = async (id: number) => {
    try {
      const detail = await apiService.getReadingDetail(id);
      setSelectedReading(detail);
      setNotes(detail.reader_notes || '');
      setRating(detail.rating || 5);
      setSaveSuccess(false);
    } catch (e) {
      alert("Failed to load reading details.");
    }
  };

  const handleSaveNotes = async () => {
    if (!selectedReading) return;
    setSaving(true);
    try {
      await apiService.updateReadingNotes(selectedReading.id, notes, undefined, rating);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (e) {
      alert("Failed to save consultant notes.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-7xl mx-auto">
      
      {/* Studio Header */}
      <div className="glass-panel rounded-3xl p-6 border border-indigo-500/30 flex items-center justify-between shadow-cosmic-glow">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-900/60 border border-indigo-400/40 flex items-center justify-center text-indigo-300">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <h2 className="font-serif text-2xl font-bold text-slate-100">
              Spiritual Consultant Studio
            </h2>
            <p className="text-xs text-indigo-200">
              Grand Mystic Workspace: Review, annotate, and augment seeker readings with professional chiromancy and tarot alchemy.
            </p>
          </div>
        </div>

        <div className="text-right hidden sm:block">
          <span className="text-xs text-slate-400 block">Consultant Profile</span>
          <span className="font-serif font-bold text-amber-300">{currentUser?.full_name}</span>
        </div>
      </div>

      {/* Grid: Seeker Queue & Review Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Seeker Reading Queue */}
        <div className="lg:col-span-5 space-y-3">
          <h3 className="font-serif font-bold text-sm text-slate-200 uppercase tracking-wider">
            Seeker Client Dossiers ({readings.length})
          </h3>

          <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
            {readings.map((r) => {
              const isSelected = selectedReading?.id === r.id;
              return (
                <div
                  key={r.id}
                  onClick={() => handleSelect(r.id)}
                  className={`glass-card p-4 rounded-2xl border cursor-pointer transition-all ${
                    isSelected 
                      ? 'border-indigo-400 bg-indigo-950/60 shadow-cosmic-glow scale-[1.02]' 
                      : 'border-purple-500/20 hover:border-purple-400/50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-serif font-bold text-xs text-slate-100">{r.title}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-950 text-indigo-300 font-mono">
                      Score: {r.overall_score.toFixed(0)}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span>Client ID: #{r.user_id}</span>
                    <span>{new Date(r.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Consultant Annotation Workspace */}
        <div className="lg:col-span-7">
          {selectedReading ? (
            <div className="glass-panel rounded-3xl p-6 border border-purple-500/30 space-y-5 shadow-cosmic-glow">
              
              <div className="flex items-center justify-between border-b border-purple-500/20 pb-3">
                <div>
                  <h3 className="font-serif font-bold text-lg text-slate-100">{selectedReading.title}</h3>
                  <span className="text-xs text-purple-300">Seeker: {selectedReading.user_name || `Seeker #${selectedReading.user_id}`}</span>
                </div>
                <span className="text-xl font-bold font-serif gold-gradient-text">
                  {selectedReading.overall_score.toFixed(1)}%
                </span>
              </div>

              {/* AI Synthesized Summary */}
              <div className="bg-cosmic-950/70 p-4 rounded-2xl border border-purple-900/40 text-xs text-slate-300 space-y-1">
                <span className="font-serif font-bold text-amber-300 block">AI Reading Synthesis:</span>
                <p className="leading-relaxed">
                  {selectedReading.ai_interpretation?.dossier || selectedReading.ai_interpretation?.holistic || JSON.stringify(selectedReading.ai_interpretation)}
                </p>
              </div>

              {/* Consultant Notes Form */}
              <div className="space-y-3">
                <label className="font-serif font-bold text-xs text-indigo-300 block">
                  Consultant Spiritual Notes & Esoteric Counsel:
                </label>
                <textarea
                  rows={5}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Enter your expert chiromancy & tarot interpretation guidance for this seeker..."
                  className="w-full p-3 rounded-2xl bg-cosmic-950 border border-purple-500/30 text-xs text-slate-100 focus:outline-none focus:border-indigo-400"
                />

                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-300">Spiritual Harmony Rating:</span>
                    <select
                      value={rating}
                      onChange={(e) => setRating(parseInt(e.target.value))}
                      className="px-3 py-1 rounded-xl bg-cosmic-950 border border-purple-500/30 text-xs text-amber-300 font-bold"
                    >
                      <option value={5}>⭐⭐⭐⭐⭐ (5/5 Pristine)</option>
                      <option value={4}>⭐⭐⭐⭐ (4/5 High Resonance)</option>
                      <option value={3}>⭐⭐⭐ (3/5 In Incubation)</option>
                    </select>
                  </div>

                  <button
                    onClick={handleSaveNotes}
                    disabled={saving}
                    className="px-6 py-2 rounded-xl font-serif font-bold text-xs cosmic-gradient-btn text-white flex items-center gap-2"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>{saving ? 'Saving...' : 'Save & Publish Notes'}</span>
                  </button>
                </div>

                {saveSuccess && (
                  <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Consultant notes updated and archived for the seeker.</span>
                  </div>
                )}
              </div>

            </div>
          ) : (
            <div className="glass-card rounded-3xl p-12 text-center text-slate-400 text-xs border border-purple-500/20 flex flex-col items-center justify-center min-h-[350px]">
              <Sparkles className="w-8 h-8 text-indigo-400 mb-2 opacity-60" />
              <p>Select a seeker's dossier from the queue to start review and consultation.</p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
