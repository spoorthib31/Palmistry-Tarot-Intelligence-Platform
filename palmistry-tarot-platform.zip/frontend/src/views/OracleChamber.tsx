import React, { useState, useRef, useEffect } from 'react';
import { 
  MessageSquareCode, Send, Sparkles, Volume2, VolumeX, 
  Key, Bot, User as UserIcon, RefreshCw, Compass
} from 'lucide-react';
import { apiService } from '../services/api';
import { ChatMessage, PalmFeatures, TarotSpreadResult } from '../types';
import { cosmicAudio } from '../services/audioSynthesizer';

interface OracleChamberProps {
  palmFeatures?: PalmFeatures | null;
  tarotSpread?: TarotSpreadResult | null;
  zodiacSign?: string;
}

export const OracleChamber: React.FC<OracleChamberProps> = ({
  palmFeatures,
  tarotSpread,
  zodiacSign = "Scorpio"
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: "Greetings, noble seeker. I am Aurelia, your Celestial Oracle. I observe the sacred topography of your palm and the archetypes of your active tarot spreads. What truth or guidance does your soul seek today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputMessage, setInputMessage] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [geminiKey, setGeminiKey] = useState<string>(() => localStorage.getItem('custom_gemini_key') || '');
  const [showKeyModal, setShowKeyModal] = useState<boolean>(false);
  const [activeAudioUrl, setActiveAudioUrl] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const quickPrompts = [
    "What spiritual lesson is active in my palm's Head line slope?",
    "How do my drawn tarot cards interact with my career path?",
    "What daily meditation best harmonizes my energy blueprint?",
    "What shadow pattern should I bring into the light?"
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setLoading(true);
    cosmicAudio.playTibetanChime(432);

    try {
      const contextPayload = {
        zodiac_sign: zodiacSign,
        palm_features: palmFeatures,
        tarot_spread: tarotSpread
      };

      const res = await apiService.chatWithOracle(
        text.trim(),
        [...messages, userMsg],
        contextPayload,
        geminiKey || undefined
      );

      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: res.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        audio_url: res.audio_tts_url
      };

      setMessages((prev) => [...prev, assistantMsg]);
      if (res.audio_tts_url) {
        setActiveAudioUrl(res.audio_tts_url);
      }
    } catch (err: any) {
      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "The cosmic ether encountered a momentary ripple. Please ask your inquiry again.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveGeminiKey = (key: string) => {
    setGeminiKey(key);
    localStorage.setItem('custom_gemini_key', key);
    setShowKeyModal(false);
  };

  const playTTSAudio = (url?: string) => {
    if (!url) return;
    if (audioPlayerRef.current) {
      audioPlayerRef.current.src = url;
      audioPlayerRef.current.play();
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-in fade-in duration-500">
      
      {/* Hidden audio element for TTS playback */}
      <audio ref={audioPlayerRef} className="hidden" />

      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 glass-card p-4 rounded-3xl border border-purple-500/20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-purple-600 to-indigo-700 flex items-center justify-center border border-purple-300/40 shadow-cosmic-glow">
            <Sparkles className="w-5 h-5 text-amber-300 animate-pulse-slow" />
          </div>
          <div>
            <h3 className="font-serif font-bold text-base text-slate-100 flex items-center gap-2">
              Aurelia • The Celestial Oracle
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </h3>
            <span className="text-[11px] text-purple-300/80">
              Context: {palmFeatures ? `${palmFeatures.hand_type} Palm` : 'General Palm'} • {tarotSpread ? `${tarotSpread.drawn_cards.length}-Card Spread` : 'General Tarot'} • {zodiacSign} Sun
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowKeyModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs bg-cosmic-950/80 border border-purple-500/30 text-slate-300 hover:text-amber-300 hover:border-amber-400/50 transition-all"
          >
            <Key className="w-3.5 h-3.5 text-amber-400" />
            <span>{geminiKey ? "Gemini Key (Active)" : "API Key (Optional)"}</span>
          </button>

          <button
            onClick={() => setMessages([messages[0]])}
            title="Clear Chat History"
            className="p-2 rounded-xl bg-cosmic-950/80 border border-purple-500/30 text-slate-400 hover:text-white"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Chat Conversation Container */}
      <div className="glass-panel rounded-3xl p-4 sm:p-6 border border-purple-500/30 shadow-cosmic-glow h-[520px] flex flex-col justify-between">
        
        {/* Messages Scroll Area */}
        <div className="overflow-y-auto space-y-4 pr-2 flex-1">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
              >
                {/* Avatar */}
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${
                  isUser 
                    ? 'bg-amber-500 text-cosmic-950 font-serif' 
                    : 'bg-purple-900 border border-purple-400/40 text-amber-300'
                }`}>
                  {isUser ? <UserIcon className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                {/* Bubble */}
                <div className={`max-w-[80%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed space-y-2 ${
                  isUser
                    ? 'bg-gradient-to-r from-purple-700 to-indigo-700 text-white rounded-tr-none shadow-cosmic-glow'
                    : 'glass-card bg-cosmic-950/80 border border-purple-500/30 text-slate-200 rounded-tl-none'
                }`}>
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                  
                  <div className="flex items-center justify-between gap-3 text-[10px] text-slate-400 pt-1 border-t border-purple-500/10">
                    <span>{msg.timestamp}</span>
                    {msg.audio_url && (
                      <button
                        onClick={() => playTTSAudio(msg.audio_url)}
                        className="flex items-center gap-1 text-amber-300 hover:text-amber-200 transition-colors font-medium"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>Listen to Voice</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {loading && (
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-900 border border-purple-400/40 flex items-center justify-center text-amber-300">
                <Bot className="w-4 h-4 animate-spin-slow" />
              </div>
              <div className="glass-card p-3 rounded-2xl rounded-tl-none border border-purple-500/30 text-xs text-purple-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
                <span>Channeling celestial frequencies...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Quick Prompts */}
        <div className="pt-3 border-t border-purple-500/20">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
            {quickPrompts.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(prompt)}
                disabled={loading}
                className="whitespace-nowrap px-3 py-1 rounded-full text-[11px] bg-cosmic-950/80 border border-purple-500/30 text-purple-200 hover:text-white hover:border-amber-400/60 transition-all shrink-0"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <div className="relative flex items-center gap-2 mt-1">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Ask Aurelia about your palm, tarot cards, or spiritual destiny..."
              className="w-full px-4 py-3 rounded-2xl bg-cosmic-950/90 border border-purple-500/40 text-xs sm:text-sm text-slate-100 focus:outline-none focus:border-amber-400 shadow-inner pr-12"
            />
            <button
              onClick={() => handleSendMessage()}
              disabled={loading || !inputMessage.trim()}
              className="absolute right-2.5 p-2 rounded-xl gold-gradient-btn text-cosmic-950 disabled:opacity-40"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>

      {/* API Key Modal */}
      {showKeyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="glass-panel border border-amber-500/30 rounded-3xl max-w-md w-full p-6 text-slate-100 relative shadow-gold-glow animate-in fade-in zoom-in-95">
            <button
              onClick={() => setShowKeyModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white text-lg font-bold w-8 h-8 rounded-full bg-purple-950/60 flex items-center justify-center border border-purple-400/30"
            >
              ✕
            </button>

            <div className="text-center mb-4">
              <Key className="w-8 h-8 text-amber-400 mx-auto mb-2" />
              <h3 className="font-serif text-xl font-bold gold-gradient-text">
                Live AI API Key (Optional)
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                The platform works out of the box using built-in symbolic intelligence. You may optionally plug in a Gemini API key for live generative text.
              </p>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-purple-300 block mb-1">Google Gemini API Key</label>
                <input
                  type="password"
                  value={geminiKey}
                  onChange={(e) => setGeminiKey(e.target.value)}
                  placeholder="AIzaSy..."
                  className="w-full px-3 py-2 rounded-xl bg-cosmic-950 border border-purple-500/30 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              <button
                onClick={() => handleSaveGeminiKey(geminiKey)}
                className="w-full py-2.5 rounded-xl font-serif font-bold text-xs gold-gradient-btn text-cosmic-950"
              >
                Save Configuration
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
