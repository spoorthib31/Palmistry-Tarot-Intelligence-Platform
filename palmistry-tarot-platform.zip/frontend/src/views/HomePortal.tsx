import React from 'react';
import { 
  Sparkles, Hand, Layers, Compass, MessageSquareCode, 
  ArrowRight, ShieldCheck, Sun, Moon, Flame
} from 'lucide-react';
import { DailyGuidance } from '../types';
import { TarotCardView } from '../components/TarotCardView';
import { cosmicAudio } from '../services/audioSynthesizer';

interface HomePortalProps {
  onNavigate: (tab: string) => void;
  dailyGuidance: DailyGuidance | null;
}

export const HomePortal: React.FC<HomePortalProps> = ({
  onNavigate,
  dailyGuidance
}) => {
  return (
    <div className="space-y-12 animate-in fade-in duration-500">
      
      {/* Hero Section */}
      <section className="relative rounded-3xl p-8 lg:p-14 overflow-hidden glass-panel border border-purple-500/30 text-center shadow-cosmic-glow">
        
        {/* Sacred Geometry Background */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#8b5cf6_1px,transparent_1px)] [background-size:24px_24px]" />
        <div className="absolute -top-32 -left-32 w-80 h-80 rounded-full bg-purple-600/20 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-32 -right-32 w-80 h-80 rounded-full bg-amber-500/20 blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl mx-auto space-y-6">
          
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-900/60 border border-purple-400/40 text-xs font-serif text-amber-300 shadow-cosmic-glow">
            <Sparkles className="w-4 h-4 text-amber-300 animate-pulse-slow" />
            <span>Harmonizing Ancient Hermetic Wisdom & Neural Intelligence</span>
          </div>

          <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-slate-100 leading-tight">
            AI-Powered <span className="gold-gradient-text">Palmistry & Tarot</span> Sanctuary
          </h1>

          <p className="text-sm sm:text-base text-slate-300/90 leading-relaxed font-light">
            Unlock your soul's multidimensional blueprint. Seamlessly synthesize high-precision computer vision chiromancy, the 78-card sacred tarot oracle, and astrological numerology into deep, actionable spiritual guidance.
          </p>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              onClick={() => {
                cosmicAudio.playTibetanChime();
                onNavigate('palm');
              }}
              className="flex items-center gap-2 px-6 py-3 rounded-2xl text-xs sm:text-sm font-serif font-bold gold-gradient-btn text-cosmic-950"
            >
              <Hand className="w-4 h-4 text-cosmic-950" />
              <span>Scan Your Palm</span>
              <ArrowRight className="w-4 h-4 text-cosmic-950" />
            </button>

            <button
              onClick={() => {
                cosmicAudio.playCardFlipSound();
                onNavigate('tarot');
              }}
              className="flex items-center gap-2 px-6 py-3 rounded-2xl text-xs sm:text-sm font-serif font-bold cosmic-gradient-btn text-white"
            >
              <Layers className="w-4 h-4 text-amber-300" />
              <span>Consult Tarot Deck</span>
            </button>

            <button
              onClick={() => onNavigate('synthesis')}
              className="flex items-center gap-2 px-5 py-3 rounded-2xl text-xs sm:text-sm font-medium bg-cosmic-900/80 border border-purple-500/30 text-purple-200 hover:text-white hover:border-purple-400 transition-all"
            >
              <Compass className="w-4 h-4 text-purple-400" />
              <span>Cosmic Blueprint</span>
            </button>
          </div>

        </div>
      </section>

      {/* Daily Divination & Planetary Alignment Widget */}
      {dailyGuidance && (
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Daily Card Draw */}
          <div className="glass-card rounded-3xl p-6 border border-amber-500/30 flex flex-col sm:flex-row items-center gap-6 lg:col-span-2 shadow-gold-glow">
            <div className="shrink-0">
              <TarotCardView 
                card={dailyGuidance.daily_card} 
                size="md" 
                positionName="Daily Cosmic Archetype"
                positionMeaning={dailyGuidance.date}
              />
            </div>

            <div className="space-y-3 text-left">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full text-[10px] uppercase tracking-wider font-bold bg-amber-500/20 border border-amber-400/40 text-amber-300">
                  Daily Oracle Message
                </span>
                <span className="text-xs text-slate-400 font-serif">
                  {dailyGuidance.date}
                </span>
              </div>

              <h3 className="font-serif text-xl font-bold text-slate-100">
                {dailyGuidance.daily_card.name}
              </h3>

              <p className="text-xs text-slate-300 leading-relaxed">
                {dailyGuidance.daily_card.description_upright}
              </p>

              <div className="bg-purple-950/50 p-3 rounded-xl border border-purple-500/30 text-xs">
                <span className="font-bold text-amber-300 block mb-0.5 font-serif">
                  Today's Affirmation:
                </span>
                <p className="italic text-purple-200">
                  "{dailyGuidance.cosmic_affirmation}"
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px] text-slate-400">
                <span>Lucky Colors: <strong className="text-slate-200">{dailyGuidance.lucky_colors.join(', ')}</strong></span>
                <span>•</span>
                <span>Lucky Numbers: <strong className="text-amber-300">{dailyGuidance.lucky_numbers.join(', ')}</strong></span>
              </div>
            </div>
          </div>

          {/* Planetary Alignment & Rune Tracker */}
          <div className="glass-card rounded-3xl p-6 border border-purple-500/20 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between border-b border-purple-500/20 pb-3">
                <span className="font-serif text-xs uppercase tracking-wider text-purple-300 font-bold flex items-center gap-1.5">
                  <Sun className="w-4 h-4 text-amber-400" />
                  Planetary Clock
                </span>
                <span className="text-xs text-amber-300 font-mono">LIVE</span>
              </div>

              <div className="mt-4 space-y-3">
                <div className="bg-cosmic-950/70 p-3 rounded-2xl border border-purple-500/30 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase">Current Hour</span>
                    <h5 className="font-serif font-bold text-sm text-slate-200">{dailyGuidance.planetary_hour}</h5>
                  </div>
                  <div className="w-9 h-9 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-300 font-serif font-bold">
                    ☉
                  </div>
                </div>

                <div className="bg-cosmic-950/70 p-3 rounded-2xl border border-purple-500/30 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase">Active Rune</span>
                    <h5 className="font-serif font-bold text-sm text-slate-200">{dailyGuidance.rune_name}</h5>
                    <p className="text-[10px] text-slate-400">{dailyGuidance.rune_meaning}</p>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-purple-900/40 border border-purple-400/40 flex items-center justify-center text-xl text-amber-300 font-serif">
                    {dailyGuidance.rune_symbol}
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={() => onNavigate('oracle')}
              className="w-full py-2.5 rounded-xl text-xs font-serif font-bold bg-purple-950/80 border border-purple-500/30 hover:border-purple-400 text-purple-200 hover:text-white transition-all flex items-center justify-center gap-2"
            >
              <MessageSquareCode className="w-3.5 h-3.5 text-amber-300" />
              <span>Converse with Aurelia</span>
            </button>
          </div>

        </section>
      )}

      {/* Feature Pillar Showcase */}
      <section className="space-y-6">
        <div className="text-center space-y-2">
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-slate-100">
            Four Pillars of Esoteric Intelligence
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Engineered with modern computer vision, symbolic knowledge graphs, and multi-modal synthesis.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          
          {/* Pillar 1: Palmistry */}
          <div 
            onClick={() => onNavigate('palm')}
            className="glass-card rounded-2xl p-6 border border-purple-500/20 hover:border-rose-500/40 cursor-pointer group transition-all"
          >
            <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-4 group-hover:scale-110 transition-transform">
              <Hand className="w-6 h-6" />
            </div>
            <h4 className="font-serif font-bold text-base text-slate-100 mb-1">
              PalmScan AI
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              Real-time contour detection of Heart, Head, Life & Fate lines with illuminated glowing overlays.
            </p>
            <span className="text-xs text-rose-400 font-medium flex items-center gap-1 group-hover:translate-x-1 transition-transform">
              Launch Scanner &rarr;
            </span>
          </div>

          {/* Pillar 2: Tarot */}
          <div 
            onClick={() => onNavigate('tarot')}
            className="glass-card rounded-2xl p-6 border border-purple-500/20 hover:border-amber-500/40 cursor-pointer group transition-all"
          >
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-4 group-hover:scale-110 transition-transform">
              <Layers className="w-6 h-6" />
            </div>
            <h4 className="font-serif font-bold text-base text-slate-100 mb-1">
              78-Card Tarot Deck
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              3D interactive spreads (Celtic Cross, Trinity, Career & Love) with upright/reversed dynamics.
            </p>
            <span className="text-xs text-amber-400 font-medium flex items-center gap-1 group-hover:translate-x-1 transition-transform">
              Draw Cards &rarr;
            </span>
          </div>

          {/* Pillar 3: Synthesis */}
          <div 
            onClick={() => onNavigate('synthesis')}
            className="glass-card rounded-2xl p-6 border border-purple-500/20 hover:border-indigo-500/40 cursor-pointer group transition-all"
          >
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mb-4 group-hover:scale-110 transition-transform">
              <Compass className="w-6 h-6" />
            </div>
            <h4 className="font-serif font-bold text-base text-slate-100 mb-1">
              Cosmic Blueprint
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              Holistic 7-dimension energy scoring, tailored rituals, crystal remedies, and downloadable PDF report.
            </p>
            <span className="text-xs text-indigo-400 font-medium flex items-center gap-1 group-hover:translate-x-1 transition-transform">
              Generate Dossier &rarr;
            </span>
          </div>

          {/* Pillar 4: Oracle AI */}
          <div 
            onClick={() => onNavigate('oracle')}
            className="glass-card rounded-2xl p-6 border border-purple-500/20 hover:border-purple-500/40 cursor-pointer group transition-all"
          >
            <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 mb-4 group-hover:scale-110 transition-transform">
              <MessageSquareCode className="w-6 h-6" />
            </div>
            <h4 className="font-serif font-bold text-base text-slate-100 mb-1">
              Mystic Advisor
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              Conversational oracle 'Aurelia' with memory of your readings and synthesized text-to-speech audio.
            </p>
            <span className="text-xs text-purple-400 font-medium flex items-center gap-1 group-hover:translate-x-1 transition-transform">
              Seek Prophecy &rarr;
            </span>
          </div>

        </div>
      </section>

    </div>
  );
};
