import React, { useState, useEffect } from 'react';
import { 
  Layers, Sparkles, RefreshCw, HelpCircle, Compass, 
  Flame, Droplets, Wind, Mountain, ChevronRight, CheckCircle2
} from 'lucide-react';
import { apiService } from '../services/api';
import { TarotCard, TarotSpreadResult, DrawnCard } from '../types';
import { TarotCardView } from '../components/TarotCardView';
import { ScoreRadar } from '../components/ScoreRadar';
import { cosmicAudio } from '../services/audioSynthesizer';

interface TarotSanctuaryProps {
  onSendToSynthesis: (tarotSpread: any) => void;
  cachedSpread?: TarotSpreadResult | null;
}

export const TarotSanctuary: React.FC<TarotSanctuaryProps> = ({
  onSendToSynthesis,
  cachedSpread
}) => {
  const [spreadType, setSpreadType] = useState<string>('three_card');
  const [question, setQuestion] = useState<string>('What energies surround my spiritual journey and growth?');
  const [result, setResult] = useState<TarotSpreadResult | null>(cachedSpread || null);
  const [loading, setLoading] = useState<boolean>(false);
  const [allCards, setAllCards] = useState<TarotCard[]>([]);

  useEffect(() => {
    apiService.getTarotCards().then(setAllCards).catch(() => {});
  }, []);

  const spreadsList = [
    { id: 'single_card', label: 'Single Card Oracle', count: 1, desc: 'Daily spark & immediate focal lesson' },
    { id: 'three_card', label: 'Past • Present • Future', count: 3, desc: 'Timeline trajectory & karmic foundation' },
    { id: 'three_card_mind_body_spirit', label: 'Mind • Body • Spirit', count: 3, desc: 'Triune plane holistic alignment' },
    { id: 'five_card_relationship', label: 'Soul Connection Alchemy', count: 5, desc: 'Relational dynamics, mirror & resolution' },
    { id: 'five_card_career', label: 'Career & Sovereign Destiny', count: 5, desc: 'Vocation, obstacles & abundance harvest' },
    { id: 'celtic_cross', label: 'Sacred Celtic Cross', count: 10, desc: '10-card in-depth spiritual blueprint' },
  ];

  const presetQuestions = [
    "What energies surround my spiritual journey and growth?",
    "How can I align my daily actions with my soul's highest purpose?",
    "What subconscious obstacle requires my compassion and release?",
    "What new opportunity is opening in my career and creative expression?"
  ];

  const handleDraw = async () => {
    setLoading(true);
    cosmicAudio.playTibetanChime();
    try {
      const res = await apiService.drawSpread(spreadType, question);
      setResult(res);
    } catch (err: any) {
      alert(err.message || 'Spread draw failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-950/60 border border-amber-500/30 text-xs font-serif text-amber-300 shadow-gold-glow">
          <Layers className="w-3.5 h-3.5" />
          <span>78-Card Rider-Waite Esoteric Oracle</span>
        </div>
        <h2 className="font-serif text-3xl sm:text-4xl font-bold text-slate-100">
          Tarot Oracle Sanctuary
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto">
          Consult the ancient archetypal deck. Cast multi-card spreads with upright/reversed dynamics and algorithmic elemental synthesis.
        </p>
      </div>

      {/* Spread & Question Configuration Card */}
      {!result && !loading && (
        <div className="glass-panel rounded-3xl p-6 lg:p-10 border border-purple-500/30 space-y-6 shadow-cosmic-glow max-w-4xl mx-auto">
          
          {/* 1. Spread Type Grid */}
          <div className="space-y-3">
            <label className="text-xs font-serif font-bold text-amber-300 uppercase tracking-wider block">
              1. Choose Sacred Spread Formation
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {spreadsList.map((sp) => {
                const isSelected = spreadType === sp.id;
                return (
                  <button
                    key={sp.id}
                    onClick={() => setSpreadType(sp.id)}
                    className={`p-4 rounded-2xl text-left border transition-all ${
                      isSelected
                        ? 'bg-purple-900/80 border-amber-400/80 shadow-gold-glow scale-[1.02]'
                        : 'bg-cosmic-950/60 border-purple-500/20 hover:border-purple-400/50 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-serif font-bold text-xs text-slate-100">{sp.label}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-950 text-amber-300 font-mono">
                        {sp.count} Cards
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-snug">{sp.desc}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Inquiry Question */}
          <div className="space-y-3">
            <label className="text-xs font-serif font-bold text-amber-300 uppercase tracking-wider block">
              2. Focus Your Spiritual Intention / Question
            </label>
            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Ask the tarot oracle..."
              className="w-full px-4 py-3 rounded-2xl bg-cosmic-950 border border-purple-500/30 text-xs sm:text-sm text-slate-100 focus:outline-none focus:border-amber-400 shadow-inner"
            />

            {/* Presets */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {presetQuestions.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => setQuestion(q)}
                  className="px-2.5 py-1 rounded-xl text-[10px] bg-purple-950/50 border border-purple-500/20 text-purple-200 hover:text-white hover:border-purple-400 transition-all"
                >
                  "{q}"
                </button>
              ))}
            </div>
          </div>

          {/* Cast Spread Button */}
          <div className="text-center pt-2">
            <button
              onClick={handleDraw}
              className="px-8 py-3.5 rounded-2xl font-serif font-bold text-sm gold-gradient-btn text-cosmic-950 shadow-gold-glow flex items-center justify-center gap-2 mx-auto"
            >
              <Sparkles className="w-4 h-4 text-cosmic-950" />
              <span>Shuffle Deck & Cast Spread</span>
            </button>
          </div>

        </div>
      )}

      {/* Loading Animation */}
      {loading && (
        <div className="glass-panel rounded-3xl p-12 text-center border border-purple-500/30 space-y-4 shadow-cosmic-glow">
          <div className="w-16 h-16 rounded-full border-4 border-amber-400 border-t-transparent animate-spin mx-auto" />
          <h3 className="font-serif text-xl font-bold gold-gradient-text">
            Consulting the 78 Arcanums of the Tarot...
          </h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Shuffling energetic archetypes, determining upright & reversed polarities, and weaving multi-card holistic synthesis.
          </p>
        </div>
      )}

      {/* Spread Result View */}
      {result && !loading && (
        <div className="space-y-8">
          
          {/* Action Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-4 glass-card p-4 rounded-2xl border border-purple-500/20">
            <div>
              <span className="font-serif font-bold text-sm text-slate-100 block">
                {result.spread_name}
              </span>
              <span className="text-[11px] text-slate-400 italic">
                "{result.question}"
              </span>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setResult(null)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs bg-cosmic-950 border border-purple-500/30 text-slate-300 hover:text-white"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Draw New Spread</span>
              </button>

              <button
                onClick={() => onSendToSynthesis(result)}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-serif font-bold gold-gradient-btn text-cosmic-950"
              >
                <span>Synthesize with Cosmic Blueprint</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Interactive 3D Tarot Table */}
          <div className="glass-panel rounded-3xl p-6 lg:p-10 border border-amber-500/30 shadow-gold-glow">
            
            <div className="text-center mb-6">
              <span className="text-[11px] text-amber-300 uppercase tracking-widest font-serif block">
                Elemental Dominance: {result.dominant_element} • Focus: {result.energy_focus}
              </span>
              <span className="text-[10px] text-slate-400">
                Tap any card to flip orientation or inspect deep esoteric lore
              </span>
            </div>

            {/* Drawn Cards Layout Grid */}
            <div className={`grid gap-6 justify-center items-start ${
              result.drawn_cards.length === 1
                ? 'grid-cols-1 max-w-xs mx-auto'
                : result.drawn_cards.length === 3
                ? 'grid-cols-1 sm:grid-cols-3'
                : result.drawn_cards.length === 5
                ? 'grid-cols-1 sm:grid-cols-3 lg:grid-cols-5'
                : 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-5'
            }`}>
              {result.drawn_cards.map((drawn) => (
                <TarotCardView
                  key={drawn.position_index}
                  card={drawn.card}
                  isReversed={drawn.is_reversed}
                  positionName={drawn.position_name}
                  positionMeaning={drawn.position_meaning}
                  size={result.drawn_cards.length > 5 ? 'sm' : 'md'}
                />
              ))}
            </div>

          </div>

          {/* AI Spread Interpretation & Actionable Wisdom */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left: Holistic Narrative Synthesis */}
            <div className="lg:col-span-7 space-y-6">
              <div className="glass-card rounded-2xl p-6 border border-purple-500/30 space-y-4 shadow-cosmic-glow">
                <div className="flex items-center gap-2 border-b border-purple-500/20 pb-3">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <h4 className="font-serif font-bold text-base text-slate-100">
                    Holistic Archetypal Synthesis
                  </h4>
                </div>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {result.holistic_interpretation}
                </p>

                {/* Card by Card Quick Overview */}
                <div className="space-y-2 pt-2">
                  <span className="text-xs font-serif font-bold text-amber-300 block">
                    Positional Arcana Breakdown:
                  </span>
                  {result.drawn_cards.map((dc) => (
                    <div key={dc.position_index} className="bg-cosmic-950/60 p-3 rounded-xl border border-purple-900/40 text-xs">
                      <div className="flex items-center justify-between font-medium text-slate-200 mb-0.5">
                        <span className="text-amber-300 font-serif">{dc.position_name}</span>
                        <span className="text-[10px] text-purple-300">{dc.card.name} {dc.is_reversed ? '(Reversed)' : ''}</span>
                      </div>
                      <p className="text-slate-400 text-[11px] leading-relaxed">
                        {dc.context_reading}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Actionable Advice */}
                <div className="pt-2">
                  <span className="text-xs font-serif font-bold text-emerald-400 block mb-2">
                    Actionable Spiritual Prescriptions:
                  </span>
                  <ul className="space-y-1.5 text-xs text-slate-300">
                    {result.actionable_advice.map((adv, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{adv}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Right: Dimension Scores Matrix */}
            <div className="lg:col-span-5">
              <ScoreRadar scores={result.dimension_scores} />
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
