import React, { useState, useRef } from 'react';
import { 
  Camera, Upload, Sparkles, RefreshCw, Hand, Heart, 
  Brain, Zap, Award, Sun, CheckCircle2, ChevronRight
} from 'lucide-react';
import { apiService } from '../services/api';
import { PalmAnalysisResult, PalmLineMetric } from '../types';
import { HandCanvasOverlay } from '../components/HandCanvasOverlay';
import { ScoreRadar } from '../components/ScoreRadar';
import { cosmicAudio } from '../services/audioSynthesizer';

interface PalmScanStudioProps {
  onSendToSynthesis: (palmFeatures: any) => void;
  cachedResult?: PalmAnalysisResult | null;
}

export const PalmScanStudio: React.FC<PalmScanStudioProps> = ({
  onSendToSynthesis,
  cachedResult
}) => {
  const [result, setResult] = useState<PalmAnalysisResult | null>(cachedResult || null);
  const [loading, setLoading] = useState<boolean>(false);
  const [handSide, setHandSide] = useState<string>('dominant_right');
  const [activeLineKey, setActiveLineKey] = useState<string>('heart_line');
  const [activeTab, setActiveTab] = useState<string>('personality');
  const [isWebcamActive, setIsWebcamActive] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Start Webcam
  const startWebcam = async () => {
    try {
      setIsWebcamActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: "user" } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      alert("Unable to access camera. You can still upload a palm photo or use instant sample analysis.");
      setIsWebcamActive(false);
    }
  };

  // Stop Webcam
  const stopWebcam = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(t => t.stop());
      videoRef.current.srcObject = null;
    }
    setIsWebcamActive(false);
  };

  // Capture from Webcam
  const captureWebcamFrame = async () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 800;
    canvas.height = videoRef.current.videoHeight || 1000;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    const base64 = canvas.toDataURL('image/jpeg', 0.9);

    stopWebcam();
    setLoading(true);
    cosmicAudio.playTibetanChime();
    try {
      const res = await apiService.analyzePalmBase64(base64, handSide);
      setResult(res);
    } catch (err: any) {
      alert(err.message || "Analysis failed.");
    } finally {
      setLoading(false);
    }
  };

  // Upload Photo File
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    cosmicAudio.playTibetanChime();
    try {
      const res = await apiService.analyzePalmFile(file, handSide);
      setResult(res);
    } catch (err: any) {
      alert(err.message || "File analysis failed.");
    } finally {
      setLoading(false);
    }
  };

  // Load Instant High-Detail Sample
  const loadSamplePalm = async () => {
    setLoading(true);
    cosmicAudio.playTibetanChime();
    try {
      const res = await apiService.getSamplePalm();
      setResult(res);
    } catch (err: any) {
      alert(err.message || "Failed to load sample palm.");
    } finally {
      setLoading(false);
    }
  };

  const activeLine: PalmLineMetric | undefined = result?.features?.lines?.[activeLineKey];

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-6xl mx-auto">
      
      {/* Studio Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-rose-950/60 border border-rose-500/30 text-xs font-serif text-rose-300 shadow-cosmic-glow">
          <Hand className="w-3.5 h-3.5" />
          <span>Computer Vision Chiromancy Engine</span>
        </div>
        <h2 className="font-serif text-3xl sm:text-4xl font-bold text-slate-100">
          PalmScan AI Studio
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto">
          Capture or upload your palm to detect key major lines (Heart, Head, Life, Fate), evaluate mounts, classify hand typology, and reveal deep soul insights.
        </p>
      </div>

      {/* Capture / Upload Control Card */}
      {!result && !loading && (
        <div className="glass-panel rounded-3xl p-6 lg:p-10 border border-purple-500/30 shadow-cosmic-glow">
          
          {/* Hand Side Selector */}
          <div className="flex justify-center mb-6">
            <div className="inline-flex rounded-2xl bg-cosmic-950/80 p-1 border border-purple-500/30 text-xs">
              <button
                onClick={() => setHandSide('dominant_right')}
                className={`px-4 py-2 rounded-xl font-medium transition-all ${
                  handSide === 'dominant_right' 
                    ? 'bg-purple-600 text-white shadow-cosmic-glow font-bold' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Dominant Right Hand (Manifested Destiny)
              </button>
              <button
                onClick={() => setHandSide('dominant_left')}
                className={`px-4 py-2 rounded-xl font-medium transition-all ${
                  handSide === 'dominant_left' 
                    ? 'bg-purple-600 text-white shadow-cosmic-glow font-bold' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Dominant Left Hand (Innate Potential)
              </button>
            </div>
          </div>

          {/* Webcam Mode */}
          {isWebcamActive ? (
            <div className="relative max-w-md mx-auto aspect-[3/4] rounded-3xl overflow-hidden border-2 border-amber-400/50 shadow-gold-glow bg-black flex items-center justify-center">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
              
              {/* Palm Silhouette Overlay Guide */}
              <div className="absolute inset-0 border-2 border-dashed border-amber-300/40 rounded-3xl m-8 flex items-center justify-center pointer-events-none">
                <span className="text-[11px] text-amber-200 bg-black/60 px-3 py-1 rounded-full font-serif">
                  Align Palm Inside Guide
                </span>
              </div>

              {/* Capture Action Bar */}
              <div className="absolute bottom-4 inset-x-0 flex justify-center gap-3">
                <button
                  onClick={captureWebcamFrame}
                  className="px-6 py-2.5 rounded-2xl font-serif font-bold text-xs gold-gradient-btn text-cosmic-950 flex items-center gap-2 shadow-lg"
                >
                  <Camera className="w-4 h-4" />
                  <span>Analyze Frame</span>
                </button>
                <button
                  onClick={stopWebcam}
                  className="px-4 py-2.5 rounded-2xl text-xs bg-rose-950/80 border border-rose-500/40 text-rose-300"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 max-w-3xl mx-auto">
              
              {/* Option 1: Live Webcam */}
              <button
                onClick={startWebcam}
                className="glass-card rounded-2xl p-6 border border-purple-500/30 hover:border-amber-400/60 flex flex-col items-center justify-center gap-3 text-center group transition-all"
              >
                <div className="w-12 h-12 rounded-2xl bg-purple-900/60 border border-purple-400/40 flex items-center justify-center text-amber-300 group-hover:scale-110 transition-transform">
                  <Camera className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-sm text-slate-100">Live Camera</h4>
                  <span className="text-[11px] text-slate-400">Point hand at webcam</span>
                </div>
              </button>

              {/* Option 2: Upload Photo */}
              <button
                onClick={() => fileInputRef.current?.click()}
                className="glass-card rounded-2xl p-6 border border-purple-500/30 hover:border-amber-400/60 flex flex-col items-center justify-center gap-3 text-center group transition-all"
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept="image/*"
                  className="hidden"
                />
                <div className="w-12 h-12 rounded-2xl bg-indigo-900/60 border border-indigo-400/40 flex items-center justify-center text-indigo-300 group-hover:scale-110 transition-transform">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-sm text-slate-100">Upload Photo</h4>
                  <span className="text-[11px] text-slate-400">PNG, JPG or WEBP</span>
                </div>
              </button>

              {/* Option 3: Instant Sample */}
              <button
                onClick={loadSamplePalm}
                className="glass-card rounded-2xl p-6 border border-purple-500/30 hover:border-amber-400/60 flex flex-col items-center justify-center gap-3 text-center group transition-all"
              >
                <div className="w-12 h-12 rounded-2xl bg-rose-900/60 border border-rose-400/40 flex items-center justify-center text-rose-300 group-hover:scale-110 transition-transform">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-sm text-slate-100">Sample Palm</h4>
                  <span className="text-[11px] text-slate-400">Instant AI simulation</span>
                </div>
              </button>

            </div>
          )}

        </div>
      )}

      {/* Loading Spinner */}
      {loading && (
        <div className="glass-panel rounded-3xl p-12 text-center border border-purple-500/30 space-y-4 shadow-cosmic-glow">
          <div className="w-16 h-16 rounded-full border-4 border-amber-400 border-t-transparent animate-spin mx-auto" />
          <h3 className="font-serif text-xl font-bold gold-gradient-text">
            Mapping Chiromancy Lines & Sacred Topography...
          </h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Extracting Heart, Head, Life, and Fate line vectors, evaluating Mount of Venus & Luna prominence, and computing elemental hand shape.
          </p>
        </div>
      )}

      {/* Analysis Results View */}
      {result && !loading && (
        <div className="space-y-8">
          
          {/* Top Reset / Action Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-4 glass-card p-4 rounded-2xl border border-purple-500/20">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <div>
                <span className="font-serif font-bold text-sm text-slate-100 block">
                  Analysis Complete: {result.features.hand_type} Elemental Signature
                </span>
                <span className="text-[11px] text-slate-400">
                  {result.personality_summary.slice(0, 80)}...
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setResult(null)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs bg-cosmic-950 border border-purple-500/30 text-slate-300 hover:text-white"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Scan Another</span>
              </button>

              <button
                onClick={() => onSendToSynthesis(result.features)}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-serif font-bold gold-gradient-btn text-cosmic-950"
              >
                <span>Synthesize with Cosmic Blueprint</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Grid Layout: Visual Canvas & Detail Drawer */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left: Annotated Hand Canvas Overlay */}
            <div className="lg:col-span-5">
              <HandCanvasOverlay
                imageUrl={result.image_url}
                annotatedImageUrl={result.annotated_image_url}
                features={result.features}
                activeLineKey={activeLineKey}
                onSelectLine={(key) => setActiveLineKey(key)}
              />
            </div>

            {/* Right: Detailed Line Metrics & 7-Category Tab Insights */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Active Line Deep Dive Card */}
              {activeLine && (
                <div className="glass-card rounded-2xl p-5 border border-purple-500/30 space-y-3 shadow-cosmic-glow">
                  <div className="flex items-center justify-between border-b border-purple-500/20 pb-2">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <h4 className="font-serif font-bold text-base text-slate-100">
                        {activeLine.name}
                      </h4>
                    </div>
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-purple-900/60 border border-purple-400/40 text-amber-300">
                      Clarity: {activeLine.clarity_score.toFixed(1)}%
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {activeLine.interpretation}
                  </p>

                  <div className="grid grid-cols-2 gap-3 text-xs pt-1">
                    <div className="bg-cosmic-950/60 p-2.5 rounded-xl border border-purple-900/40">
                      <span className="text-[10px] text-slate-400 uppercase block">Curvature & Flow</span>
                      <span className="text-slate-200 font-medium">{activeLine.curvature}</span>
                    </div>
                    <div className="bg-cosmic-950/60 p-2.5 rounded-xl border border-purple-900/40">
                      <span className="text-[10px] text-slate-400 uppercase block">Depth & Definition</span>
                      <span className="text-slate-200 font-medium">{activeLine.depth}</span>
                    </div>
                  </div>

                  <div>
                    <span className="text-[11px] font-bold text-slate-300 block mb-1">Key Manifested Traits:</span>
                    <div className="flex flex-wrap gap-1.5">
                      {activeLine.key_traits.map((t, idx) => (
                        <span key={idx} className="px-2 py-0.5 rounded-lg text-[10px] bg-indigo-950/70 border border-indigo-500/30 text-indigo-200">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* 7-Category Tabbed Insights */}
              <div className="glass-card rounded-2xl p-5 border border-purple-500/20 space-y-4">
                
                {/* Tabs */}
                <div className="flex flex-wrap gap-2 border-b border-purple-500/20 pb-3">
                  {[
                    { id: 'personality', label: 'Soul Architecture', icon: Brain },
                    { id: 'relationships', label: 'Relational Blueprint', icon: Heart },
                    { id: 'career_and_destiny', label: 'Career & Destiny', icon: Award },
                    { id: 'health_and_vitality', label: 'Health & Prana', icon: Zap }
                  ].map((tab) => {
                    const Icon = tab.icon;
                    const isActive = activeTab === tab.id;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                          isActive 
                            ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-cosmic-glow' 
                            : 'bg-cosmic-950/60 text-slate-400 hover:text-white'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                        <span>{tab.label}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Tab Content */}
                {result.category_insights[activeTab] && (
                  <div className="space-y-3 animate-in fade-in">
                    <h5 className="font-serif font-bold text-sm text-slate-100">
                      {result.category_insights[activeTab].title}
                    </h5>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {result.category_insights[activeTab].summary}
                    </p>

                    <div>
                      <span className="text-[11px] font-bold text-emerald-400 block mb-1">Innate Strengths:</span>
                      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs text-slate-300">
                        {result.category_insights[activeTab].strengths.map((s, i) => (
                          <li key={i} className="flex items-center gap-1.5">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                            <span>{s}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {result.category_insights[activeTab].growth_areas && (
                      <div className="pt-1">
                        <span className="text-[11px] font-bold text-amber-400 block mb-1">Growth Opportunities:</span>
                        <ul className="space-y-1 text-xs text-slate-300">
                          {result.category_insights[activeTab].growth_areas?.map((g, i) => (
                            <li key={i} className="flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                              <span>{g}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}

              </div>

              {/* Dimension Scores Matrix */}
              <ScoreRadar scores={result.dimension_scores} />

            </div>
          </div>

        </div>
      )}

    </div>
  );
};
