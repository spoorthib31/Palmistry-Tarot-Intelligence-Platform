import React, { useState } from 'react';
import { PalmFeatures, PalmLineMetric } from '../types';
import { Eye, Layers, Sparkles } from 'lucide-react';

interface HandCanvasOverlayProps {
  imageUrl?: string;
  annotatedImageUrl?: string;
  features?: PalmFeatures;
  activeLineKey?: string | null;
  onSelectLine?: (key: string) => void;
}

export const HandCanvasOverlay: React.FC<HandCanvasOverlayProps> = ({
  imageUrl,
  annotatedImageUrl,
  features,
  activeLineKey,
  onSelectLine
}) => {
  const [showOriginal, setShowOriginal] = useState<boolean>(false);
  const [hoveredMount, setHoveredMount] = useState<string | null>(null);

  if (!features) {
    return (
      <div className="w-full h-80 rounded-2xl glass-card flex flex-col items-center justify-center text-slate-400 gap-3 border border-purple-500/20">
        <Sparkles className="w-8 h-8 text-purple-400 animate-pulse-slow" />
        <p className="text-sm">Capture or upload your palm to activate the chiromancy overlay.</p>
      </div>
    );
  }

  const lineButtons = [
    { key: 'heart_line', label: 'Heart Line', color: 'bg-rose-500', border: 'border-rose-400' },
    { key: 'head_line', label: 'Head Line', color: 'bg-blue-500', border: 'border-blue-400' },
    { key: 'life_line', label: 'Life Line', color: 'bg-emerald-500', border: 'border-emerald-400' },
    { key: 'fate_line', label: 'Fate Line', color: 'bg-amber-500', border: 'border-amber-400' },
    { key: 'sun_line', label: 'Sun Line', color: 'bg-violet-500', border: 'border-violet-400' },
  ];

  const currentImg = showOriginal && imageUrl ? imageUrl : (annotatedImageUrl || imageUrl);

  return (
    <div className="flex flex-col gap-4">
      {/* Top Controls: Toggle Original vs AI Glow */}
      <div className="flex items-center justify-between gap-2 px-1">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-amber-400" />
            Chiromancy Topography
          </span>
          <span className="px-2 py-0.5 rounded-full text-[10px] bg-purple-900/60 border border-purple-400/30 text-purple-200">
            {features.hand_type} Hand
          </span>
        </div>

        <button
          onClick={() => setShowOriginal(!showOriginal)}
          className="flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs bg-cosmic-900/80 border border-purple-500/30 text-slate-300 hover:text-white hover:border-purple-400 transition-all"
        >
          <Eye className="w-3.5 h-3.5 text-purple-400" />
          <span>{showOriginal ? "Show AI Overlay" : "Show Original"}</span>
        </button>
      </div>

      {/* Main Visual Frame */}
      <div className="relative rounded-2xl overflow-hidden glass-card border border-purple-500/30 aspect-[4/5] max-h-[500px] flex items-center justify-center bg-cosmic-950/80 group">
        {currentImg ? (
          <img
            src={currentImg}
            alt="Analyzed Palm"
            className="w-full h-full object-contain rounded-2xl transition-all duration-500"
          />
        ) : (
          <div className="text-center p-6 text-slate-400">
            <Sparkles className="w-10 h-10 text-amber-400 mx-auto mb-2 animate-bounce" />
            <p className="text-sm">Processing Hand Geometry...</p>
          </div>
        )}

        {/* Floating Element Badge */}
        <div className="absolute top-3 left-3 px-3 py-1.5 rounded-xl bg-cosmic-950/80 backdrop-blur-md border border-purple-400/40 text-xs font-serif text-amber-300 shadow-cosmic-glow">
          Elemental Dominance: {features.dominant_element}
        </div>
      </div>

      {/* Interactive Line Focus Bar */}
      <div className="flex flex-wrap items-center gap-2">
        {lineButtons.map((btn) => {
          const isSelected = activeLineKey === btn.key;
          const lineData: PalmLineMetric | undefined = features.lines[btn.key];
          return (
            <button
              key={btn.key}
              onClick={() => onSelectLine && onSelectLine(btn.key)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                isSelected
                  ? `bg-purple-900/90 text-white ${btn.border} border shadow-cosmic-glow scale-105`
                  : 'bg-cosmic-900/60 text-slate-400 border border-purple-500/20 hover:text-slate-200'
              }`}
            >
              <span className={`w-2.5 h-2.5 rounded-full ${btn.color} animate-pulse`} />
              <span>{btn.label}</span>
              {lineData && (
                <span className="text-[10px] text-purple-300 font-mono">
                  {lineData.clarity_score.toFixed(0)}%
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
