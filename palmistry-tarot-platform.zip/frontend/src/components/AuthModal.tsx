import React, { useState } from 'react';
import { Sparkles, User as UserIcon, Lock, Mail, Shield, Check } from 'lucide-react';
import { apiService } from '../services/api';
import { User } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (user: User) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onAuthSuccess
}) => {
  const [isRegister, setIsRegister] = useState<boolean>(false);
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [fullName, setFullName] = useState<string>('');
  const [role, setRole] = useState<string>('user');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      if (isRegister) {
        const res = await apiService.register(email, password, fullName, role);
        onAuthSuccess(res.user);
      } else {
        const res = await apiService.login(email, password);
        onAuthSuccess(res.user);
      }
      onClose();
    } catch (err: any) {
      setError(err.message || 'Authentication error.');
    } finally {
      setLoading(false);
    }
  };

  const fillDemoAccount = async (demoEmail: string, demoPass: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiService.login(demoEmail, demoPass);
      onAuthSuccess(res.user);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Demo login failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="glass-panel border border-purple-500/30 rounded-3xl max-w-md w-full p-6 text-slate-100 relative shadow-cosmic-glow animate-in fade-in zoom-in-95">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white text-lg font-bold w-8 h-8 rounded-full bg-purple-950/60 flex items-center justify-center border border-purple-400/30"
        >
          ✕
        </button>

        {/* Modal Header */}
        <div className="text-center mb-6">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-600 to-indigo-700 flex items-center justify-center mx-auto mb-3 border border-purple-300/40 shadow-cosmic-glow">
            <Sparkles className="w-6 h-6 text-amber-300 animate-pulse-slow" />
          </div>
          <h3 className="font-serif text-2xl font-bold gold-gradient-text">
            {isRegister ? 'Seeker Initiation' : 'Cosmic Portal Access'}
          </h3>
          <p className="text-xs text-purple-300/70 mt-1">
            {isRegister ? 'Begin your journey of spiritual self-discovery' : 'Enter your credentials to access your soul blueprint'}
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-950/60 border border-rose-500/30 text-rose-300 text-xs">
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {isRegister && (
            <div>
              <label className="text-[11px] text-purple-300 block mb-1">Seeker Name</label>
              <div className="relative">
                <UserIcon className="w-4 h-4 text-purple-400 absolute left-3 top-3" />
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Elena Vance"
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-cosmic-950/80 border border-purple-500/30 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>
          )}

          <div>
            <label className="text-[11px] text-purple-300 block mb-1">Cosmic Email</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-purple-400 absolute left-3 top-3" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seeker@spiritual.ai"
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-cosmic-950/80 border border-purple-500/30 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          <div>
            <label className="text-[11px] text-purple-300 block mb-1">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-purple-400 absolute left-3 top-3" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-cosmic-950/80 border border-purple-500/30 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {isRegister && (
            <div>
              <label className="text-[11px] text-purple-300 block mb-1">Role</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-cosmic-950/80 border border-purple-500/30 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
              >
                <option value="user">Seeker (Personal Readings)</option>
                <option value="spiritual_consultant">Spiritual Consultant / Tarot Reader</option>
              </select>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-xl font-serif font-bold text-xs gold-gradient-btn text-cosmic-950 mt-2 disabled:opacity-50"
          >
            {loading ? 'Consulting the Cosmos...' : isRegister ? 'Complete Initiation' : 'Open Portal'}
          </button>
        </form>

        {/* Toggle Mode */}
        <div className="text-center mt-3">
          <button
            type="button"
            onClick={() => {
              setIsRegister(!isRegister);
              setError(null);
            }}
            className="text-xs text-purple-300 hover:text-amber-300 transition-colors"
          >
            {isRegister ? 'Already an initiated seeker? Log In' : 'New seeker? Begin Initiation'}
          </button>
        </div>

        {/* 1-Click Demo Accounts */}
        <div className="mt-5 pt-4 border-t border-purple-500/20">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider block text-center mb-2.5">
            Quick 1-Click Demo Access
          </span>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => fillDemoAccount('seeker@spiritual.ai', 'seeker123')}
              className="px-3 py-2 rounded-xl bg-purple-950/60 border border-purple-500/30 hover:border-amber-400 text-[11px] text-slate-200 text-left transition-all flex items-center justify-between"
            >
              <div>
                <span className="font-bold text-amber-300 block">Seeker Demo</span>
                <span className="text-[9px] text-slate-400">Elena Vance</span>
              </div>
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            </button>

            <button
              type="button"
              onClick={() => fillDemoAccount('oracle@spiritual.ai', 'oracle123')}
              className="px-3 py-2 rounded-xl bg-indigo-950/60 border border-indigo-500/30 hover:border-amber-400 text-[11px] text-slate-200 text-left transition-all flex items-center justify-between"
            >
              <div>
                <span className="font-bold text-indigo-300 block">Consultant Demo</span>
                <span className="text-[9px] text-slate-400">Master Cassandra</span>
              </div>
              <Shield className="w-3.5 h-3.5 text-indigo-400" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
