import React, { useState } from 'react';
import { TarotCard } from '../types';
import { Sparkles, Info, RotateCw, Flame, Droplets, Wind, Mountain, Moon } from 'lucide-react';
import { cosmicAudio } from '../services/audioSynthesizer';

interface TarotCardViewProps {
  card: TarotCard;
  isReversed?: boolean;
  isFlipped?: boolean;
  positionName?: string;
  positionMeaning?: string;
  onCardClick?: () => void;
  size?: 'sm' | 'md' | 'lg';
}

export const TarotCardView: React.FC<TarotCardViewProps> = ({
  card,
  isReversed = false,
  isFlipped = true,
  positionName,
  positionMeaning,
  onCardClick,
  size = 'md'
}) => {
  const [flipped, setFlipped] = useState<boolean>(isFlipped);
  const [showDetailModal, setShowDetailModal] = useState<boolean>(false);

  const handleFlip = (e: React.MouseEvent) => {
    e.stopPropagation();
    cosmicAudio.playCardFlipSound();
    setFlipped(!flipped);
    if (onCardClick) onCardClick();
  };

  const getElementIcon = (elem?: string) => {
    if (!elem) return <Sparkles className="w-3.5 h-3.5 text-amber-400" />;
    if (elem.includes('Fire')) return <Flame className="w-3.5 h-3.5 text-rose-400" />;
    if (elem.includes('Water')) return <Droplets className="w-3.5 h-3.5 text-cyan-400" />;
    if (elem.includes('Air')) return <Wind className="w-3.5 h-3.5 text-indigo-300" />;
    if (elem.includes('Earth')) return <Mountain className="w-3.5 h-3.5 text-emerald-400" />;
    return <Moon className="w-3.5 h-3.5 text-purple-400" />;
  };

  const dimensions = {
    sm: 'w-36 h-56',
    md: 'w-48 h-72',
    lg: 'w-60 h-92'
  }[size];

  const keywords = isReversed ? card.keywords_reversed : card.keywords_upright;

  return (
    <>
      <div className="flex flex-col items-center gap-2 group">
        
        {/* Position Label above Card */}
        {positionName && (
          <div className="text-center max-w-[200px]">
            <span className="text-xs font-serif font-bold text-amber-300 block truncate">
              {positionName}
            </span>
            {positionMeaning && (
              <span className="text-[10px] text-slate-400 block truncate">
                {positionMeaning}
              </span>
            )}
          </div>
        )}

        {/* 3D Card Container */}
        <div 
          onClick={handleFlip}
          className={`relative ${dimensions} perspective-1000 cursor-pointer select-none transition-transform duration-300 group-hover:scale-105`}
        >
          <div 
            className={`w-full h-full relative transform-style-3d transition-transform duration-700 rounded-2xl shadow-card-3d ${
              flipped ? 'rotate-y-180' : ''
            }`}
          >
            
            {/* CARD BACK */}
            <div className="absolute inset-0 w-full h-full backface-hidden rounded-2xl bg-gradient-to-br from-indigo-950 via-purple-950 to-cosmic-950 border-2 border-amber-400/40 p-3 flex flex-col items-center justify-between overflow-hidden shadow-cosmic-glow">
              <div className="w-full border border-amber-400/20 rounded-xl p-2 flex flex-col items-center justify-center h-full relative">
                {/* Mystic Geometry Pattern */}
                <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:12px_12px]" />
                
                <div className="w-14 h-14 rounded-full border-2 border-amber-400/50 flex items-center justify-center relative">
                  <Sparkles className="w-7 h-7 text-amber-300 animate-spin-slow" />
                </div>
                <span className="font-serif text-[11px] uppercase tracking-widest text-amber-200/80 mt-3 text-center">
                  ARCANUM
                </span>
                <span className="text-[9px] text-purple-300/60 mt-1">Tap to Reveal</span>
              </div>
            </div>

            {/* CARD FRONT */}
            <div className={`absolute inset-0 w-full h-full backface-hidden rotate-y-180 rounded-2xl bg-gradient-to-b from-cosmic-900 via-purple-950 to-cosmic-950 border-2 ${
              isReversed ? 'border-rose-400/60' : 'border-amber-400/60'
            } p-3 flex flex-col justify-between overflow-hidden shadow-gold-glow ${
              isReversed ? 'rotate-180' : ''
            }`}>
              
              {/* Card Header: Element & Astrological note */}
              <div className="flex items-center justify-between text-[10px] text-amber-200/90 font-serif border-b border-amber-400/20 pb-1">
                <span className="flex items-center gap-1 font-bold">
                  {getElementIcon(card.element)}
                  {card.arcana_type === 'major' ? `NO. ${card.number}` : card.suit?.toUpperCase()}
                </span>
                <span className="truncate max-w-[80px] text-slate-300">
                  {card.astrology || card.element}
                </span>
              </div>

              {/* Card Center Graphic / Symbol Representation */}
              <div className="my-auto flex flex-col items-center text-center px-1">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-500/20 to-purple-600/30 border border-amber-400/30 flex items-center justify-center mb-2 shadow-cosmic-glow">
                  <Sparkles className="w-6 h-6 text-amber-300" />
                </div>
                <h4 className="font-serif font-bold text-sm text-slate-100 leading-tight">
                  {card.name}
                </h4>
                {isReversed && (
                  <span className="text-[10px] font-bold text-rose-300 uppercase tracking-widest mt-0.5">
                    (Reversed)
                  </span>
                )}
              </div>

              {/* Card Keywords Footer */}
              <div className="border-t border-amber-400/20 pt-1">
                <div className="flex flex-wrap gap-1 justify-center">
                  {keywords.slice(0, 2).map((kw, i) => (
                    <span 
                      key={i} 
                      className="px-1.5 py-0.5 rounded text-[9px] bg-purple-900/50 border border-purple-400/30 text-amber-200 truncate max-w-[85px]"
                    >
                      {kw}
                    </span>
                  ))}
                </div>
              </div>

            </div>

          </div>
        </div>

        {/* Quick Lore & Inspect Trigger */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            setShowDetailModal(true);
          }}
          className="flex items-center gap-1 text-[11px] text-purple-300 hover:text-amber-300 transition-colors mt-0.5"
        >
          <Info className="w-3 h-3" />
          <span>Esoteric Lore</span>
        </button>

      </div>

      {/* Expanded Esoteric Lore Modal */}
      {showDetailModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="glass-panel border border-amber-500/30 rounded-3xl max-w-lg w-full p-6 text-slate-200 relative shadow-gold-glow animate-in fade-in zoom-in-95">
            
            <button
              onClick={() => setShowDetailModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white text-lg font-bold w-8 h-8 rounded-full bg-purple-950/60 flex items-center justify-center border border-purple-400/30"
            >
              ✕
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <h3 className="font-serif text-xl font-bold text-slate-100">
                  {card.name} {isReversed ? '(Reversed)' : ''}
                </h3>
                <span className="text-xs text-amber-300/80 font-serif">
                  {card.arcana_type.toUpperCase()} ARCANA • {card.element} • {card.astrology}
                </span>
              </div>
            </div>

            <div className="space-y-4 text-xs max-h-[60vh] overflow-y-auto pr-2">
              
              {/* Meaning */}
              <div className="bg-purple-950/40 p-3 rounded-xl border border-purple-500/20">
                <h5 className="font-serif font-bold text-amber-300 mb-1">
                  {isReversed ? "Reversed Meaning" : "Upright Meaning"}
                </h5>
                <p className="text-slate-300 leading-relaxed">
                  {isReversed ? card.description_reversed : card.description_upright}
                </p>
              </div>

              {/* Keywords */}
              <div>
                <span className="font-bold text-slate-300 block mb-1.5">Keywords:</span>
                <div className="flex flex-wrap gap-1.5">
                  {(isReversed ? card.keywords_reversed : card.keywords_upright).map((kw, i) => (
                    <span key={i} className="px-2 py-1 rounded-lg bg-indigo-900/60 border border-indigo-400/30 text-amber-200">
                      {kw}
                    </span>
                  ))}
                </div>
              </div>

              {/* Symbolism */}
              {card.symbolism && (
                <div>
                  <span className="font-bold text-slate-300 block mb-1">Esoteric Symbolism:</span>
                  <p className="text-slate-400 leading-relaxed italic">{card.symbolism}</p>
                </div>
              )}

              {/* Advice */}
              {card.advice && (
                <div className="bg-amber-950/30 p-3 rounded-xl border border-amber-500/30 text-amber-200">
                  <span className="font-serif font-bold text-amber-300 block mb-0.5">Oracle Advice:</span>
                  <p>{card.advice}</p>
                </div>
              )}

            </div>

            <div className="mt-5 text-center">
              <button
                onClick={() => setShowDetailModal(false)}
                className="px-5 py-2 rounded-xl gold-gradient-btn text-cosmic-950 font-bold text-xs"
              >
                Return to Sanctuary
              </button>
            </div>

          </div>
        </div>
      )}
    </>
  );
};
