import React, { useState, useEffect } from 'react';
import { 
  Sparkles, Hand, Layers, Compass, MessageSquareCode, 
  History, Volume2, VolumeX, User as UserIcon, LogOut, Shield, Moon
} from 'lucide-react';
import { User, DailyGuidance } from '../types';
import { cosmicAudio } from '../services/audioSynthesizer';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentUser: User | null;
  onOpenAuth: () => void;
  onLogout: () => void;
  dailyGuidance: DailyGuidance | null;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  onOpenAuth,
  onLogout,
  dailyGuidance
}) => {
  const [isAudioPlaying, setIsAudioPlaying] = useState<boolean>(false);

  const toggleSound = () => {
    const playing = cosmicAudio.toggleAmbient(0.12);
    setIsAudioPlaying(playing);
  };

  const navItems = [
    { id: 'home', label: 'Sanctuary', icon: Sparkles },
    { id: 'palm', label: 'PalmScan AI', icon: Hand },
    { id: 'tarot', label: 'Tarot Oracle', icon: Layers },
    { id: 'synthesis', label: 'Cosmic Blueprint', icon: Compass },
    { id: 'oracle', label: 'Mystic Chamber', icon: MessageSquareCode },
    { id: 'history', label: 'Journal', icon: History },
  ];

  if (currentUser?.role === 'spiritual_consultant' || currentUser?.role === 'admin') {
    navItems.push({ id: 'consultant', label: 'Consultant Studio', icon: Shield });
  }

  return (
    <header className="sticky top-0 z-50 glass-panel border-b border-purple-500/20 px-4 lg:px-8 py-3 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        
        {/* Brand Logo */}
        <div 
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-700 flex items-center justify-center shadow-cosmic-glow group-hover:scale-105 transition-transform border border-purple-300/30">
            <Sparkles className="w-5 h-5 text-amber-300 animate-pulse-slow" />
          </div>
          <div>
            <span className="font-serif font-bold text-lg md:text-xl tracking-wider gold-gradient-text block">
              MYSTIC INTELLIGENCE
            </span>
            <span className="text-[10px] uppercase tracking-widest text-purple-300/70 block">
              AI Palmistry & Tarot Oracle
            </span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="hidden md:flex items-center gap-1 bg-cosmic-900/60 p-1 rounded-2xl border border-purple-500/20 backdrop-blur-md">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  cosmicAudio.playCardFlipSound();
                }}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs lg:text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-purple-600/90 to-indigo-600/90 text-white shadow-cosmic-glow border border-purple-400/30'
                    : 'text-slate-300 hover:text-white hover:bg-purple-950/40'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-300' : 'text-purple-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Side Actions: Planetary Badge, Audio, User */}
        <div className="flex items-center gap-3">
          
          {/* Planetary Hour Badge */}
          {dailyGuidance && (
            <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-full bg-cosmic-900/80 border border-amber-500/30 text-xs">
              <Moon className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-slate-300 font-serif">{dailyGuidance.planetary_hour}</span>
              <span className="text-amber-400 font-bold">({dailyGuidance.rune_symbol})</span>
            </div>
          )}

          {/* Ambient Soundscape Toggle */}
          <button
            onClick={toggleSound}
            title={isAudioPlaying ? "Mute 432Hz Ambient Soundscape" : "Play 432Hz Cosmic Soundscape"}
            className={`p-2.5 rounded-xl border transition-all ${
              isAudioPlaying 
                ? 'bg-amber-500/20 border-amber-400/50 text-amber-300 shadow-gold-glow animate-pulse-slow' 
                : 'bg-cosmic-900/60 border-purple-500/20 text-slate-400 hover:text-purple-300'
            }`}
          >
            {isAudioPlaying ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* User Profile / Auth */}
          {currentUser ? (
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 bg-cosmic-900/70 border border-purple-500/30 rounded-xl px-3 py-1.5">
                <div className="w-6 h-6 rounded-full bg-purple-600 flex items-center justify-center text-xs font-bold text-white">
                  {currentUser.full_name.charAt(0)}
                </div>
                <div className="text-left hidden sm:block">
                  <div className="text-xs font-medium text-slate-200 truncate max-w-[100px]">{currentUser.full_name}</div>
                  <div className="text-[10px] text-purple-300 uppercase">{currentUser.role.replace('_', ' ')}</div>
                </div>
              </div>
              <button
                onClick={onLogout}
                title="Sign Out"
                className="p-2 rounded-xl bg-rose-950/40 border border-rose-500/20 text-rose-400 hover:bg-rose-900/60 hover:text-rose-200 transition-all"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold gold-gradient-btn text-cosmic-950"
            >
              <UserIcon className="w-3.5 h-3.5" />
              <span>Enter Portal</span>
            </button>
          )}

        </div>
      </div>

      {/* Mobile Navigation Sub-Bar */}
      <div className="md:hidden flex items-center justify-around gap-1 mt-2 pt-2 border-t border-purple-500/10 overflow-x-auto pb-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center gap-0.5 px-2.5 py-1 rounded-lg text-[10px] ${
                isActive ? 'text-amber-300 font-bold' : 'text-slate-400'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{item.label.split(' ')[0]}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
