import React from 'react';
import { DimensionScoreItem } from '../types';
import { Sparkles, Activity, ShieldAlert, CheckCircle2 } from 'lucide-react';

interface ScoreRadarProps {
  scores: Record<string, DimensionScoreItem | number>;
  overallScore?: number;
}

export const ScoreRadar: React.FC<ScoreRadarProps> = ({
  scores,
  overallScore
}) => {
  const scoreEntries = Object.entries(scores);

  const getStatusBadge = (scoreVal: number, statusStr?: string) => {
    if (scoreVal >= 85) {
      return (
        <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] bg-emerald-950/60 border border-emerald-500/30 text-emerald-300">
          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
          {statusStr || "Harmonious"}
        </span>
      );
    } else if (scoreVal >= 70) {
      return (
        <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] bg-indigo-950/60 border border-indigo-500/30 text-indigo-300">
          <Activity className="w-3 h-3 text-indigo-400" />
          {statusStr || "Ascending"}
        </span>
      );
    } else {
      return (
        <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] bg-amber-950/60 border border-amber-500/30 text-amber-300">
          <ShieldAlert className="w-3 h-3 text-amber-400" />
          {statusStr || "Active Focus"}
        </span>
      );
    }
  };

  const getBarColor = (scoreVal: number) => {
    if (scoreVal >= 85) return 'from-emerald-500 to-teal-400';
    if (scoreVal >= 70) return 'from-purple-500 to-indigo-400';
    return 'from-amber-500 to-rose-400';
  };

  return (
    <div className="glass-card rounded-2xl p-5 border border-purple-500/20 space-y-4">
      
      {/* Header with Overall Harmony Index */}
      <div className="flex items-center justify-between border-b border-purple-500/20 pb-3">
        <div>
          <h4 className="font-serif font-bold text-slate-100 text-sm flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            7-Dimension Spiritual Energy Matrix
          </h4>
          <span className="text-[11px] text-purple-300/70">
            Algorithmic synthesis of palm lines, tarot archetypes & cosmic dharma
          </span>
        </div>

        {overallScore !== undefined && (
          <div className="text-right">
            <span className="text-xl font-bold font-serif gold-gradient-text">
              {overallScore.toFixed(1)}%
            </span>
            <span className="text-[10px] text-slate-400 block uppercase tracking-wider">
              Harmony Index
            </span>
          </div>
        )}
      </div>

      {/* Dimension Bar List */}
      <div className="space-y-3 pt-1">
        {scoreEntries.map(([key, item]) => {
          const scoreVal = typeof item === 'number' ? item : item.score;
          const nameStr = typeof item === 'number' 
            ? key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) 
            : item.name;
          const statusStr = typeof item === 'number' ? undefined : item.status;
          const descStr = typeof item === 'number' ? undefined : item.description;

          return (
            <div key={key} className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-slate-200">{nameStr}</span>
                <div className="flex items-center gap-2">
                  {getStatusBadge(scoreVal, statusStr)}
                  <span className="font-mono font-bold text-slate-100">{scoreVal.toFixed(1)}%</span>
                </div>
              </div>

              {/* Progress Bar with Glow */}
              <div className="w-full h-2 rounded-full bg-cosmic-950 overflow-hidden border border-purple-900/40">
                <div
                  className={`h-full rounded-full bg-gradient-to-r ${getBarColor(scoreVal)} transition-all duration-1000`}
                  style={{ width: `${Math.min(100, Math.max(10, scoreVal))}%` }}
                />
              </div>

              {descStr && (
                <p className="text-[10px] text-slate-400 italic truncate">
                  {descStr}
                </p>
              )}
            </div>
          );
        })}
      </div>

    </div>
  );
};
