import React from 'react';
import { Sparkles, Compass, ShieldCheck } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="glass-panel border-t border-purple-500/20 py-8 px-4 lg:px-8 mt-16 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-purple-900/60 border border-purple-400/30 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-amber-400" />
          </div>
          <div>
            <div className="font-serif font-semibold text-slate-200 text-sm">
              Palmistry & Tarot Intelligence Platform
            </div>
            <div className="text-[11px] text-purple-300/70">
              Personalized Spiritual Insights & Multi-Modal Chiromancy
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6 text-slate-400">
          <span className="flex items-center gap-1.5 hover:text-slate-200 transition-colors">
            <Compass className="w-3.5 h-3.5 text-purple-400" /> 78-Card Rider-Waite DB
          </span>
          <span className="flex items-center gap-1.5 hover:text-slate-200 transition-colors">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Hermetic Privacy
          </span>
          <span className="hover:text-amber-300 transition-colors">
            432Hz Harmonic Engine
          </span>
        </div>

        <div className="text-[11px] text-slate-500 text-center md:text-right">
          © 2026 Mystic Intelligence. Built for Self-Discovery & Spiritual Evolution.
        </div>
      </div>
    </footer>
  );
};
