export interface UserProfile {
  age_group?: string;
  interests?: string[];
  spiritual_goals?: string[];
  reading_preferences?: {
    preferred_spread?: string;
    deck_theme?: string;
    zodiac_sign?: string;
    birth_date?: string;
    life_path_number?: number;
    detailed_analysis?: boolean;
  };
  bio?: string;
  avatar_url?: string;
}

export interface User {
  id: number;
  email: string;
  full_name: string;
  role: 'user' | 'tarot_reader' | 'spiritual_consultant' | 'admin';
  is_active: boolean;
  profile?: UserProfile;
}

export interface PalmLineMetric {
  name: string;
  length: number;
  depth: string;
  curvature: string;
  clarity_score: number;
  start_point: [number, number];
  end_point: [number, number];
  interpretation: string;
  key_traits: string[];
}

export interface PalmMount {
  name: string;
  location: string;
  development: string;
  associated_planet: string;
  energy: string;
  prominence_score: number;
}

export interface PalmFeatures {
  hand_type: string;
  hand_type_desc: string;
  palm_shape: string;
  finger_ratios: {
    index_to_ring: number;
    middle_to_palm: number;
    thumb_angle: number;
  };
  lines: Record<string, PalmLineMetric>;
  mounts: Record<string, PalmMount>;
  special_marks: Array<{ name: string; location: string; meaning: string }>;
  dominant_element: string;
}

export interface PalmAnalysisResult {
  status: string;
  message: string;
  image_url?: string;
  annotated_image_url?: string;
  features: PalmFeatures;
  personality_summary: string;
  dimension_scores: Record<string, number>;
  category_insights: Record<string, {
    title: string;
    summary: string;
    strengths: string[];
    growth_areas?: string[];
  }>;
}

export interface TarotCard {
  id: number;
  card_id: string;
  name: string;
  arcana_type: 'major' | 'minor';
  suit?: 'wands' | 'cups' | 'swords' | 'pentacles' | null;
  number: number;
  image_url?: string;
  element?: string;
  astrology?: string;
  keywords_upright: string[];
  keywords_reversed: string[];
  description_upright: string;
  description_reversed: string;
  advice?: string;
  symbolism?: string;
}

export interface DrawnCard {
  card: TarotCard;
  position_index: number;
  position_name: string;
  position_meaning: string;
  is_reversed: boolean;
  context_reading: string;
}

export interface TarotSpreadResult {
  spread_name: string;
  question: string;
  drawn_cards: DrawnCard[];
  holistic_interpretation: string;
  dominant_element: string;
  energy_focus: string;
  dimension_scores: Record<string, number>;
  actionable_advice: string[];
}

export interface DimensionScoreItem {
  name: string;
  score: number;
  category: string;
  description: string;
  status: string;
}

export interface SynthesisResult {
  reading_id?: number;
  title: string;
  seeker_name: string;
  astrological_profile: {
    zodiac_sign: string;
    element: string;
    ruling_planet: string;
    cosmic_motto: string;
    archetype: string;
    summary: string;
  };
  numerology_profile: {
    life_path_number: number;
    title: string;
    core_lesson: string;
  };
  palm_synthesis: {
    hand_type: string;
    hand_type_desc: string;
    lines: Record<string, PalmLineMetric>;
  };
  tarot_synthesis: {
    spread_name: string;
    holistic_interpretation: string;
    drawn_cards: DrawnCard[];
  };
  unified_dossier: string;
  dimension_scores: Record<string, DimensionScoreItem>;
  overall_harmony_score: number;
  life_category_guidance: {
    top_strength: DimensionScoreItem;
    growth_focus: DimensionScoreItem;
  };
  personalized_rituals: Array<{
    title: string;
    duration: string;
    instructions: string;
    purpose: string;
  }>;
  recommended_crystals: Array<{
    name: string;
    purpose: string;
  }>;
  affirmations: string[];
  pdf_download_url?: string;
}

export interface DailyGuidance {
  date: string;
  planetary_hour: string;
  dominant_planet: string;
  rune_symbol: string;
  rune_name: string;
  rune_meaning: string;
  daily_card: TarotCard;
  cosmic_affirmation: string;
  meditation_focus: string;
  lucky_colors: string[];
  lucky_numbers: number[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  audio_url?: string;
}

export interface ReadingSummary {
  id: number;
  user_id: number;
  reading_type: 'palm' | 'tarot' | 'synthesized_holistic';
  status: string;
  title: string;
  overall_score: number;
  created_at: string;
  user_name?: string;
}
