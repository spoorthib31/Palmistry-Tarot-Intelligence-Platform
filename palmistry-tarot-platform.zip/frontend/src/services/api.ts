import {
  User, PalmAnalysisResult, TarotCard, TarotSpreadResult,
  SynthesisResult, DailyGuidance, ReadingSummary, ChatMessage
} from '../types';

const API_BASE = '/api';

class ApiService {
  private token: string | null = null;

  constructor() {
    this.token = localStorage.getItem('cosmic_token');
  }

  setToken(token: string | null) {
    this.token = token;
    if (token) {
      localStorage.setItem('cosmic_token', token);
    } else {
      localStorage.removeItem('cosmic_token');
    }
  }

  getToken(): string | null {
    return this.token;
  }

  private getHeaders(isJson: boolean = true): HeadersInit {
    const headers: HeadersInit = {};
    if (isJson) {
      headers['Content-Type'] = 'application/json';
    }
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }
    return headers;
  }

  // Auth
  async login(email: string, password: string): Promise<{ access_token: string; user: User }> {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: this.getHeaders(true),
      body: JSON.stringify({ email, password })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Failed to authenticate.' }));
      throw new Error(err.detail || 'Login failed.');
    }
    const data = await res.json();
    this.setToken(data.access_token);
    return data;
  }

  async register(email: string, password: string, fullName: string, role: string = 'user'): Promise<{ access_token: string; user: User }> {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: this.getHeaders(true),
      body: JSON.stringify({ email, password, full_name: fullName, role })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Registration failed.' }));
      throw new Error(err.detail || 'Registration failed.');
    }
    const data = await res.json();
    this.setToken(data.access_token);
    return data;
  }

  async getMe(): Promise<User> {
    const res = await fetch(`${API_BASE}/auth/me`, {
      headers: this.getHeaders(true)
    });
    if (!res.ok) throw new Error('Session expired.');
    return res.json();
  }

  // Palmistry
  async analyzePalmFile(file: File, handSide: string = 'dominant_right'): Promise<PalmAnalysisResult> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('hand_side', handSide);

    const res = await fetch(`${API_BASE}/palm/analyze`, {
      method: 'POST',
      headers: this.getHeaders(false),
      body: formData
    });
    if (!res.ok) throw new Error('Palm analysis failed.');
    return res.json();
  }

  async analyzePalmBase64(base64: string, handSide: string = 'dominant_right'): Promise<PalmAnalysisResult> {
    const formData = new FormData();
    formData.append('image_base64', base64);
    formData.append('hand_side', handSide);

    const res = await fetch(`${API_BASE}/palm/analyze`, {
      method: 'POST',
      headers: this.getHeaders(false),
      body: formData
    });
    if (!res.ok) throw new Error('Webcam palm analysis failed.');
    return res.json();
  }

  async getSamplePalm(): Promise<PalmAnalysisResult> {
    const res = await fetch(`${API_BASE}/palm/sample`);
    if (!res.ok) throw new Error('Failed to load sample palm.');
    return res.json();
  }

  // Tarot
  async getTarotCards(): Promise<TarotCard[]> {
    const res = await fetch(`${API_BASE}/tarot/cards`);
    if (!res.ok) throw new Error('Failed to fetch tarot catalog.');
    return res.json();
  }

  async drawSpread(spreadType: string, question: string): Promise<TarotSpreadResult> {
    const res = await fetch(`${API_BASE}/tarot/spread`, {
      method: 'POST',
      headers: this.getHeaders(true),
      body: JSON.stringify({ spread_type: spreadType, question })
    });
    if (!res.ok) throw new Error('Failed to draw tarot spread.');
    return res.json();
  }

  // Spiritual Synthesis
  async generateSynthesis(payload: {
    palm_features?: any;
    tarot_spread?: any;
    zodiac_sign?: string;
    life_path_number?: number;
    spiritual_question?: string;
  }): Promise<SynthesisResult> {
    const res = await fetch(`${API_BASE}/synthesis/generate`, {
      method: 'POST',
      headers: this.getHeaders(true),
      body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error('Spiritual synthesis generation failed.');
    return res.json();
  }

  // Oracle
  async chatWithOracle(message: string, history: ChatMessage[], context?: any, geminiKey?: string): Promise<{ reply: string; suggested_questions: string[]; audio_tts_url?: string }> {
    const res = await fetch(`${API_BASE}/oracle/chat`, {
      method: 'POST',
      headers: this.getHeaders(true),
      body: JSON.stringify({
        message,
        conversation_history: history.map(h => ({ role: h.role, content: h.content, timestamp: h.timestamp })),
        context,
        custom_gemini_key: geminiKey
      })
    });
    if (!res.ok) throw new Error('Oracle communication failed.');
    return res.json();
  }

  async getDailyGuidance(): Promise<DailyGuidance> {
    const res = await fetch(`${API_BASE}/oracle/daily`);
    if (!res.ok) throw new Error('Failed to fetch daily guidance.');
    return res.json();
  }

  // Readings
  async getReadings(): Promise<ReadingSummary[]> {
    const res = await fetch(`${API_BASE}/readings`, {
      headers: this.getHeaders(true)
    });
    if (!res.ok) throw new Error('Failed to load readings history.');
    return res.json();
  }

  async getReadingDetail(id: number): Promise<any> {
    const res = await fetch(`${API_BASE}/readings/${id}`, {
      headers: this.getHeaders(true)
    });
    if (!res.ok) throw new Error('Failed to load reading details.');
    return res.json();
  }

  async updateReadingNotes(id: number, readerNotes?: string, feedback?: string, rating?: number): Promise<any> {
    const res = await fetch(`${API_BASE}/readings/${id}/notes`, {
      method: 'PUT',
      headers: this.getHeaders(true),
      body: JSON.stringify({
        reader_notes: readerNotes,
        client_feedback: feedback,
        rating: rating
      })
    });
    if (!res.ok) throw new Error('Failed to update notes.');
    return res.json();
  }

  async deleteReading(id: number): Promise<any> {
    const res = await fetch(`${API_BASE}/readings/${id}`, {
      method: 'DELETE',
      headers: this.getHeaders(true)
    });
    if (!res.ok) throw new Error('Failed to delete reading.');
    return res.json();
  }
}

export const apiService = new ApiService();
