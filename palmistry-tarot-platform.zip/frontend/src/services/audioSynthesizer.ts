class CosmicAudioSynthesizer {
  private ctx: AudioContext | null = null;
  private isPlayingAmbient: boolean = false;
  private ambientGain: GainNode | null = null;
  private oscillators: OscillatorNode[] = [];

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  // Play ambient 432Hz & 528Hz cosmic harmonic drone
  startAmbientSoundscape(volume: number = 0.15) {
    this.initContext();
    if (!this.ctx || this.isPlayingAmbient) return;

    try {
      this.ambientGain = this.ctx.createGain();
      this.ambientGain.gain.setValueAtTime(0.001, this.ctx.currentTime);
      this.ambientGain.gain.exponentialRampToValueAtTime(volume, this.ctx.currentTime + 3);
      this.ambientGain.connect(this.ctx.destination);

      // 432Hz fundamental drone (Sacred Natural Frequency)
      const osc1 = this.ctx.createOscillator();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(432, this.ctx.currentTime);

      // 528Hz Solfeggio Transformation Tone (Harmony & Miracle)
      const osc2 = this.ctx.createOscillator();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(528, this.ctx.currentTime);

      // 108Hz Sub-bass root chakra grounding tone
      const osc3 = this.ctx.createOscillator();
      osc3.type = 'triangle';
      osc3.frequency.setValueAtTime(108, this.ctx.currentTime);

      // Stereo panner if supported
      const panner1 = this.ctx.createStereoPanner ? this.ctx.createStereoPanner() : null;
      if (panner1) panner1.pan.setValueAtTime(-0.4, this.ctx.currentTime);

      const gain1 = this.ctx.createGain();
      gain1.gain.setValueAtTime(0.4, this.ctx.currentTime);
      const gain2 = this.ctx.createGain();
      gain2.gain.setValueAtTime(0.3, this.ctx.currentTime);
      const gain3 = this.ctx.createGain();
      gain3.gain.setValueAtTime(0.3, this.ctx.currentTime);

      osc1.connect(gain1);
      osc2.connect(gain2);
      osc3.connect(gain3);

      gain1.connect(this.ambientGain);
      gain2.connect(this.ambientGain);
      gain3.connect(this.ambientGain);

      osc1.start();
      osc2.start();
      osc3.start();

      this.oscillators = [osc1, osc2, osc3];
      this.isPlayingAmbient = true;
    } catch (e) {
      console.warn('Web Audio Ambient Drone could not start:', e);
    }
  }

  stopAmbientSoundscape() {
    if (!this.ctx || !this.isPlayingAmbient || !this.ambientGain) return;

    try {
      this.ambientGain.gain.setValueAtTime(this.ambientGain.gain.value, this.ctx.currentTime);
      this.ambientGain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 1.5);
      
      setTimeout(() => {
        this.oscillators.forEach(osc => {
          try { osc.stop(); osc.disconnect(); } catch (_) {}
        });
        this.oscillators = [];
        this.isPlayingAmbient = false;
      }, 1600);
    } catch (e) {
      this.isPlayingAmbient = false;
    }
  }

  toggleAmbient(volume: number = 0.15): boolean {
    if (this.isPlayingAmbient) {
      this.stopAmbientSoundscape();
      return false;
    } else {
      this.startAmbientSoundscape(volume);
      return true;
    }
  }

  getIsPlaying(): boolean {
    return this.isPlayingAmbient;
  }

  // Play Tibetan Crystal Singing Bowl Strike Chime
  playTibetanChime(freq: number = 528) {
    this.initContext();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

      // Bell envelope
      gain.gain.setValueAtTime(0.001, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.25, this.ctx.currentTime + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 3.2);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + 3.3);
    } catch (_) {}
  }

  // Play Tarot Card Swoosh & Reveal Sound
  playCardFlipSound() {
    this.initContext();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, this.ctx.currentTime + 0.15);

      gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.2);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.22);
    } catch (_) {}
  }
}

export const cosmicAudio = new CosmicAudioSynthesizer();
