import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { AuthModal } from './components/AuthModal';
import { HomePortal } from './views/HomePortal';
import { PalmScanStudio } from './views/PalmScanStudio';
import { TarotSanctuary } from './views/TarotSanctuary';
import { SpiritualBlueprint } from './views/SpiritualBlueprint';
import { OracleChamber } from './views/OracleChamber';
import { JournalHistory } from './views/JournalHistory';
import { ConsultantStudio } from './views/ConsultantStudio';
import { apiService } from './services/api';
import { User, DailyGuidance, PalmAnalysisResult, TarotSpreadResult, PalmFeatures } from './types';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [dailyGuidance, setDailyGuidance] = useState<DailyGuidance | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  // Cached readings in active session
  const [cachedPalmResult, setCachedPalmResult] = useState<PalmAnalysisResult | null>(null);
  const [cachedPalmFeatures, setCachedPalmFeatures] = useState<PalmFeatures | null>(null);
  const [cachedTarotSpread, setCachedTarotSpread] = useState<TarotSpreadResult | null>(null);

  useEffect(() => {
    // 1. Fetch daily planetary & tarot guidance
    apiService.getDailyGuidance()
      .then(setDailyGuidance)
      .catch((e) => console.warn('Could not fetch daily guidance:', e));

    // 2. Check existing auth session
    if (apiService.getToken()) {
      apiService.getMe()
        .then(setCurrentUser)
        .catch(() => apiService.setToken(null));
    }
  }, []);

  const handleLogout = () => {
    apiService.setToken(null);
    setCurrentUser(null);
    setActiveTab('home');
  };

  const handleSendPalmToSynthesis = (features: PalmFeatures) => {
    setCachedPalmFeatures(features);
    setActiveTab('synthesis');
  };

  const handleSendTarotToSynthesis = (spread: TarotSpreadResult) => {
    setCachedTarotSpread(spread);
    setActiveTab('synthesis');
  };

  return (
    <div className="min-h-screen flex flex-col justify-between selection:bg-purple-600 selection:text-white">
      
      {/* Cosmic Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onLogout={handleLogout}
        dailyGuidance={dailyGuidance}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 lg:px-8 py-8">
        {activeTab === 'home' && (
          <HomePortal
            onNavigate={(tab) => setActiveTab(tab)}
            dailyGuidance={dailyGuidance}
          />
        )}

        {activeTab === 'palm' && (
          <PalmScanStudio
            onSendToSynthesis={handleSendPalmToSynthesis}
            cachedResult={cachedPalmResult}
          />
        )}

        {activeTab === 'tarot' && (
          <TarotSanctuary
            onSendToSynthesis={handleSendTarotToSynthesis}
            cachedSpread={cachedTarotSpread}
          />
        )}

        {activeTab === 'synthesis' && (
          <SpiritualBlueprint
            palmFeatures={cachedPalmFeatures}
            tarotSpread={cachedTarotSpread}
            onNavigateToPalm={() => setActiveTab('palm')}
            onNavigateToTarot={() => setActiveTab('tarot')}
          />
        )}

        {activeTab === 'oracle' && (
          <OracleChamber
            palmFeatures={cachedPalmFeatures}
            tarotSpread={cachedTarotSpread}
            zodiacSign={currentUser?.profile?.reading_preferences?.zodiac_sign || "Scorpio"}
          />
        )}

        {activeTab === 'history' && (
          <JournalHistory
            currentUser={currentUser}
            onOpenAuth={() => setIsAuthModalOpen(true)}
          />
        )}

        {activeTab === 'consultant' && (
          <ConsultantStudio
            currentUser={currentUser}
          />
        )}
      </main>

      {/* Cosmic Platform Footer */}
      <Footer />

      {/* Auth / Initiation Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onAuthSuccess={(user) => setCurrentUser(user)}
      />

    </div>
  );
};

export default App;
