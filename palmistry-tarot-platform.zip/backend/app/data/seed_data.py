import json
from pathlib import Path
from sqlalchemy.orm import Session
from app.models.user import User, UserProfile, UserRole
from app.models.tarot_card import TarotCard
from app.models.reading import Reading, ReadingType, ReadingStatus
from app.models.notification import Notification, NotificationType
from app.services.auth_service import get_password_hash

DATA_DIR = Path(__file__).resolve().parent

def seed_database(db: Session):
    # 1. Seed Tarot Cards
    cards_file = DATA_DIR / "tarot_cards.json"
    if cards_file.exists():
        with open(cards_file, "r", encoding="utf-8") as f:
            cards_data = json.load(f)
            
        existing_count = db.query(TarotCard).count()
        if existing_count < len(cards_data):
            for c in cards_data:
                existing = db.query(TarotCard).filter(TarotCard.card_id == c["card_id"]).first()
                if not existing:
                    card = TarotCard(
                        card_id=c["card_id"],
                        name=c["name"],
                        arcana_type=c["arcana_type"],
                        suit=c.get("suit"),
                        number=c["number"],
                        image_url=c.get("image_url"),
                        element=c.get("element"),
                        astrology=c.get("astrology"),
                        keywords_upright=c.get("keywords_upright", []),
                        keywords_reversed=c.get("keywords_reversed", []),
                        description_upright=c["description_upright"],
                        description_reversed=c["description_reversed"],
                        advice=c.get("advice"),
                        symbolism=c.get("symbolism"),
                    )
                    db.add(card)
            db.commit()

    # 2. Seed Default Users
    # Seeker User
    seeker = db.query(User).filter(User.email == "seeker@spiritual.ai").first()
    if not seeker:
        seeker = User(
            email="seeker@spiritual.ai",
            hashed_password=get_password_hash("seeker123"),
            full_name="Elena Vance",
            role=UserRole.USER.value,
            is_active=True
        )
        db.add(seeker)
        db.flush()

        seeker_profile = UserProfile(
            user_id=seeker.id,
            age_group="28",
            interests=["Tarot", "Vedic Palmistry", "Astrology", "Sacred Geometry"],
            spiritual_goals=["Deepen Intuition", "Align Career with Soul Purpose", "Inner Peace"],
            reading_preferences={
                "preferred_spread": "celtic_cross",
                "deck_theme": "rider_waite",
                "zodiac_sign": "Scorpio",
                "birth_date": "1997-11-08",
                "life_path_number": 9
            },
            bio="Intuitive artist and seeker exploring the intersection of consciousness, tarot, and chiromancy.",
            avatar_url="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80"
        )
        db.add(seeker_profile)

        # Add initial welcome notification
        welcome_note = Notification(
            user_id=seeker.id,
            title="Welcome to the Sanctuary",
            message="Your cosmic portal is active. Scan your palm or draw from the 78-card deck to begin your spiritual synthesis.",
            notification_type=NotificationType.PLATFORM_ANNOUNCEMENT.value,
            is_read=False
        )
        db.add(welcome_note)

    # Consultant / Reader User
    consultant = db.query(User).filter(User.email == "oracle@spiritual.ai").first()
    if not consultant:
        consultant = User(
            email="oracle@spiritual.ai",
            hashed_password=get_password_hash("oracle123"),
            full_name="Master Cassandra Sol",
            role=UserRole.SPIRITUAL_CONSULTANT.value,
            is_active=True
        )
        db.add(consultant)
        db.flush()

        consultant_profile = UserProfile(
            user_id=consultant.id,
            age_group="40+",
            interests=["Esoteric Hermeticism", "Master Palmistry", "Tarot Alchemy", "Kundalini"],
            spiritual_goals=["Guide Seekers", "Synthesize Ancient & AI Wisdom"],
            reading_preferences={
                "preferred_spread": "celtic_cross",
                "deck_theme": "rider_waite",
                "detailed_analysis": True
            },
            bio="Grand Mystic & High Priestess with 20+ years in esoteric chiromancy and archetypal tarot synthesis.",
            avatar_url="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80"
        )
        db.add(consultant_profile)

    db.commit()
