import json
from pathlib import Path

def generate_tarot_dataset():
    cards = []
    
    # 22 Major Arcana
    major_arcana_data = [
        (0, "the_fool", "The Fool", "Air", "Uranus", 
         ["Beginnings", "Innocence", "Spontaneity", "Free Spirit", "Leap of Faith"],
         ["Recklessness", "Risk-taking", "Inconsideration", "Hesitation", "Naivety"],
         "The Fool represents new beginnings, pure potential, and the courage to step into the unknown with an open heart. You are at the start of a profound spiritual odyssey.",
         "Reversed, The Fool cautions against impulsive folly, reckless gambles, or conversely, being paralyzed by the fear of taking a necessary leap.",
         "Trust the universe and take the first step, but look before you leap.",
         "The white dog symbolizes loyalty and protection, the cliff edge represents the threshold between mundane reality and infinite cosmic opportunity."),
        
        (1, "the_magician", "The Magician", "Fire / Air", "Mercury",
         ["Manifestation", "Resourcefulness", "Power", "Inspired Action", "Skill"],
         ["Illusion", "Manipulation", "Untapped Potential", "Wasted Talent", "Trickery"],
         "The Magician holds mastery over the four sacred elements (Wand, Cup, Sword, Pentacle). As above, so below: you have all the tools required to manifest your highest desires into physical reality.",
         "Reversed, warns of deceptive intentions, smoke and mirrors, or frustration from failing to channel your creative energy effectively.",
         "Align your willpower with divine purpose; focus your energy without distraction.",
         "The infinity symbol (lemniscate) above the head represents boundless mental mastery and infinite cosmic connection."),

        (2, "the_high_priestess", "The High Priestess", "Water", "Moon",
         ["Intuition", "Sacred Knowledge", "Divine Feminine", "Subconscious", "Mystery"],
         ["Secrets", "Disconnected from Intuition", "Withdrawal", "Silence", "Superficiality"],
         "The High Priestess sits at the veil between the conscious and subconscious realms. She invites you to look beyond the veil, trust your inner knowing, and heed your dreams.",
         "Reversed, signals an ignored gut feeling, suppressed secrets, or being disconnected from your intuitive inner voice.",
         "Be still and listen to the whispers of your soul; not everything must be answered with logic.",
         "The twin pillars Boaz (black) and Jachin (white) symbolize the duality of light and shadow, the pomegranates signify spiritual fertility."),

        (3, "the_empress", "The Empress", "Earth", "Venus",
         ["Abundance", "Fertility", "Nurturing", "Creativity", "Sensuality", "Nature"],
         ["Creative Block", "Dependence", "Smothering", "Emptiness", "Disharmony"],
         "The Empress is the archetype of mother nature, unconditional love, creative fruitfulness, and luxurious abundance. Everything you cultivate now is destined to flourish.",
         "Reversed, indicates creative depletion, neglect of self-care, or overbearing maternal/relational dynamics.",
         "Nurture your body and creations with gentleness; immerse yourself in the beauty of nature.",
         "The crown of twelve twelve-pointed stars represents dominion over the celestial cycles of the zodiac."),

        (4, "the_emperor", "The Emperor", "Fire", "Aries",
         ["Authority", "Structure", "Stability", "Leadership", "Discipline", "Protection"],
         ["Tyranny", "Rigidity", "Lack of Discipline", "Abuse of Power", "Chaos"],
         "The Emperor embodies divine masculine order, architectural vision, strategic discipline, and sovereign leadership. He brings structure to chaos.",
         "Reversed, suggests domineering control, stubborn inflexibility, or an unstable foundation requiring urgent boundary setting.",
         "Establish clear boundaries and organize your empire with wisdom and steady resolve.",
         "The stone throne adorned with ram heads symbolizes fiery determination, authority, and unbreakable mental fortitude."),

        (5, "the_hierophant", "The Hierophant", "Earth", "Taurus",
         ["Spiritual Wisdom", "Tradition", "Mentorship", "Institutions", "Sacred Knowledge"],
         ["Rebellion", "Dogma", "Non-conformity", "New Approaches", "Spiritual Hypocrisy"],
         "The Hierophant is the bridge between the heavenly realm and earthly community, representing esoteric lineage, sacred rites, and trusted guidance.",
         "Reversed, indicates questioning outdated dogma, carving your own spiritual path, and breaking free from restrictive traditions.",
         "Honor time-tested wisdom while seeking authentic teachers who empower your inner sovereign truth.",
         "The triple cross staff represents dominion over physical, intellectual, and spiritual planes."),

        (6, "the_lovers", "The Lovers", "Air", "Gemini",
         ["Love", "Harmony", "Soul Connection", "Values Alignment", "Choice"],
         ["Disharmony", "Imbalance", "Misaligned Values", "Conflict", "Indecision"],
         "The Lovers signifies profound emotional union, authentic vulnerability, soulmate synergy, and crucial choices made in alignment with your moral compass.",
         "Reversed, points to relationship tension, internal conflict of values, or choosing short-term gratification over soul integrity.",
         "Choose from love rather than fear; ensure your partnerships reflect your core spiritual truths.",
         "Archangel Raphael blesses the sacred union beneath the Tree of Life and Tree of Knowledge."),

        (7, "the_chariot", "The Chariot", "Water", "Cancer",
         ["Determination", "Willpower", "Victory", "Focus", "Overcoming Obstacles"],
         ["Lack of Direction", "Aggression", "Loss of Control", "Obstacles", "Powerlessness"],
         "The Chariot heralds triumph through resolute focus, self-mastery, and balancing opposing forces into a unified forward momentum.",
         "Reversed, warns of reckless impulsivity, feeling steamrolled by external circumstances, or spinning wheels without traction.",
         "Harness your dual emotions and drive straight toward your highest goal with unwavering discipline.",
         "The black and white sphinxes pulling the chariot represent opposing instinctual forces brought into harmony by pure willpower."),

        (8, "strength", "Strength", "Fire", "Leo",
         ["Courage", "Compassion", "Inner Power", "Patience", "Gentle Mastery"],
         ["Self-Doubt", "Raw Emotion", "Weakness", "Impatience", "Forcefulness"],
         "Strength demonstrates that true power is not brute force, but gentle compassion, patience, and love subduing the wildest instincts.",
         "Reversed, indicates vulnerability to self-criticism, explosive anger, or forgetting your innate inner resilience.",
         "Tame difficult situations with calm understanding and grace rather than aggressive confrontation.",
         "The maiden gently closing the lion's jaws while the infinity symbol hovers over her head illustrates love mastering primal passion."),

        (9, "the_hermit", "The Hermit", "Earth", "Virgo",
         ["Soul Searching", "Introspection", "Solitude", "Inner Guidance", "Enlightenment"],
         ["Isolation", "Loneliness", "Withdrawal", "Lost Path", "Over-Analysis"],
         "The Hermit ascends the cosmic mountain alone to illuminate truth. This is a sacred period of introspection, meditation, and seeking inner light.",
         "Reversed, indicates harmful isolation, refusing to seek help, or becoming lost in obsessive cynicism.",
         "Step back from the noise of the world and seek guidance within your own sacred silence.",
         "The lantern containing a six-pointed star represents the Light of Truth guiding seekers through spiritual darkness."),

        (10, "wheel_of_fortune", "Wheel of Fortune", "Fire", "Jupiter",
         ["Destiny", "Karma", "Cycles of Life", "Turning Point", "Good Luck"],
         ["Bad Luck", "Resistance to Change", "Breaking Cycles", "Setbacks"],
         "The Wheel turns eternally, reminding us that life moves in sacred cycles. A karmic turning point is at hand, bringing sudden breakthrough and divine synchronicity.",
         "Reversed, advises accepting inevitable fluctuations and realizing that resisting change only prolongs setbacks.",
         "Embrace life's cyclical rhythm with humility; what goes down must soon rise up.",
         "The four fixed astrological signs (Man/Aquarius, Eagle/Scorpio, Lion/Leo, Bull/Taurus) anchor the spinning wheel in cosmic law."),

        (11, "justice", "Justice", "Air", "Libra",
         ["Fairness", "Truth", "Karma", "Accountability", "Clarity"],
         ["Dishonesty", "Unfairness", "Lack of Accountability", "Bias", "Legal Snags"],
         "Justice wields the double-edged sword of truth and the balanced scales of karmic equilibrium. All actions produce equal reverberations across time.",
         "Reversed, indicates injustice, evasion of personal responsibility, or unfair blame requiring objective reflection.",
         "Act with total integrity and speak truth with unbiased fairness.",
         "The upright double-edged sword cuts through illusion while the golden scales weigh deeds against universal law."),

        (12, "the_hanged_man", "The Hanged Man", "Water", "Neptune",
         ["Surrender", "New Perspective", "Letting Go", "Pause", "Spiritual Enlightenment"],
         ["Delays", "Resistance", "Martyrdom", "Stagnation", "Futile Sacrifice"],
         "The Hanged Man suspends himself willingly from the World Tree to gain illuminated insight. Surrendering control births profound spiritual breakthroughs.",
         "Reversed, warns against playing the martyr or resisting a necessary period of rest and perspective shift.",
         "Release your need to control outcomes; look at the situation completely upside down.",
         "The golden halo around his head signifies mystical illumination gained through selfless contemplation."),

        (13, "death", "Death", "Water", "Scorpio",
         ["Transformation", "Endings", "New Beginnings", "Rebirth", "Metamorphosis"],
         ["Fear of Change", "Holding On", "Stagnation", "Decay", "Resistance"],
         "Death is the sacred harbinger of profound rebirth. An old chapter, habit, or identity is dissolving to make way for radiant new beginnings.",
         "Reversed, points to clinging onto dead patterns, fear of the unknown, or resisting a natural transformation.",
         "Gracefully let go of what no longer serves your soul; welcome the fertile dawn of transformation.",
         "The black banner with the mystic white rose signifies purity, immortality, and perpetual renewal after darkness."),

        (14, "temperance", "Temperance", "Fire", "Sagittarius",
         ["Balance", "Moderation", "Alchemy", "Patience", "Divine Purpose"],
         ["Imbalance", "Excess", "Extremes", "Lack of Patience", "Discord"],
         "The angel of Temperance mixes the dual waters of spirit and matter with effortless grace, symbolizing inner peace, moderation, and spiritual alchemy.",
         "Reversed, signals overindulgence, burning out from extremes, or emotional volatility.",
         "Seek the middle path; blend opposing elements of your life into harmonious synergy.",
         "One foot on land and one in water illustrates grounding spiritual insights into tangible reality."),

        (15, "the_devil", "The Devil", "Earth", "Capricorn",
         ["Shadow Self", "Attachment", "Addiction", "Illusion of Limitation", "Materialism"],
         ["Liberation", "Reclaiming Power", "Breaking Free", "Overcoming Addiction"],
         "The Devil reflects the chains of self-imposed illusion, addictive cycles, material obsessions, and suppressed shadow desires.",
         "Reversed, marks a triumphant awakening, snapping false chains, and stepping into spiritual sovereignty and freedom.",
         "Examine what you are excessively attached to; recognize that the chains around your neck are loose enough to remove at will.",
         "The loose chains around the necks of the figures show that entrapment is largely an illusion of belief."),

        (16, "the_tower", "The Tower", "Fire", "Mars",
         ["Sudden Awakening", "Upheaval", "Breakthrough", "Revelation", "Liberation"],
         ["Averting Disaster", "Fear of Suffering", "Prolonging the Inevitable"],
         "Divine lightning strikes false towers built on unstable illusions. While sudden and startling, the collapse clears the ground for unshakable authentic foundations.",
         "Reversed, suggests internal upheaval or clinging to a crumbling structure rather than embracing freedom.",
         "Surrender to divine revelation; do not weep for foundations that were never built on truth.",
         "The lightning flash of divine truth knocks the artificial golden crown off the tower of human pride."),

        (17, "the_star", "The Star", "Air", "Aquarius",
         ["Hope", "Inspiration", "Healing", "Serenity", "Divine Blessing"],
         ["Despair", "Discouragement", "Lack of Faith", "Insecurity", "Disconnection"],
         "The Star pours out waters of celestial rejuvenation after the storm. It promises cosmic blessings, deep emotional healing, radiant hope, and artistic inspiration.",
         "Reversed, indicates temporary loss of faith, feeling overwhelmed by cynicism, or neglecting spiritual self-care.",
         "Keep your eyes fixed on your highest guiding star; you are divinely protected and revitalized.",
         "The seven smaller stars surrounding the central golden star represent the seven chakras aligned in cosmic harmony."),

        (18, "the_moon", "The Moon", "Water", "Pisces",
         ["Illusion", "Intuition", "Dreams", "Shadow Realm", "Unconscious Fears"],
         ["Release of Fear", "Unveiling Secrets", "Clarity", "Overcoming Anxiety"],
         "The Moon illuminates the mysterious landscape of dreams, deep subconscious fears, and psychic intuition. Things are not entirely what they seem on the surface.",
         "Reversed, marks the dispelling of illusions, rising above paranoia, and emerging into the crisp clarity of dawn.",
         "Trust your psychic instincts while being mindful not to mistake shadows for monsters.",
         "The dog and wolf howling at the moon symbolize our domesticated and primal instincts uniting under lunar energy."),

        (19, "the_sun", "The Sun", "Fire", "Sun",
         ["Joy", "Success", "Radiance", "Vitality", "Warmth", "Celebration"],
         ["Temporary Cloudiness", "Overly Optimistic", "Burnt Out", "Delayed Joy"],
         "The Sun is the most auspicious card in the deck, radiating boundless vitality, unconditional joy, creative triumph, and divine clarity.",
         "Reversed, reminds you that the sun is always shining behind passing clouds; gently reconnect with your inner child.",
         "Shine your authentic light unabashedly; celebrate your existence and share your warmth.",
         "The child riding a white horse with arms outstretched symbolizes pure, unburdened innocence and sovereign triumph."),

        (20, "judgement", "Judgement", "Fire / Water", "Pluto",
         ["Rebirth", "Higher Calling", "Awakening", "Absolution", "Spiritual Reckoning"],
         ["Self-Doubt", "Harsh Criticism", "Ignoring Calling", "Guilt", "Regret"],
         "The archangel sounds the trumpet of awakening, calling your soul to rise into its highest incarnation and shed past regrets forever.",
         "Reversed, points to harsh self-judgment, paralysis by guilt, or evading your true higher purpose.",
         "Heed the call of your soul; forgive your past and step boldly into your higher timeline.",
         "Figures rising from graves with outstretched arms symbolize resurrection of spirit into divine consciousness."),

        (21, "the_world", "The World", "Earth / Saturn", "Saturn",
         ["Completion", "Wholeness", "Integration", "Accomplishment", "Cosmic Harmony"],
         ["Incomplete Cycle", "Lack of Closure", "Shortcuts", "Delays in Completion"],
         "The final card of the Major Arcana represents the victorious completion of a major spiritual cycle, total cosmic integration, and blissful wholeness.",
         "Reversed, signals unfinished business or needing one last push of intentional closure before embarking on the next grand cycle.",
         "Honor how far you have journeyed; celebrate your wholeness and step into mastery.",
         "The cosmic dancer inside the green laurel wreath represents total harmony with the universal laws of creation.")
    ]

    for num, cid, name, elem, astro, kw_up, kw_rev, desc_up, desc_rev, adv, sym in major_arcana_data:
        cards.append({
            "card_id": cid,
            "name": name,
            "arcana_type": "major",
            "suit": None,
            "number": num,
            "image_url": f"/assets/tarot/major_{num:02d}_{cid}.jpg",
            "element": elem,
            "astrology": astro,
            "keywords_upright": kw_up,
            "keywords_reversed": kw_rev,
            "description_upright": desc_up,
            "description_reversed": desc_rev,
            "advice": adv,
            "symbolism": sym
        })

    # Minor Arcana (56 Cards)
    suits_config = [
        ("wands", "Wands", "Fire", ["Aries", "Leo", "Sagittarius"], "Inspiration, Passion, Creative Energy, Willpower, Action"),
        ("cups", "Cups", "Water", ["Cancer", "Scorpio", "Pisces"], "Emotions, Intuition, Relationships, Soul Connection, Empathy"),
        ("swords", "Swords", "Air", ["Gemini", "Libra", "Aquarius"], "Intellect, Truth, Communication, Clarity, Decision-making"),
        ("pentacles", "Pentacles", "Earth", ["Taurus", "Virgo", "Capricorn"], "Material World, Wealth, Career, Health, Manifestation, Grounding")
    ]

    minor_values = [
        (1, "ace", "Ace of {suit_title}", 
         ["Pure Potential", "New Opportunity", "Breakthrough", "Inception"],
         ["Missed Opportunity", "Blocked Energy", "Delays", "Hesitation"],
         "The Ace represents the primordial seed of {suit_title} power, offering a potent catalyst for new beginnings.",
         "Reversed, suggests creative blocks or hesitating to seize a fertile cosmic opening.",
         "Seize the spark of potential and begin planting seeds immediately.",
         "A divine hand emerging from the clouds presents the radiant symbol of the suit."),
        
        (2, "two", "Two of {suit_title}",
         ["Planning", "Decisions", "Partnership", "Discovery"],
         ["Indecision", "Disconnection", "Fear of Unknown", "Imbalance"],
         "The Two reflects balancing dual paths, strategic foresight, and making foundational choices.",
         "Reversed, points to hesitation between choices or disharmony in dynamic collaborations.",
         "Assess your trajectory with clarity before setting your path in stone.",
         "Two focal symbols held in balance symbolize choices and equilibrium."),

        (3, "three", "Three of {suit_title}",
         ["Expansion", "Growth", "Collaboration", "Vision"],
         ["Delays in Expansion", "Obstacles", "Frustration", "Dispersed Energy"],
         "The Three represents initial momentum, creative teamwork, and broadening horizons.",
         "Reversed, indicates unexpected delays or feeling unappreciated in collective endeavors.",
         "Look beyond familiar borders; collaborate with those who elevate your craft.",
         "A stance looking outward across expansive vistas symbolizes forward vision."),

        (4, "four", "Four of {suit_title}",
         ["Stability", "Celebration", "Rest", "Security"],
         ["Stagnation", "Insecurity", "Restlessness", "Rigidity"],
         "The Four brings grounded structure, sanctuary, and celebration of milestone achievements.",
         "Reversed, cautions against becoming too complacent or stubbornly resistant to evolution.",
         "Establish solid pillars of peace while maintaining flexibility.",
         "Four steady anchors forming a harmonious temple of security."),

        (5, "five", "Five of {suit_title}",
         ["Conflict", "Challenge", "Growth through Friction", "Testing"],
         ["Resolution", "Avoiding Conflict", "Reconciliation", "Compromise"],
         "The Five tests your resilience through healthy friction, competition, and overcoming obstacles.",
         "Reversed, signals the calming of storms, learning key lessons, and seeking peaceful resolution.",
         "View challenges as spiritual gym equipment designed to build inner muscle.",
         "Dynamic, colliding energies testing endurance and authenticity."),

        (6, "six", "Six of {suit_title}",
         ["Harmony", "Victory", "Generosity", "Revisiting Past"],
         ["Ego Inflation", "Lack of Recognition", "Greed", "Clinging to Past"],
         "The Six brings triumphant recognition, joyful reciprocity, and sweet reconciliation.",
         "Reversed, warns of ego-driven pride or one-sided dynamics that drain your reserves.",
         "Share your victories with humility; practice reciprocal generosity.",
         "A victorious or benevolent figure bestowing blessings and balance."),

        (7, "seven", "Seven of {suit_title}",
         ["Perseverance", "Strategy", "Evaluation", "Spiritual Choices"],
         ["Giving Up", "Overwhelmed", "Deception", "Impatience"],
         "The Seven calls for strategic stamina, assessing progress, and standing firm in your convictions.",
         "Reversed, advises against fighting unnecessary battles or rushing unripened fruit.",
         "Stand tall in your truth and cultivate patience for long-term dividends.",
         "A lone figure defending high ground or evaluating ripening harvest."),

        (8, "eight", "Eight of {suit_title}",
         ["Rapid Movement", "Mastery", "Transformation", "Dedication"],
         ["Delays", "Burnout", "Frustration", "Lack of Focus"],
         "The Eight accelerates energy, demanding razor-sharp focus, craftsmanship, and swift execution.",
         "Reversed, warns against rushing heedlessly or scattering your energy across too many fronts.",
         "Harness momentum and devote yourself to pristine craftsmanship.",
         "Eight symbols flying swift through open skies or meticulously carved on a workshop bench."),

        (9, "nine", "Nine of {suit_title}",
         ["Resilience", "Fulfillment", "Wisdom", "Last Stretch"],
         ["Exhaustion", "Paranoia", "Self-Doubt", "Defensiveness"],
         "The Nine signifies near completion, deep inner wisdom, and having the fortitude to cross the finish line.",
         "Reversed, calls for urgent rejuvenation to avoid burnout before the final breakthrough.",
         "Draw upon your reservoir of inner strength; victory is only one step away.",
         "A seasoned guardian standing watchful with deep reserves of accumulated wisdom."),

        (10, "ten", "Ten of {suit_title}",
         ["Culmination", "Legacy", "Full Circle", "Overburden"],
         ["Release of Burden", "Collapse", "Renewal", "Relief"],
         "The Ten represents the complete culmination and full manifestation of the suit's energy.",
         "Reversed, encourages laying down heavy burdens that are no longer yours to carry.",
         "Celebrate the completion of the cycle and prepare to evolve to the next octave.",
         "Ten full emblems completing the arc of earthly and spiritual manifestation."),

        (11, "page", "Page of {suit_title}",
         ["Curiosity", "New Message", "Enthusiasm", "Youthful Spirit"],
         ["Immaturity", "Procrastination", "Bad News", "Lack of Focus"],
         "The Page brings fresh curiosity, exciting communications, and a child-like desire to learn.",
         "Reversed, signals scattered attention, fear of making mistakes, or petulant behavior.",
         "Approach your journey with beginner's mind and genuine curiosity.",
         "A youthful seeker studying the symbol with bright, inquiring eyes."),

        (12, "knight", "Knight of {suit_title}",
         ["Drive", "Action", "Chivalry", "Pursuit of Goal"],
         ["Recklessness", "Impatience", "Aggression", "Hesitation"],
         "The Knight charges forward with dynamic commitment, pursuing his quest with fervor.",
         "Reversed, cautions against burning bridges or rushing blindly without situational awareness.",
         "Channel your fiery drive with purposeful strategy and honor.",
         "A galloping knight on horseback bearing the sacred standard."),

        (13, "queen", "Queen of {suit_title}",
         ["Emotional Mastery", "Nurturing Power", "Intuitive Leadership", "Grace"],
         ["Coldness", "Insecurity", "Jealousy", "Domineering"],
         "The Queen embodies mature, magnetic mastery, ruling her domain with grace, warmth, and intuitive wisdom.",
         "Reversed, warns against emotional manipulation, bitter withdrawal, or self-sabotage.",
         "Lead with regal compassion and trust your intrinsic magnetic worth.",
         "A crowned queen seated on an ornate throne flanked by elemental familiars."),

        (14, "king", "King of {suit_title}",
         ["Authority", "Mastery", "Visionary Leadership", "Execution"],
         ["Tyranny", "Incompetence", "Stubbornness", "Ruthlessness"],
         "The King represents supreme mastery, sovereign authority, and long-term wisdom in the realm of {suit_title}.",
         "Reversed, warns of authoritarian tendencies, arrogance, or losing sight of ethical standards.",
         "Embody visionary stewardship; make decisions for the highest good of all.",
         "A majestic king holding the scepter of power on a solid foundation.")
    ]

    for suit_key, suit_title, suit_elem, suit_astro, suit_desc in suits_config:
        for num, val_key, name_fmt, kw_up, kw_rev, desc_up_fmt, desc_rev_fmt, adv, sym in minor_values:
            cid = f"{val_key}_of_{suit_key}"
            name = name_fmt.format(suit_title=suit_title)
            desc_up = desc_up_fmt.format(suit_title=suit_title) + f" Aligned with {suit_desc}."
            desc_rev = desc_rev_fmt.format(suit_title=suit_title)
            
            cards.append({
                "card_id": cid,
                "name": name,
                "arcana_type": "minor",
                "suit": suit_key,
                "number": num,
                "image_url": f"/assets/tarot/{suit_key}_{num:02d}_{val_key}.jpg",
                "element": suit_elem,
                "astrology": ", ".join(suit_astro),
                "keywords_upright": kw_up,
                "keywords_reversed": kw_rev,
                "description_upright": desc_up,
                "description_reversed": desc_rev,
                "advice": adv,
                "symbolism": sym
            })

    return cards

if __name__ == "__main__":
    cards_data = generate_tarot_dataset()
    out_path = Path(__file__).resolve().parent / "tarot_cards.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(cards_data, f, indent=2, ensure_ascii=False)
    print(f"Successfully generated {len(cards_data)} tarot cards to {out_path}")
