from typing import Dict, Any, List, Optional

class SpiritualScoringEngine:
    """
    Synthesizes chiromancy metrics, tarot card archetypes, astrological zodiac signs,
    and numerological life path numbers into a unified, balanced multi-dimensional scoring matrix.
    """

    DIMENSION_DEFINITIONS = {
        "vitality": {
            "name": "Vitality & Somatic Prana",
            "category": "Physical & Energy Body",
            "desc": "Biological vitality, nervous system stamina, and grounded physical regenerative power."
        },
        "mental_clarity": {
            "name": "Mental Clarity & Strategic Insight",
            "category": "Intellectual Plane",
            "desc": "Focus, cognitive adaptability, problem-solving prowess, and discernment between truth and illusion."
        },
        "emotional_harmony": {
            "name": "Emotional Depth & Relational Harmony",
            "category": "Heart & Connection",
            "desc": "Vulnerability, capacity for unconditional love, empathy, and healthy relational boundaries."
        },
        "career_destiny": {
            "name": "Career Destiny & Sovereign Ambition",
            "category": "Vocation & Dharma",
            "desc": "Alignment with soul calling, entrepreneurial willpower, and purposeful vocational manifestation."
        },
        "spiritual_connection": {
            "name": "Spiritual Connection & Higher Intuition",
            "category": "Soul & Cosmos",
            "desc": "Psychic receptivity, alignment with synchronicity, meditation depth, and ancestral/cosmic guidance."
        },
        "abundance_flow": {
            "name": "Financial Flow & Material Abundance",
            "category": "Prosperity & Wealth",
            "desc": "Healthy relationship with money, wealth generation, resource stewardship, and prosperity consciousness."
        },
        "creative_radiance": {
            "name": "Creative Radiance & Magnetism",
            "category": "Expression & Joy",
            "desc": "Artistic inspiration, personal charisma, playful authenticity, and creative self-expression."
        }
    }

    def compute_holistic_synthesis(
        self,
        palm_features: Optional[Dict[str, Any]] = None,
        tarot_spread: Optional[Dict[str, Any]] = None,
        zodiac_sign: str = "Cancer",
        life_path_number: int = 7
    ) -> Dict[str, Any]:
        
        # Base baseline scores
        scores = {
            "vitality": 80.0,
            "mental_clarity": 82.0,
            "emotional_harmony": 84.0,
            "career_destiny": 78.0,
            "spiritual_connection": 86.0,
            "abundance_flow": 76.0,
            "creative_radiance": 81.0,
        }

        # 1. Incorporate Palm Features
        if palm_features:
            lines = palm_features.get("lines", {})
            mounts = palm_features.get("mounts", {})
            hand_type = palm_features.get("hand_type", "Earth")

            if "life_line" in lines:
                scores["vitality"] = lines["life_line"].get("clarity_score", 85.0)
            if "head_line" in lines:
                scores["mental_clarity"] = lines["head_line"].get("clarity_score", 84.0)
            if "heart_line" in lines:
                scores["emotional_harmony"] = lines["heart_line"].get("clarity_score", 82.0)
            if "fate_line" in lines:
                scores["career_destiny"] = lines["fate_line"].get("clarity_score", 76.0)
            if "sun_line" in lines:
                scores["creative_radiance"] = lines["sun_line"].get("clarity_score", 78.0)

            # Hand type adjustments
            if hand_type == "Fire":
                scores["creative_radiance"] += 4.0
                scores["career_destiny"] += 3.0
            elif hand_type == "Water":
                scores["emotional_harmony"] += 5.0
                scores["spiritual_connection"] += 6.0
            elif hand_type == "Air":
                scores["mental_clarity"] += 5.0
                scores["abundance_flow"] += 3.0
            elif hand_type == "Earth":
                scores["vitality"] += 5.0
                scores["abundance_flow"] += 4.0

        # 2. Incorporate Tarot Spread
        if tarot_spread:
            drawn_cards = tarot_spread.get("drawn_cards", [])
            for dc in drawn_cards:
                card = dc.get("card", {})
                is_rev = dc.get("is_reversed", False)
                suit = card.get("suit")
                arcana = card.get("arcana_type")
                
                weight = -2.0 if is_rev else 3.0
                if arcana == "major":
                    scores["spiritual_connection"] += (4.0 if not is_rev else -1.0)
                if suit == "wands":
                    scores["creative_radiance"] += weight
                    scores["career_destiny"] += weight
                elif suit == "cups":
                    scores["emotional_harmony"] += weight
                elif suit == "swords":
                    scores["mental_clarity"] += weight
                elif suit == "pentacles":
                    scores["abundance_flow"] += weight
                    scores["vitality"] += (weight * 0.8)

        # 3. Incorporate Numerology & Zodiac Modifiers
        # Numerology modifiers
        if life_path_number in [1, 8]:
            scores["career_destiny"] += 4.0
            scores["abundance_flow"] += 3.0
        elif life_path_number in [2, 6]:
            scores["emotional_harmony"] += 4.0
        elif life_path_number in [3, 5]:
            scores["creative_radiance"] += 5.0
        elif life_path_number in [7, 9, 11, 22]:
            scores["spiritual_connection"] += 5.0
            scores["mental_clarity"] += 3.0

        # Normalize scores within [50.0, 99.0]
        dimension_results = {}
        total_sum = 0.0

        for key, raw_val in scores.items():
            clamped = float(max(55.0, min(98.5, round(raw_val, 1))))
            total_sum += clamped
            
            if clamped >= 88.0:
                status = "Harmonious & Radiant"
            elif clamped >= 76.0:
                status = "Ascending & Expanding"
            elif clamped >= 65.0:
                status = "Active Incubation"
            else:
                status = "Transformational Focus"

            dim_info = self.DIMENSION_DEFINITIONS[key]
            dimension_results[key] = {
                "name": dim_info["name"],
                "score": clamped,
                "category": dim_info["category"],
                "description": dim_info["desc"],
                "status": status
            }

        overall_score = float(round(total_sum / len(scores), 1))

        # Determine lowest and highest dimensions for tailored recommendations
        sorted_dims = sorted(dimension_results.items(), key=lambda x: x[1]["score"])
        growth_focus = sorted_dims[0][0]
        top_strength = sorted_dims[-1][0]

        # Personalized Rituals
        rituals = [
            {
                "title": "Morning Solar Alignment & Chiromancy Grounding",
                "duration": "10 Minutes",
                "instructions": "Face the morning sun, place your dominant palm over your heart space, take 7 deep diaphragmatic breaths, and visualize golden solar prana illuminating your Life and Heart lines.",
                "purpose": "Charges the nervous system and activates sovereign energetic boundaries."
            },
            {
                "title": "Evening Lunar Tarot Meditation",
                "duration": "15 Minutes",
                "instructions": "Place your focal tarot card beside a glass of water under the moonlight. Softly gaze at the central archetype, asking your subconscious what truth desires integration before sleep.",
                "purpose": "Synthesizes dream wisdom and dissolves subconscious anxiety."
            }
        ]

        # Recommended Crystals & Remedies
        crystal_map = {
            "vitality": {"name": "Red Jasper & Carnelian", "purpose": "Grounding somatic root energy and enhancing cellular stamina."},
            "mental_clarity": {"name": "Fluorite & Clear Quartz", "purpose": "Clearing mental fog and sharpening intuitive discernment."},
            "emotional_harmony": {"name": "Rose Quartz & Rhodonite", "purpose": "Opening heart chakra and healing emotional wounds."},
            "career_destiny": {"name": "Tiger's Eye & Pyrite", "purpose": "Igniting executive confidence and attracting golden vocational synchronicity."},
            "spiritual_connection": {"name": "Amethyst & Labradorite", "purpose": "Deepening third-eye vision and shielding psychic aura."},
            "abundance_flow": {"name": "Citrine & Green Aventurine", "purpose": "Activating wealth frequency and releasing scarcity paradigms."},
            "creative_radiance": {"name": "Sunstone & Orange Calcite", "purpose": "Unlocking spontaneous joy and artistic flow states."}
        }

        recommended_crystals = [
            crystal_map.get(top_strength, {"name": "Clear Quartz", "purpose": "Amplifying highest energetic mastery."}),
            crystal_map.get(growth_focus, {"name": "Amethyst", "purpose": "Harmonizing growth areas and restoring equilibrium."})
        ]

        affirmations = [
            f"I am fully aligned with my cosmic blueprint; my soul wisdom guides every earthly step.",
            f"My heart and mind work in sacred synergy to manifest beauty, truth, and abundance.",
            f"I honor the cycles of my growth and trust that the universe conspires for my highest good."
        ]

        return {
            "dimension_scores": dimension_results,
            "overall_harmony_score": overall_score,
            "top_strength": dimension_results[top_strength],
            "growth_focus": dimension_results[growth_focus],
            "personalized_rituals": rituals,
            "recommended_crystals": recommended_crystals,
            "affirmations": affirmations
        }

scoring_engine = SpiritualScoringEngine()
