import uuid
from pathlib import Path
from typing import Dict, Any
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, HRFlowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch

from app.config import settings

class PDFReportService:
    def __init__(self):
        self.reports_dir = settings.REPORTS_DIR

    def generate_spiritual_dossier_pdf(self, synthesis_data: Dict[str, Any]) -> str:
        """
        Generates an ethereal, comprehensive PDF report summarizing the Seeker's
        Spiritual Blueprint, Palmistry findings, Tarot Spread, and 7-Dimension Scores.
        """
        file_id = uuid.uuid4().hex[:10]
        filename = f"spiritual_dossier_{file_id}.pdf"
        filepath = self.reports_dir / filename

        doc = SimpleDocTemplate(
            str(filepath),
            pagesize=letter,
            rightMargin=40,
            leftMargin=40,
            topMargin=40,
            bottomMargin=40
        )

        styles = getSampleStyleSheet()
        
        # Custom Mystical Styles
        primary_color = colors.HexColor("#1e1b4b")  # Deep indigo
        gold_color = colors.HexColor("#d97706")     # Amber gold
        accent_color = colors.HexColor("#4f46e5")   # Indigo accent
        dark_text = colors.HexColor("#1f2937")

        title_style = ParagraphStyle(
            "MysticTitle",
            parent=styles["Heading1"],
            fontSize=22,
            leading=26,
            textColor=primary_color,
            alignment=1,  # Center
            spaceAfter=8
        )

        subtitle_style = ParagraphStyle(
            "MysticSubtitle",
            parent=styles["Normal"],
            fontSize=11,
            leading=15,
            textColor=gold_color,
            alignment=1,
            spaceAfter=15
        )

        section_heading = ParagraphStyle(
            "SectionHeading",
            parent=styles["Heading2"],
            fontSize=14,
            leading=18,
            textColor=accent_color,
            spaceBefore=12,
            spaceAfter=6
        )

        body_style = ParagraphStyle(
            "MysticBody",
            parent=styles["Normal"],
            fontSize=10,
            leading=14,
            textColor=dark_text,
            spaceAfter=6
        )

        bold_style = ParagraphStyle(
            "MysticBold",
            parent=body_style,
            fontName="Helvetica-Bold"
        )

        story = []

        # Header Title
        story.append(Paragraph("✧ SPIRITUAL BLUEPRINT & COSMIC DOSSIER ✧", title_style))
        story.append(Paragraph("AI-Powered Palmistry & Tarot Intelligence Platform", subtitle_style))
        story.append(HRFlowable(width="100%", thickness=1.5, color=gold_color, spaceAfter=15))

        # Seeker Overview Table
        seeker_name = synthesis_data.get("seeker_name", "Elena Vance")
        zodiac = synthesis_data.get("astrological_profile", {}).get("zodiac_sign", "Scorpio")
        life_path = synthesis_data.get("numerology_profile", {}).get("life_path_number", 7)
        harmony_score = synthesis_data.get("overall_harmony_score", 84.5)

        overview_data = [
            [
                Paragraph("<b>Seeker Name:</b>", body_style),
                Paragraph(seeker_name, body_style),
                Paragraph("<b>Zodiac Sign:</b>", body_style),
                Paragraph(f"{zodiac} (Sun)", body_style),
            ],
            [
                Paragraph("<b>Life Path Number:</b>", body_style),
                Paragraph(f"Number {life_path}", body_style),
                Paragraph("<b>Harmony Index:</b>", body_style),
                Paragraph(f"<b>{harmony_score} / 100</b>", bold_style),
            ]
        ]

        t_overview = Table(overview_data, colWidths=[110, 150, 110, 150])
        t_overview.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
            ('BOX', (0, 0), (-1, -1), 1, colors.HexColor("#e2e8f0")),
            ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#f1f5f9")),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ]))
        story.append(t_overview)
        story.append(Spacer(1, 14))

        # 1. 7-Dimension Guidance Scores
        story.append(Paragraph("1. Multi-Dimensional Spiritual Energy Matrix", section_heading))
        dim_scores = synthesis_data.get("dimension_scores", {})
        
        score_rows = [
            [
                Paragraph("<b>Dimension</b>", bold_style),
                Paragraph("<b>Score</b>", bold_style),
                Paragraph("<b>Status</b>", bold_style),
                Paragraph("<b>Energetic Resonance</b>", bold_style)
            ]
        ]

        for dkey, dval in dim_scores.items():
            score_rows.append([
                Paragraph(dval.get("name", dkey.title()), body_style),
                Paragraph(f"{dval.get('score', 80.0)}%", bold_style),
                Paragraph(dval.get("status", "Harmonious"), body_style),
                Paragraph(dval.get("description", "")[:60] + "...", body_style)
            ])

        t_scores = Table(score_rows, colWidths=[140, 50, 120, 210])
        t_scores.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#ede9fe")),
            ('TEXTCOLOR', (0, 0), (-1, 0), primary_color),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ]))
        story.append(t_scores)
        story.append(Spacer(1, 14))

        # 2. Palmistry Chiromancy Findings
        story.append(Paragraph("2. Chiromancy & Hand Topography Insights", section_heading))
        palm_syn = synthesis_data.get("palm_synthesis", {})
        hand_type = palm_syn.get("hand_type", "Earth")
        hand_desc = palm_syn.get("hand_type_desc", "Square palm with sturdy fingers, grounded and resilient.")
        
        story.append(Paragraph(f"<b>Elemental Hand Structure:</b> {hand_type} Hand — {hand_desc}", body_style))
        story.append(Paragraph("<b>Key Line Formations:</b>", bold_style))
        
        lines_summary = [
            "• <b>Heart Line:</b> Reaches toward Mount of Jupiter, denoting high ideals, deep loyalty, and healthy boundaries.",
            "• <b>Head Line:</b> Gentle slope toward Mount of Moon, blending sharp logic with psychic and creative intuition.",
            "• <b>Life Line:</b> Expansive curve around Venus Mount, reflecting vigorous physical prana and rapid regeneration.",
            "• <b>Fate Line:</b> Ascending clearly toward Saturn Mount, indicating self-architected destiny and vocational clarity."
        ]
        for l_txt in lines_summary:
            story.append(Paragraph(l_txt, body_style))

        story.append(Spacer(1, 14))

        # 3. Tarot Spread Synthesis
        story.append(Paragraph("3. Tarot Archetypal Resonance", section_heading))
        tarot_syn = synthesis_data.get("tarot_synthesis", {})
        spread_name = tarot_syn.get("spread_name", "Trinity Spread")
        holistic_interp = tarot_syn.get("holistic_interpretation", "A sacred period of spiritual transition and grounded action.")
        
        story.append(Paragraph(f"<b>Active Spread:</b> {spread_name}", bold_style))
        story.append(Paragraph(f"<b>Holistic Oracle Synthesis:</b> {holistic_interp}", body_style))
        story.append(Spacer(1, 14))

        # 4. Tailored Spiritual Rituals & Crystal Remedies
        story.append(Paragraph("4. Prescribed Rituals & Energetic Remedies", section_heading))
        rituals = synthesis_data.get("personalized_rituals", [])
        for r in rituals:
            story.append(Paragraph(f"<b>✧ {r.get('title', 'Ritual')}</b> ({r.get('duration', '10 mins')}): {r.get('instructions', '')}", body_style))

        crystals = synthesis_data.get("recommended_crystals", [])
        if crystals:
            c_str = ", ".join([f"<b>{c.get('name')}</b> ({c.get('purpose')})" for c in crystals])
            story.append(Paragraph(f"<b>Recommended Crystal Allies:</b> {c_str}", body_style))

        # Affirmations
        affirmations = synthesis_data.get("affirmations", [])
        if affirmations:
            story.append(Spacer(1, 6))
            story.append(Paragraph("<b>Cosmic Affirmation:</b>", bold_style))
            story.append(Paragraph(f"<i>\"{affirmations[0]}\"</i>", body_style))

        # Build Document
        doc.build(story)
        return f"/reports/{filename}"

pdf_report_service = PDFReportService()
