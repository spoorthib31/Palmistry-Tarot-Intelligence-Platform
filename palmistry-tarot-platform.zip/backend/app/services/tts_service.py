import uuid
from pathlib import Path
from typing import Optional
from app.config import settings

class TTSService:
    def __init__(self):
        self.upload_dir = settings.UPLOAD_DIR

    def text_to_speech(self, text: str, lang: str = "en") -> Optional[str]:
        try:
            from gtts import gTTS
            file_id = uuid.uuid4().hex[:10]
            filename = f"tts_{file_id}.mp3"
            filepath = self.upload_dir / filename

            # Limit text length to prevent long synthesis lag
            clean_text = text[:300]
            tts = gTTS(text=clean_text, lang=lang, slow=False)
            tts.save(str(filepath))

            return f"/uploads/{filename}"
        except Exception:
            return None

tts_service = TTSService()
