import json
import random
from pathlib import Path
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session

from app.models.tarot_card import TarotCard

class TarotService:
    def __init__(self):
        self.data_dir = Path(__file__).resolve().parent.parent / "data"
        self._load_fallback_cards()

    def _load_fallback_cards(self):
        json_path = self.data_dir / "tarot_cards.json"
        if json_path.exists():
            with open(json_path, "r", encoding="utf-8") as f:
                self.fallback_cards = json.load(f)
        else:
            self.fallback_cards = []

    def get_all_cards(self, db: Optional[Session] = None) -> List[Dict[str, Any]]:
        if db:
            cards = db.query(TarotCard).all()
            if cards:
                return [
                    {
                        "id": c.id,
                        "card_id": c.card_id,
                        "name": c.name,
                        "arcana_type": c.arcana_type,
                        "suit": c.suit,
                        "number": c.number,
                        "image_url": c.image_url,
                        "element": c.element,
                        "astrology": c.astrology,
                        "keywords_upright": c.keywords_upright,
                        "keywords_reversed": c.keywords_reversed,
                        "description_upright": c.description_upright,
                        "description_reversed": c.description_reversed,
                        "advice": c.advice,
                        "symbolism": c.symbolism,
                    }
                    for c in cards
                ]
        return self.fallback_cards

    def get_card_by_id(self, card_id: str, db: Optional[Session] = None) -> Optional[Dict[str, Any]]:
        all_cards = self.get_all_cards(db)
        for c in all_cards:
            if c["card_id"] == card_id:
                return c
        return None

    def draw_spread(
        self, 
        spread_type: str = "three_card", 
        question: str = "What energies surround my journey?",
        db: Optional[Session] = None,
        custom_card_ids: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Draws cards according to the requested spread type, computes positions,
        reversals, elemental dynamics, and provides a multi-layer holistic interpretation.
        """
        all_cards = list(self.get_all_cards(db))
        if not all_cards:
            self._load_fallback_cards()
            all_cards = list(self.fallback_cards)

        # Spread layout definitions
        spread_layouts = {
            "single_card": {
                "name": "Single Card Oracle (Cosmic Spark)",
                "positions": [
                    {"name": "Core Energy & Message", "meaning": "The immediate spiritual lesson and active archetype for this moment."}
                ]
            },
            "three_card": {
                "name": "Trinity Spread (Past • Present • Future)",
                "positions": [
                    {"name": "Root & Foundation (Past)", "meaning": "Karmic origins, learned lessons, and energies that laid the current groundwork."},
                    {"name": "Current Catalyst (Present)", "meaning": "The prevailing focal energy, active challenges, and immediate reality."},
                    {"name": "Ascending Horizon (Future)", "meaning": "The highest potential outcome if current trajectory and wisdom are integrated."}
                ]
            },
            "three_card_mind_body_spirit": {
                "name": "Mind • Body • Spirit Alignment",
                "positions": [
                    {"name": "Mind (Mental Plane)", "meaning": "Conscious thoughts, intellectual clarity, and mental paradigms."},
                    {"name": "Body (Physical Plane)", "meaning": "Somatic energy, health, material foundations, and physical environment."},
                    {"name": "Spirit (Higher Self)", "meaning": "Intuitive calling, cosmic connection, and soul evolution."}
                ]
            },
            "five_card_relationship": {
                "name": "Soul Connection Alchemy (5-Card Spread)",
                "positions": [
                    {"name": "Your Current Energy", "meaning": "How you show up in the partnership and your conscious desire."},
                    {"name": "Partner / Other Energy", "meaning": "The perspective, emotional state, and projection of the other party."},
                    {"name": "The Sacred Crucible", "meaning": "The shared vibrational bridge uniting both souls."},
                    {"name": "Underlying Friction / Karmic Lesson", "meaning": "The core blockage, shadow element, or growth trigger."},
                    {"name": "Harmonious Resolution", "meaning": "The highest evolved state of this union when truth is honored."}
                ]
            },
            "five_card_career": {
                "name": "Career & Sovereign Destiny Spread",
                "positions": [
                    {"name": "Current Stance", "meaning": "Your current vocational positioning and skills."},
                    {"name": "Emerging Opportunity", "meaning": "A fertile path, invitation, or creative spark ready to blossom."},
                    {"name": "Hidden Factor", "meaning": "Unseen currents, market timing, or subconscious fears to be aware of."},
                    {"name": "Mastery Action", "meaning": "The concrete strategic move recommended by the oracle."},
                    {"name": "Abundance Harvest", "meaning": "The ultimate professional and financial manifestation."}
                ]
            },
            "celtic_cross": {
                "name": "The Sacred Celtic Cross (10-Card In-Depth Life Guidance)",
                "positions": [
                    {"name": "1. The Heart of the Matter", "meaning": "The central theme and immediate environment surrounding the seeker."},
                    {"name": "2. The Crossing Challenge", "meaning": "The primary obstacle, opposing force, or friction to navigate."},
                    {"name": "3. The Root Foundation", "meaning": "Subconscious beliefs, ancestral karma, and deep historical roots."},
                    {"name": "4. The Passing Past", "meaning": "Recent events and fading influences leaving your sphere."},
                    {"name": "5. The Crown & Ideal", "meaning": "Conscious aspiration, highest hope, and optimal goal."},
                    {"name": "6. The Emerging Future", "meaning": "Next phase catalysts and people stepping into your path."},
                    {"name": "7. The Seeker's Self", "meaning": "Internal stance, confidence, and psychological mindset."},
                    {"name": "8. The External Sphere", "meaning": "Influence of family, society, workspace, and physical realm."},
                    {"name": "9. Hopes & Hidden Fears", "meaning": "Deepest vulnerabilities, secret wishes, and psychological projections."},
                    {"name": "10. The Ultimate Synthesis", "meaning": "The culmination of all spiritual and earthly energies in play."}
                ]
            }
        }

        layout = spread_layouts.get(spread_type, spread_layouts["three_card"])
        num_cards = len(layout["positions"])

        # Select cards
        selected_raw_cards = []
        if custom_card_ids and len(custom_card_ids) >= num_cards:
            for cid in custom_card_ids[:num_cards]:
                card = next((c for c in all_cards if c["card_id"] == cid), None)
                if card:
                    selected_raw_cards.append(card)
        
        # Fill remaining with random shuffle
        remaining_needed = num_cards - len(selected_raw_cards)
        if remaining_needed > 0:
            available = [c for c in all_cards if c not in selected_raw_cards]
            random.shuffle(available)
            selected_raw_cards.extend(available[:remaining_needed])

        drawn_cards = []
        element_counts = {"Fire": 0, "Water": 0, "Air": 0, "Earth": 0, "Spirit": 0}
        major_count = 0

        for i, pos_info in enumerate(layout["positions"]):
            card = selected_raw_cards[i]
            # 22% chance of reversed orientation for natural reading dynamics
            is_reversed = random.random() < 0.22
            
            elem = card.get("element", "Spirit")
            if "Fire" in elem: element_counts["Fire"] += 1
            elif "Water" in elem: element_counts["Water"] += 1
            elif "Air" in elem: element_counts["Air"] += 1
            elif "Earth" in elem: element_counts["Earth"] += 1
            else: element_counts["Spirit"] += 1

            if card["arcana_type"] == "major":
                major_count += 1

            # Contextualized reading text
            desc = card["description_reversed"] if is_reversed else card["description_upright"]
            keywords = card["keywords_reversed"] if is_reversed else card["keywords_upright"]
            kw_str = ", ".join(keywords[:3]) if keywords else ""
            
            context_reading = (
                f"Position: {pos_info['name']} ({pos_info['meaning']}). "
                f"Card: {card['name']} ({'Reversed' if is_reversed else 'Upright'}). "
                f"Key Themes: {kw_str}. {desc} "
                f"Guidance: {card.get('advice', 'Proceed with mindfulness.')}"
            )

            drawn_cards.append({
                "card": card,
                "position_index": i + 1,
                "position_name": pos_info["name"],
                "position_meaning": pos_info["meaning"],
                "is_reversed": is_reversed,
                "context_reading": context_reading
            })

        # Dominant Element
        dominant_element = max(element_counts, key=element_counts.get)
        
        # Energy Focus synthesis
        if major_count >= (num_cards / 2):
            energy_focus = "High Karmic Evolution & Soul Destiny"
        elif dominant_element == "Fire":
            energy_focus = "Passionate Action, Creative Willpower & Inspiration"
        elif dominant_element == "Water":
            energy_focus = "Emotional Receptivity, Psychic Intuition & Soul Healing"
        elif dominant_element == "Air":
            energy_focus = "Mental Breakthrough, Strategic Truth & Communication"
        else:
            energy_focus = "Material Manifestation, Grounded Stability & Physical Harvest"

        # Holistic Interpretation Generator
        card_names = [f"{'Reversed ' if d['is_reversed'] else ''}{d['card']['name']}" for d in drawn_cards]
        holistic_interp = (
            f"Your spread reveals a potent convergence of {dominant_element} energy ({energy_focus}). "
            f"With {', '.join(card_names[:3])} anchoring this reading, the cosmos highlights a sacred transition. "
            f"The underlying currents invite you to balance courageous action with deep inner stillness. "
            f"You are being called to embody sovereign discernment, trusting that current obstacles are catalysts for profound spiritual expansion."
        )

        # Dimension Scores based on cards drawn
        dim_scores = {
            "intuition": float(round(75.0 + element_counts["Water"] * 6 + (10 if major_count > 0 else 0), 1)),
            "career_destiny": float(round(70.0 + element_counts["Fire"] * 6 + element_counts["Earth"] * 4, 1)),
            "emotional_balance": float(round(72.0 + element_counts["Water"] * 5 + element_counts["Air"] * 4, 1)),
            "spiritual_harmony": float(round(80.0 + major_count * 7, 1)),
            "manifestation_power": float(round(74.0 + element_counts["Earth"] * 6 + element_counts["Fire"] * 5, 1))
        }

        # Actionable Advice
        actionable_advice = [
            f"Channel the vitality of {dominant_element} to ground your intentions into tangible daily practice.",
            f"Reflect deeply on {drawn_cards[0]['card']['name']}'s core teaching: {drawn_cards[0]['card'].get('advice', 'Honor your inner guidance.')}",
            "Perform a brief 5-minute morning breathwork ritual to harmonize conscious thoughts with intuitive whispers."
        ]

        return {
            "spread_name": layout["name"],
            "question": question,
            "drawn_cards": drawn_cards,
            "holistic_interpretation": holistic_interp,
            "dominant_element": dominant_element,
            "energy_focus": energy_focus,
            "dimension_scores": dim_scores,
            "actionable_advice": actionable_advice
        }

tarot_service = TarotService()
