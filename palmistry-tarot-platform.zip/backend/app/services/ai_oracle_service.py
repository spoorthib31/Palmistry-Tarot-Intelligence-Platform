import datetime
import random
import httpx
from typing import Dict, Any, List, Optional
from app.config import settings

class AIOracleService:
    """
    Spiritual AI engine powering the conversational Mystic Advisor ('Aurelia'),
    daily divination, and holistic dossier interpretations.
    Operates seamlessly out-of-the-box using symbolic esoteric intelligence,
    with automatic upgrade when OpenAI / Gemini API keys are configured.
    """

    SYSTEM_PERSONA = (
        "You are Aurelia, the Celestial Oracle of the Palmistry & Tarot Intelligence Platform. "
        "You possess profound, compassionate, and poetic wisdom spanning Hermetic philosophy, "
        "Vedic Chiromancy, archetypal Tarot symbolism, Western Astrology, and Sacred Numerology. "
        "Your tone is serene, illuminating, empowering, and grounded. You never preach fatalism; "
        "you illuminate sovereign choices, spiritual lessons, and energetic alignments."
    )

    RUNES = [
        ("Fehu", "ᚠ", "Abundance, wealth flow, new beginnings, fruitful harvest"),
        ("Ansuz", "ᚨ", "Divine inspiration, higher communication, ancestral wisdom"),
        ("Raidho", "ᚱ", "Sacred journey, rhythm of destiny, spiritual alignment"),
        ("Kenaz", "ᚲ", "Illumination, creative fire, inner clarity, breakthrough"),
        ("Gebo", "ᚷ", "Sacred gift, reciprocal partnership, balance of giving & receiving"),
        ("Wunjo", "ᚹ", "Joy, fellowship, harmonious fulfillment, soul radiance"),
        ("Sowilo", "ᛋ", "Solar victory, life force vitality, divine success, wholeness"),
        ("Tiwaz", "ᛏ", "Spiritual warrior, sovereign justice, courageous leadership"),
        ("Berkana", "ᛒ", "Rebirth, gentle healing, nurturing sanctuary, fertile growth"),
        ("Ehwaz", "ᛖ", "Sacred momentum, synergistic alliance, swift transformation"),
        ("Mannaz", "ᛗ", "Human collective, self-actualization, deep empathy"),
        ("Laguz", "ᛚ", "Living waters, psychic intuition, dream flow, emotional cleansing"),
        ("Dagaz", "ᛞ", "Dawn of awakening, radical breakthrough, cosmic enlightenment"),
        ("Othala", "ᛟ", "Ancestral legacy, spiritual heritage, sacred sacred boundaries")
    ]

    async def generate_chat_response(
        self,
        message: str,
        conversation_history: Optional[List[Dict[str, str]]] = None,
        context: Optional[Dict[str, Any]] = None,
        custom_gemini_key: Optional[str] = None,
        custom_openai_key: Optional[str] = None
    ) -> Dict[str, Any]:
        
        gemini_key = custom_gemini_key or settings.GEMINI_API_KEY
        openai_key = custom_openai_key or settings.OPENAI_API_KEY

        # Check if live Gemini API key is available
        if gemini_key:
            try:
                reply = await self._call_gemini_api(gemini_key, message, conversation_history, context)
                return {
                    "reply": reply,
                    "suggested_questions": self._generate_suggested_questions(context),
                    "cosmic_mood": "Deeply Attuned to Celestial Frequencies"
                }
            except Exception:
                pass  # Fallback to symbolic engine

        # Check if live OpenAI API key is available
        if openai_key:
            try:
                reply = await self._call_openai_api(openai_key, message, conversation_history, context)
                return {
                    "reply": reply,
                    "suggested_questions": self._generate_suggested_questions(context),
                    "cosmic_mood": "Attuned to Solar & Lunar Currents"
                }
            except Exception:
                pass  # Fallback to symbolic engine

        # High-Fidelity Symbolic Esoteric Knowledge Engine
        reply = self._generate_symbolic_oracle_reply(message, context)
        return {
            "reply": reply,
            "suggested_questions": self._generate_suggested_questions(context),
            "cosmic_mood": "Ethereal & Divinely Attuned"
        }

    def _generate_symbolic_oracle_reply(self, message: str, context: Optional[Dict[str, Any]] = None) -> str:
        msg_lower = message.lower()
        
        # Context extraction
        zodiac = "Cancer"
        hand_type = "Earth"
        drawn_cards_str = ""
        
        if context:
            zodiac = context.get("zodiac_sign", zodiac)
            if "palm_features" in context:
                hand_type = context["palm_features"].get("hand_type", hand_type)
            if "tarot_spread" in context:
                cards = context["tarot_spread"].get("drawn_cards", [])
                if cards:
                    card_names = [c["card"]["name"] for c in cards]
                    drawn_cards_str = f"and the archetypal resonance of {', '.join(card_names[:3])}"

        if any(w in msg_lower for w in ["love", "relationship", "partner", "soulmate", "twin flame", "heart"]):
            return (
                f"Beloved Seeker, your heart space carries a sacred vibration. "
                f"Your chiromancy lines reflect deep relational devotion and sensitivity, "
                f"{drawn_cards_str} indicating that true alignment is born when you honor your sovereign emotional boundaries. "
                f"In matters of love, do not seek completeness outside yourself; rather, radiate the wholeness of your soul. "
                f"What is meant for you will recognize your frequency effortlessly."
            )
        elif any(w in msg_lower for w in ["career", "job", "money", "purpose", "business", "future", "destiny"]):
            return (
                f"The celestial currents around your vocation are undergoing powerful alchemy. "
                f"Your hand reveals a defined Fate Line, showing that you are an architect of your own timeline. "
                f"{drawn_cards_str} The universe asks you to step beyond hesitation and execute on your inner vision with disciplined confidence. "
                f"Focus on the next concrete milestone; abundance naturally follows sovereign mastery."
            )
        elif any(w in msg_lower for w in ["palm", "hand", "line", "mount", "heart line", "life line", "head line"]):
            return (
                f"Your palm is a living mandala of your subconscious mind and soul contracts. "
                f"As an elemental {hand_type} hand, your energy is both grounded and receptive. "
                f"Your Head Line's slope signifies creative intelligence, while your Life Line reflects deep regenerative vitality. "
                f"Remember: chiromancy is dynamic—as your consciousness expands, the micro-capillaries and lines in your palm actively evolve."
            )
        elif any(w in msg_lower for w in ["tarot", "card", "deck", "spread", "celtic cross"]):
            return (
                f"The 78 archetypes of the Tarot are mirrors of the cosmic psyche. "
                f"{drawn_cards_str} Every card drawn is not a fixed decree of fate, but a conscious invitation to align with higher spiritual law. "
                f"Look at the symbols with an open heart: what immediate feeling or memory arises when you gaze upon the imagery?"
            )
        elif any(w in msg_lower for w in ["spiritual", "meditation", "chakra", "energy", "intuition", "peace"]):
            return (
                f"Your intuitive antenna is especially sensitive in this chapter. "
                f"With your {zodiac} celestial energy, emotional stillness is your greatest sanctuary. "
                f"Take 10 minutes today to sit with a quiet mind, placing your hands over your heart and solar plexus. "
                f"Breathe in the golden prana of the universe, and allow your worries to dissolve into the cosmic sea."
            )
        else:
            return (
                f"Greetings, noble seeker. I hear the quiet inquiry of your soul. "
                f"Your current energetic matrix is pregnant with opportunity and transformation. "
                f"Trust the subtle whispers of your intuition over external noise. "
                f"Whether exploring the sacred topography of your palm or the archetypes of the tarot, "
                f"remember that you are the conscious weaver of your destiny. How may the oracle illuminate your path further?"
            )

    def _generate_suggested_questions(self, context: Optional[Dict[str, Any]] = None) -> List[str]:
        return [
            "What spiritual lessons are active for me right now?",
            "How can I align my palmistry insights with my daily career goals?",
            "What crystal and meditation ritual best balances my energetic blueprint?",
            "How do my drawn tarot cards interact with my zodiac sign?"
        ]

    def get_daily_guidance(self) -> Dict[str, Any]:
        today = datetime.date.today()
        # Daily deterministic seed based on date
        seed_val = today.year * 10000 + today.month * 100 + today.day
        rng = random.Random(seed_val)

        planetary_hours = [
            ("Hour of the Sun", "Sun", "Vitality, leadership, self-expression, clarity"),
            ("Hour of Venus", "Venus", "Love, beauty, harmony, artistic flow"),
            ("Hour of Mercury", "Mercury", "Communication, intellect, strategy, commerce"),
            ("Hour of the Moon", "Moon", "Intuition, dreams, emotional renewal, reflection"),
            ("Hour of Jupiter", "Jupiter", "Expansion, spiritual wisdom, abundance, luck"),
            ("Hour of Mars", "Mars", "Courage, decisive action, energy, boundaries")
        ]

        hour_info = rng.choice(planetary_hours)
        rune = rng.choice(self.RUNES)
        
        # Sample daily card
        from app.services.tarot_service import tarot_service
        all_cards = tarot_service.get_all_cards()
        daily_card = rng.choice(all_cards) if all_cards else {
            "name": "The Star",
            "arcana_type": "major",
            "keywords_upright": ["Hope", "Inspiration", "Serenity"],
            "description_upright": "A day of cosmic blessings, hope, and rejuvenation.",
            "advice": "Keep your vision focused on what elevates your spirit."
        }

        affirmations = [
            "Today, I move with grace, grounded in truth and elevated in spirit.",
            "I welcome divine synchronicity and trust my intuitive knowing.",
            "My energy is magnetic, radiant, and anchored in peace.",
            "I embrace all opportunities with a fearless, joyful heart."
        ]

        return {
            "date": today.strftime("%A, %B %d, %Y"),
            "planetary_hour": hour_info[0],
            "dominant_planet": hour_info[1],
            "rune_symbol": rune[1],
            "rune_name": rune[0],
            "rune_meaning": rune[2],
            "daily_card": daily_card,
            "cosmic_affirmation": rng.choice(affirmations),
            "meditation_focus": f"Meditate on {rune[0]} ({rune[1]}) and channel the radiant clarity of {hour_info[1]}.",
            "lucky_colors": rng.sample(["Midnight Indigo", "Solar Gold", "Emerald Velvet", "Amethyst Violet", "Rose Quartz Pink"], 2),
            "lucky_numbers": sorted(rng.sample(range(1, 33), 3))
        }

    async def _call_gemini_api(self, api_key: str, message: str, history: Optional[List[Dict[str, str]]], context: Optional[Dict[str, Any]]) -> str:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={api_key}"
        ctx_str = f"Context about the user: {context}\n" if context else ""
        prompt = f"{self.SYSTEM_PERSONA}\n\n{ctx_str}Seeker asks: {message}"
        
        payload = {
            "contents": [{"parts": [{"text": prompt}]}]
        }
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(url, json=payload)
            if resp.status_code == 200:
                data = resp.json()
                return data["candidates"][0]["content"]["parts"][0]["text"]
        raise Exception("Gemini API call failed")

    async def _call_openai_api(self, api_key: str, message: str, history: Optional[List[Dict[str, str]]], context: Optional[Dict[str, Any]]) -> str:
        url = "https://api.openai.com/v1/chat/completions"
        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        messages = [{"role": "system", "content": self.SYSTEM_PERSONA}]
        if context:
            messages.append({"role": "system", "content": f"User Context: {context}"})
        if history:
            for h in history[-4:]:
                messages.append({"role": h.get("role", "user"), "content": h.get("content", "")})
        messages.append({"role": "user", "content": message})
        
        payload = {
            "model": "gpt-4o-mini",
            "messages": messages,
            "temperature": 0.7,
            "max_tokens": 400
        }
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(url, headers=headers, json=payload)
            if resp.status_code == 200:
                data = resp.json()
                return data["choices"][0]["message"]["content"]
        raise Exception("OpenAI API call failed")

ai_oracle_service = AIOracleService()
