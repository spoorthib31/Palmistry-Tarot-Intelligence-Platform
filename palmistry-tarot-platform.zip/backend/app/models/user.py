import enum
from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from app.database import Base

class UserRole(str, enum.Enum):
    USER = "user"
    TAROT_READER = "tarot_reader"
    SPIRITUAL_CONSULTANT = "spiritual_consultant"
    ADMIN = "admin"

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    role = Column(String(50), default=UserRole.USER.value, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    profile = relationship("UserProfile", back_populates="user", uselist=False, cascade="all, delete-orphan")
    readings = relationship("Reading", back_populates="user", cascade="all, delete-orphan")
    notifications = relationship("Notification", back_populates="user", cascade="all, delete-orphan")

class UserProfile(Base):
    __tablename__ = "user_profiles"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    age_group = Column(String(50), default="25-34")
    interests = Column(JSON, default=lambda: ["Astrology", "Tarot", "Palmistry", "Mindfulness"])
    spiritual_goals = Column(JSON, default=lambda: ["Self-Discovery", "Career Clarity", "Inner Peace"])
    reading_preferences = Column(JSON, default=lambda: {"preferred_spread": "celtic_cross", "deck_theme": "rider_waite", "detailed_analysis": True})
    bio = Column(Text, default="Seeker of cosmic wisdom and self-discovery.")
    avatar_url = Column(String(512), default="")
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="profile")
