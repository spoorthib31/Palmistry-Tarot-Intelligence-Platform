from sqlalchemy import Column, Integer, String, Text, JSON
from app.database import Base

class TarotCard(Base):
    __tablename__ = "tarot_cards"

    id = Column(Integer, primary_key=True, index=True)
    card_id = Column(String(50), unique=True, index=True, nullable=False)
    name = Column(String(100), nullable=False)
    arcana_type = Column(String(20), nullable=False)  # "major" or "minor"
    suit = Column(String(20), nullable=True)          # "wands", "cups", "swords", "pentacles", None for major
    number = Column(Integer, nullable=False)
    image_url = Column(String(512), nullable=True)
    element = Column(String(50), nullable=True)       # Fire, Water, Air, Earth, Spirit
    astrology = Column(String(100), nullable=True)    # Planet / Zodiac correspondence
    keywords_upright = Column(JSON, default=list)
    keywords_reversed = Column(JSON, default=list)
    description_upright = Column(Text, nullable=False)
    description_reversed = Column(Text, nullable=False)
    advice = Column(Text, nullable=True)
    symbolism = Column(Text, nullable=True)
