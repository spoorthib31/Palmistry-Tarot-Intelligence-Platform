import enum
from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, JSON, Float
from sqlalchemy.orm import relationship
from app.database import Base

class ReadingType(str, enum.Enum):
    PALM = "palm"
    TAROT = "tarot"
    SYNTHESIZED_HOLISTIC = "synthesized_holistic"

class ReadingStatus(str, enum.Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    ARCHIVED = "archived"

class Reading(Base):
    __tablename__ = "readings"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    reading_type = Column(String(50), default=ReadingType.SYNTHESIZED_HOLISTIC.value, nullable=False)
    status = Column(String(50), default=ReadingStatus.COMPLETED.value)
    title = Column(String(255), default="Spiritual Synthesis Reading")
    
    # Palm Analysis specifics
    palm_image_url = Column(String(512), nullable=True)
    palm_features = Column(JSON, nullable=True)  # Line metrics, hand shape, finger ratios, mounts, landmarks
    
    # Tarot Reading specifics
    spread_name = Column(String(100), nullable=True)  # "celtic_cross", "three_card", "relationship", etc.
    drawn_cards = Column(JSON, nullable=True)  # List of cards with position, orientation, meaning
    
    # AI Interpretation & Insights across categories
    # Categories: Personality, Relationships, Career, Finance, Health & Wellness, Personal Growth, Life Opportunities
    ai_interpretation = Column(JSON, nullable=True)
    
    # Personality & Life Trend Intelligence
    personality_profile = Column(JSON, nullable=True)
    life_trends = Column(JSON, nullable=True)
    
    # Spiritual Guidance Scoring Engine Metrics
    insight_scores = Column(JSON, nullable=True)  # Weighted overall score + dimensional breakdown
    overall_score = Column(Float, default=0.0)
    
    # Actionable Recommendations
    recommendations = Column(JSON, nullable=True)
    
    # Reader & Consultant Collaboration Notes
    reader_notes = Column(Text, nullable=True)
    client_feedback = Column(Text, nullable=True)
    rating = Column(Integer, nullable=True)
    
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user = relationship("User", back_populates="readings")
