import enum
from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base

class NotificationType(str, enum.Enum):
    DAILY_GUIDANCE = "daily_guidance"
    READING_REMINDER = "reading_reminder"
    INSIGHT_UPDATE = "insight_update"
    SPIRITUAL_GROWTH_ALERT = "spiritual_growth_alert"
    PLATFORM_ANNOUNCEMENT = "platform_announcement"

class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    notification_type = Column(String(50), default=NotificationType.DAILY_GUIDANCE.value)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    user = relationship("User", back_populates="notifications")
