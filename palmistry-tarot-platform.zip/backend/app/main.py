import os
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.database import engine, Base, SessionLocal
from app.data.seed_data import seed_database
from app.routers import auth, palmistry, tarot, synthesis, oracle, readings

# Create DB tables
Base.metadata.create_all(bind=engine)

# Seed database with initial 78 tarot cards, demo seeker, and consultant accounts
db = SessionLocal()
try:
    seed_database(db)
finally:
    db.close()

app = FastAPI(
    title="Palmistry & Tarot Intelligence Platform API",
    description="AI-Powered Palmistry and Tarot Intelligence Platform for Personalized Spiritual Insights",
    version=settings.PROJECT_VERSION,
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Static Files for Uploads and PDF Reports
app.mount("/uploads", StaticFiles(directory=str(settings.UPLOAD_DIR)), name="uploads")
app.mount("/reports", StaticFiles(directory=str(settings.REPORTS_DIR)), name="reports")

# Include API Routers
app.include_router(auth.router, prefix=settings.API_V1_STR)
app.include_router(palmistry.router, prefix=settings.API_V1_STR)
app.include_router(tarot.router, prefix=settings.API_V1_STR)
app.include_router(synthesis.router, prefix=settings.API_V1_STR)
app.include_router(oracle.router, prefix=settings.API_V1_STR)
app.include_router(readings.router, prefix=settings.API_V1_STR)

@app.get("/")
def root():
    return {
        "platform": settings.PROJECT_NAME,
        "version": settings.PROJECT_VERSION,
        "status": "Cosmic Gateway Active",
        "documentation": "/docs"
    }

@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "database": "connected",
        "tarot_engine": "78_cards_loaded",
        "palm_vision": "ready",
        "oracle_ai": "active"
    }
