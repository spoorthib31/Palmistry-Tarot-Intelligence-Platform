from typing import Optional, List, Dict, Any
from pydantic import BaseModel

class OracleChatMessage(BaseModel):
    role: str  # "user" or "assistant" or "system"
    content: str
    timestamp: Optional[str] = None

class OracleChatRequest(BaseModel):
    message: str
    conversation_history: Optional[List[OracleChatMessage]] = []
    context: Optional[Dict[str, Any]] = None  # user's palm reading, tarot cards, zodiac, etc.
    custom_gemini_key: Optional[str] = None
    custom_openai_key: Optional[str] = None

class OracleChatResponse(BaseModel):
    reply: str
    suggested_questions: List[str]
    cosmic_mood: str
    audio_tts_url: Optional[str] = None

class DailyGuidanceResponse(BaseModel):
    date: str
    planetary_hour: str
    dominant_planet: str
    rune_symbol: str
    rune_name: str
    daily_card: Dict[str, Any]
    cosmic_affirmation: str
    meditation_focus: str
    lucky_colors: List[str]
    lucky_numbers: List[int]
