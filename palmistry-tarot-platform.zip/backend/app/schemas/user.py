from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, ConfigDict

class UserProfileBase(BaseModel):
    age_group: Optional[str] = "25-34"
    interests: Optional[List[str]] = ["Astrology", "Tarot", "Palmistry", "Mindfulness"]
    spiritual_goals: Optional[List[str]] = ["Self-Discovery", "Career Clarity", "Inner Peace"]
    reading_preferences: Optional[Dict[str, Any]] = {
        "preferred_spread": "celtic_cross",
        "deck_theme": "rider_waite",
        "detailed_analysis": True
    }
    bio: Optional[str] = "Seeker of cosmic wisdom and self-discovery."
    avatar_url: Optional[str] = ""

class UserProfileUpdate(UserProfileBase):
    pass

class UserProfileResponse(UserProfileBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int
    updated_at: Optional[datetime] = None

class UserBase(BaseModel):
    email: str
    full_name: str
    role: Optional[str] = "user"

class UserCreate(UserBase):
    password: str

class UserLogin(BaseModel):
    email: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: Dict[str, Any]

class UserResponse(UserBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    is_active: bool
    created_at: datetime
    profile: Optional[UserProfileResponse] = None
