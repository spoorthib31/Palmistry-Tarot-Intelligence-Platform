from typing import Optional, List, Dict, Any
from pydantic import BaseModel

class SpiritualSynthesisRequest(BaseModel):
    palm_reading_id: Optional[int] = None
    tarot_reading_id: Optional[int] = None
    palm_features: Optional[Dict[str, Any]] = None
    tarot_spread: Optional[Dict[str, Any]] = None
    user_birth_date: Optional[str] = "1998-07-15"
    zodiac_sign: Optional[str] = "Cancer"
    life_path_number: Optional[int] = 7
    spiritual_question: Optional[str] = "What is my spiritual destiny and how can I align my life path?"

class DimensionScore(BaseModel):
    name: str
    score: float  # 0 to 100
    category: str
    description: str
    status: str  # "Harmonious", "Ascending", "Requires Focus", "Transformational"

class SpiritualSynthesisResponse(BaseModel):
    reading_id: Optional[int] = None
    title: str
    seeker_name: str
    astrological_profile: Dict[str, Any]
    numerology_profile: Dict[str, Any]
    palm_synthesis: Dict[str, Any]
    tarot_synthesis: Dict[str, Any]
    unified_dossier: str
    dimension_scores: Dict[str, DimensionScore]
    overall_harmony_score: float
    life_category_guidance: Dict[str, Dict[str, Any]]
    personalized_rituals: List[Dict[str, str]]
    recommended_crystals: List[Dict[str, str]]
    affirmations: List[str]
    pdf_download_url: Optional[str] = None
