from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, ConfigDict

class ReadingNoteUpdate(BaseModel):
    reader_notes: Optional[str] = None
    client_feedback: Optional[str] = None
    rating: Optional[int] = None

class ReadingSummaryResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int
    reading_type: str
    status: str
    title: str
    overall_score: float
    created_at: datetime
    updated_at: Optional[datetime] = None

class ReadingDetailResponse(ReadingSummaryResponse):
    model_config = ConfigDict(from_attributes=True)
    palm_image_url: Optional[str] = None
    palm_features: Optional[Dict[str, Any]] = None
    spread_name: Optional[str] = None
    drawn_cards: Optional[List[Dict[str, Any]]] = None
    ai_interpretation: Optional[Dict[str, Any]] = None
    personality_profile: Optional[Dict[str, Any]] = None
    life_trends: Optional[Dict[str, Any]] = None
    insight_scores: Optional[Dict[str, Any]] = None
    recommendations: Optional[Dict[str, Any]] = None
    reader_notes: Optional[str] = None
    client_feedback: Optional[str] = None
    rating: Optional[int] = None
    user_name: Optional[str] = None
