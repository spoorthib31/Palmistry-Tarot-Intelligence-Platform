from typing import Optional, List, Dict, Any
from pydantic import BaseModel, ConfigDict

class TarotCardResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    card_id: str
    name: str
    arcana_type: str
    suit: Optional[str] = None
    number: int
    image_url: Optional[str] = None
    element: Optional[str] = None
    astrology: Optional[str] = None
    keywords_upright: List[str] = []
    keywords_reversed: List[str] = []
    description_upright: str
    description_reversed: str
    advice: Optional[str] = None
    symbolism: Optional[str] = None

class DrawnCard(BaseModel):
    card: TarotCardResponse
    position_index: int
    position_name: str
    position_meaning: str
    is_reversed: bool
    context_reading: str

class TarotSpreadRequest(BaseModel):
    spread_type: str = "three_card"
    question: Optional[str] = "What energies surround my spiritual journey today?"
    deck_theme: Optional[str] = "rider_waite"

class TarotSpreadResponse(BaseModel):
    spread_name: str
    question: str
    drawn_cards: List[DrawnCard]
    holistic_interpretation: str
    dominant_element: str
    energy_focus: str
    dimension_scores: Dict[str, float]
    actionable_advice: List[str]
