from typing import Optional, List, Dict, Any
from pydantic import BaseModel

class PalmLineMetric(BaseModel):
    name: str
    length: float
    depth: str  # "Deep", "Moderate", "Faint"
    curvature: str  # "Straight", "Gentle Curve", "Steep Arc"
    clarity_score: float  # 0.0 to 100.0
    start_point: List[int]
    end_point: List[int]
    interpretation: str
    key_traits: List[str]

class PalmFeatures(BaseModel):
    hand_type: str  # "Earth", "Air", "Fire", "Water"
    hand_type_desc: str
    palm_shape: str
    finger_ratios: Dict[str, float]
    lines: Dict[str, PalmLineMetric]
    mounts: Dict[str, Dict[str, Any]]
    special_marks: List[Dict[str, str]]
    dominant_element: str

class PalmAnalysisRequest(BaseModel):
    image_base64: Optional[str] = None
    hand_side: Optional[str] = "dominant_right"  # "left" or "right"
    notes: Optional[str] = None

class PalmAnalysisResponse(BaseModel):
    status: str
    message: str
    image_url: Optional[str] = None
    annotated_image_url: Optional[str] = None
    features: PalmFeatures
    personality_summary: str
    dimension_scores: Dict[str, float]
    category_insights: Dict[str, Dict[str, Any]]
