"""Palmistry & Tarot Intelligence Platform Backend Application Package."""
__version__ = "1.0.0"
