from fastapi import APIRouter, Depends, HTTPException, status
from typing import List, Optional
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User, UserRole
from app.models.reading import Reading
from app.schemas.reading import (
    ReadingSummaryResponse, ReadingDetailResponse, ReadingNoteUpdate
)
from app.services.auth_service import get_current_user

router = APIRouter(prefix="/readings", tags=["Reading History & Journal"])

@router.get("", response_model=List[ReadingSummaryResponse])
def get_user_readings(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Lists readings for the authenticated user, or all readings if consultant/admin."""
    if current_user.role in [UserRole.SPIRITUAL_CONSULTANT.value, UserRole.ADMIN.value]:
        readings = db.query(Reading).order_by(Reading.created_at.desc()).limit(100).all()
    else:
        readings = db.query(Reading).filter(Reading.user_id == current_user.id).order_by(Reading.created_at.desc()).all()
    return readings

@router.get("/{reading_id}", response_model=ReadingDetailResponse)
def get_reading_detail(
    reading_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieves full details of a specific reading."""
    reading = db.query(Reading).filter(Reading.id == reading_id).first()
    if not reading:
        raise HTTPException(status_code=404, detail="Reading record not found.")

    if current_user.role not in [UserRole.SPIRITUAL_CONSULTANT.value, UserRole.ADMIN.value] and reading.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to access this seeker's dossier.")

    user_name = reading.user.full_name if reading.user else "Anonymous Seeker"

    return {
        "id": reading.id,
        "user_id": reading.user_id,
        "reading_type": reading.reading_type,
        "status": reading.status,
        "title": reading.title,
        "overall_score": reading.overall_score or 0.0,
        "created_at": reading.created_at,
        "updated_at": reading.updated_at,
        "palm_image_url": reading.palm_image_url,
        "palm_features": reading.palm_features,
        "spread_name": reading.spread_name,
        "drawn_cards": reading.drawn_cards,
        "ai_interpretation": reading.ai_interpretation,
        "personality_profile": reading.personality_profile,
        "life_trends": reading.life_trends,
        "insight_scores": reading.insight_scores,
        "recommendations": reading.recommendations,
        "reader_notes": reading.reader_notes,
        "client_feedback": reading.client_feedback,
        "rating": reading.rating,
        "user_name": user_name
    }

@router.put("/{reading_id}/notes", response_model=ReadingDetailResponse)
def update_reading_notes(
    reading_id: int,
    payload: ReadingNoteUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Allows spiritual consultants or seekers to add notes, feedback, and ratings."""
    reading = db.query(Reading).filter(Reading.id == reading_id).first()
    if not reading:
        raise HTTPException(status_code=404, detail="Reading record not found.")

    if payload.reader_notes is not None:
        reading.reader_notes = payload.reader_notes
    if payload.client_feedback is not None:
        reading.client_feedback = payload.client_feedback
    if payload.rating is not None:
        reading.rating = payload.rating

    db.commit()
    db.refresh(reading)
    return get_reading_detail(reading_id, current_user, db)

@router.delete("/{reading_id}")
def delete_reading(
    reading_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    reading = db.query(Reading).filter(Reading.id == reading_id).first()
    if not reading:
        raise HTTPException(status_code=404, detail="Reading record not found.")

    if reading.user_id != current_user.id and current_user.role != UserRole.ADMIN.value:
        raise HTTPException(status_code=403, detail="Not authorized to delete this reading.")

    db.delete(reading)
    db.commit()
    return {"message": "Reading successfully dissolved into the cosmic ether."}
