from fastapi import APIRouter, Depends, Body
from typing import Dict, Any, Optional
from app.schemas.oracle import (
    OracleChatRequest, OracleChatResponse, DailyGuidanceResponse
)
from app.services.ai_oracle_service import ai_oracle_service
from app.services.tts_service import tts_service

router = APIRouter(prefix="/oracle", tags=["AI Oracle Chamber"])

@router.post("/chat", response_model=OracleChatResponse)
async def chat_with_oracle(request: OracleChatRequest):
    """
    Real-time conversational mystic advisor ("Aurelia") with reading context memory
    and optional text-to-speech audio prophecy generation.
    """
    res = await ai_oracle_service.generate_chat_response(
        message=request.message,
        conversation_history=[m.dict() for m in request.conversation_history] if request.conversation_history else None,
        context=request.context,
        custom_gemini_key=request.custom_gemini_key,
        custom_openai_key=request.custom_openai_key
    )

    # Generate optional TTS audio clip for the prophecy
    tts_url = tts_service.text_to_speech(res["reply"])
    res["audio_tts_url"] = tts_url

    return res

@router.get("/daily", response_model=DailyGuidanceResponse)
def get_daily_prophecy():
    """Returns today's planetary hour, active rune, daily tarot archetype, and affirmation."""
    return ai_oracle_service.get_daily_guidance()

@router.post("/tts")
def generate_custom_tts(payload: Dict[str, str] = Body(...)):
    text = payload.get("text", "May peace and wisdom illuminate your spiritual path.")
    audio_url = tts_service.text_to_speech(text)
    return {"audio_url": audio_url}
