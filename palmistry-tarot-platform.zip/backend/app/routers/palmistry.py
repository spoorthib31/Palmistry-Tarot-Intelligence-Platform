from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException
from typing import Optional
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User
from app.models.reading import Reading, ReadingType, ReadingStatus
from app.schemas.palm import PalmAnalysisRequest, PalmAnalysisResponse
from app.services.palm_vision_service import palm_vision_service
from app.services.auth_service import get_current_user_optional

router = APIRouter(prefix="/palm", tags=["Palmistry AI"])

@router.post("/analyze", response_model=PalmAnalysisResponse)
async def analyze_palm(
    file: Optional[UploadFile] = File(None),
    image_base64: Optional[str] = Form(None),
    hand_side: str = Form("dominant_right"),
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    Accepts either an uploaded image file or a base64 webcam frame,
    performs computer vision line and mount analysis, and saves the reading.
    """
    if file:
        contents = await file.read()
        res = palm_vision_service.analyze_palm_image(contents, hand_side)
    elif image_base64:
        res = palm_vision_service.analyze_palm_image(image_base64, hand_side)
    else:
        # Fallback to rich sample analysis
        res = palm_vision_service.generate_sample_palm_analysis()

    # Save to database if user is logged in
    if current_user:
        reading = Reading(
            user_id=current_user.id,
            reading_type=ReadingType.PALM.value,
            status=ReadingStatus.COMPLETED.value,
            title=f"Palmistry Analysis ({res['features']['hand_type']} Hand)",
            palm_image_url=res.get("annotated_image_url"),
            palm_features=res["features"],
            ai_interpretation=res["category_insights"],
            personality_profile={"summary": res["personality_summary"]},
            insight_scores=res["dimension_scores"],
            overall_score=sum(res["dimension_scores"].values()) / len(res["dimension_scores"]),
            recommendations={"strengths": res["category_insights"]["personality"]["strengths"]}
        )
        db.add(reading)
        db.commit()

    return res

@router.get("/sample", response_model=PalmAnalysisResponse)
def get_sample_palm():
    """Generates an instant sample palm analysis for previewing features."""
    return palm_vision_service.generate_sample_palm_analysis()
