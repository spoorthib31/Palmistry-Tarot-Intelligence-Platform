from fastapi import APIRouter, Depends, HTTPException
from typing import List, Optional
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User
from app.models.reading import Reading, ReadingType, ReadingStatus
from app.schemas.tarot import TarotCardResponse, TarotSpreadRequest, TarotSpreadResponse
from app.services.tarot_service import tarot_service
from app.services.auth_service import get_current_user_optional

router = APIRouter(prefix="/tarot", tags=["Tarot Sanctuary"])

@router.get("/cards", response_model=List[TarotCardResponse])
def get_all_tarot_cards(db: Session = Depends(get_db)):
    """Returns the complete 78-card Rider-Waite-Smith tarot deck."""
    return tarot_service.get_all_cards(db)

@router.get("/cards/{card_id}", response_model=TarotCardResponse)
def get_tarot_card(card_id: str, db: Session = Depends(get_db)):
    card = tarot_service.get_card_by_id(card_id, db)
    if not card:
        raise HTTPException(status_code=404, detail="Tarot card not found in the cosmic archives.")
    return card

@router.post("/spread", response_model=TarotSpreadResponse)
def generate_spread(
    request: TarotSpreadRequest,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """Draws a multi-card tarot spread, synthesizes archetypes, and saves reading if authenticated."""
    result = tarot_service.draw_spread(
        spread_type=request.spread_type,
        question=request.question,
        db=db
    )

    if current_user:
        reading = Reading(
            user_id=current_user.id,
            reading_type=ReadingType.TAROT.value,
            status=ReadingStatus.COMPLETED.value,
            title=f"Tarot Spread: {result['spread_name']}",
            spread_name=request.spread_type,
            drawn_cards=result["drawn_cards"],
            ai_interpretation={"holistic": result["holistic_interpretation"]},
            insight_scores=result["dimension_scores"],
            overall_score=sum(result["dimension_scores"].values()) / len(result["dimension_scores"]),
            recommendations={"actionable_advice": result["actionable_advice"]}
        )
        db.add(reading)
        db.commit()

    return result
