from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from typing import Optional
from sqlalchemy.orm import Session
from pathlib import Path

from app.database import get_db
from app.models.user import User
from app.models.reading import Reading, ReadingType, ReadingStatus
from app.schemas.synthesis import SpiritualSynthesisRequest, SpiritualSynthesisResponse
from app.services.scoring_engine import scoring_engine
from app.services.palm_vision_service import palm_vision_service
from app.services.tarot_service import tarot_service
from app.services.pdf_report_service import pdf_report_service
from app.services.auth_service import get_current_user_optional
from app.config import settings

router = APIRouter(prefix="/synthesis", tags=["Spiritual Synthesis & Blueprint"])

@router.post("/generate", response_model=SpiritualSynthesisResponse)
def generate_synthesis(
    request: SpiritualSynthesisRequest,
    current_user: Optional[User] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    Synthesizes Palmistry features + Tarot spread + Astrological Zodiac + Numerology Life Path
    into a comprehensive 7-dimensional Spiritual Blueprint and saves it.
    """
    seeker_name = current_user.full_name if current_user else "Seeker"
    
    # 1. Fetch or prepare Palm features
    palm_data = request.palm_features
    if not palm_data and request.palm_reading_id and db:
        reading = db.query(Reading).filter(Reading.id == request.palm_reading_id).first()
        if reading and reading.palm_features:
            palm_data = reading.palm_features
    if not palm_data:
        palm_sample = palm_vision_service.generate_sample_palm_analysis()
        palm_data = palm_sample["features"]

    # 2. Fetch or prepare Tarot spread
    tarot_data = request.tarot_spread
    if not tarot_data and request.tarot_reading_id and db:
        reading = db.query(Reading).filter(Reading.id == request.tarot_reading_id).first()
        if reading and reading.drawn_cards:
            tarot_data = {
                "spread_name": reading.spread_name or "Trinity Spread",
                "drawn_cards": reading.drawn_cards,
                "holistic_interpretation": reading.ai_interpretation.get("holistic", "") if reading.ai_interpretation else ""
            }
    if not tarot_data:
        tarot_data = tarot_service.draw_spread("three_card", db=db)

    # 3. Astrological & Numerological profiles
    zodiac = request.zodiac_sign or "Scorpio"
    life_path = request.life_path_number or 7
    
    zodiac_profiles = {
        "Aries": {"element": "Fire", "ruler": "Mars", "motto": "I Am", "archetype": "The Pioneer"},
        "Taurus": {"element": "Earth", "ruler": "Venus", "motto": "I Have", "archetype": "The Anchor"},
        "Gemini": {"element": "Air", "ruler": "Mercury", "motto": "I Think", "archetype": "The Messenger"},
        "Cancer": {"element": "Water", "ruler": "Moon", "motto": "I Feel", "archetype": "The Nurturer"},
        "Leo": {"element": "Fire", "ruler": "Sun", "motto": "I Will", "archetype": "The Sovereign"},
        "Virgo": {"element": "Earth", "ruler": "Mercury", "motto": "I Analyze", "archetype": "The Alchemist"},
        "Libra": {"element": "Air", "ruler": "Venus", "motto": "I Balance", "archetype": "The Harmonizer"},
        "Scorpio": {"element": "Water", "ruler": "Pluto / Mars", "motto": "I Transform", "archetype": "The Mystic Phoenix"},
        "Sagittarius": {"element": "Fire", "ruler": "Jupiter", "motto": "I Seek", "archetype": "The Philosopher"},
        "Capricorn": {"element": "Earth", "ruler": "Saturn", "motto": "I Build", "archetype": "The Master Architect"},
        "Aquarius": {"element": "Air", "ruler": "Uranus", "motto": "I Know", "archetype": "The Visionary Rebel"},
        "Pisces": {"element": "Water", "ruler": "Neptune", "motto": "I Believe", "archetype": "The Cosmic Dreamer"}
    }
    z_info = zodiac_profiles.get(zodiac, zodiac_profiles["Scorpio"])
    
    astro_profile = {
        "zodiac_sign": zodiac,
        "element": z_info["element"],
        "ruling_planet": z_info["ruler"],
        "cosmic_motto": z_info["motto"],
        "archetype": z_info["archetype"],
        "summary": f"Your {zodiac} solar placement bestows the archetype of {z_info['archetype']}, driven by {z_info['element']} energy and guided by {z_info['ruler']}."
    }

    numerology_profile = {
        "life_path_number": life_path,
        "title": f"Life Path {life_path}: The Sacred Seeker & Truth Bearer" if life_path == 7 else f"Life Path {life_path}: Sovereign Creator",
        "core_lesson": "Bridging empirical discernment with esoteric intuition to illuminate wisdom for others."
    }

    # 4. Compute 7-Dimensional Synthesis
    synthesis_result = scoring_engine.compute_holistic_synthesis(
        palm_features=palm_data,
        tarot_spread=tarot_data,
        zodiac_sign=zodiac,
        life_path_number=life_path
    )

    unified_dossier = (
        f"Beloved Seeker, your spiritual blueprint reflects an authentic convergence between the physical chiromancy "
        f"of your {palm_data.get('hand_type', 'Earth')} hand and the archetypal vibration of your active tarot spread. "
        f"Your {zodiac} astrological core infuses your {synthesis_result['top_strength']['name']} with radiant potency. "
        f"By leaning into your prescribed rituals, you elevate your overall spiritual harmony to sovereign mastery."
    )

    full_payload = {
        "title": "Comprehensive Spiritual Blueprint & Cosmic Dossier",
        "seeker_name": seeker_name,
        "astrological_profile": astro_profile,
        "numerology_profile": numerology_profile,
        "palm_synthesis": {
            "hand_type": palm_data.get("hand_type", "Earth"),
            "hand_type_desc": palm_data.get("hand_type_desc", ""),
            "lines": palm_data.get("lines", {})
        },
        "tarot_synthesis": {
            "spread_name": tarot_data.get("spread_name", "Trinity Spread"),
            "holistic_interpretation": tarot_data.get("holistic_interpretation", ""),
            "drawn_cards": tarot_data.get("drawn_cards", [])
        },
        "unified_dossier": unified_dossier,
        "dimension_scores": synthesis_result["dimension_scores"],
        "overall_harmony_score": synthesis_result["overall_harmony_score"],
        "life_category_guidance": {
            "top_strength": synthesis_result["top_strength"],
            "growth_focus": synthesis_result["growth_focus"]
        },
        "personalized_rituals": synthesis_result["personalized_rituals"],
        "recommended_crystals": synthesis_result["recommended_crystals"],
        "affirmations": synthesis_result["affirmations"]
    }

    # Generate PDF Dossier
    pdf_url = pdf_report_service.generate_spiritual_dossier_pdf(full_payload)
    full_payload["pdf_download_url"] = pdf_url

    # Save reading if user is logged in
    if current_user and db:
        reading = Reading(
            user_id=current_user.id,
            reading_type=ReadingType.SYNTHESIZED_HOLISTIC.value,
            status=ReadingStatus.COMPLETED.value,
            title="Holistic Spiritual Blueprint",
            palm_features=palm_data,
            spread_name=tarot_data.get("spread_name"),
            drawn_cards=tarot_data.get("drawn_cards"),
            ai_interpretation={"dossier": unified_dossier, "pdf_url": pdf_url},
            personality_profile=astro_profile,
            life_trends={"numerology": numerology_profile},
            insight_scores=synthesis_result["dimension_scores"],
            overall_score=synthesis_result["overall_harmony_score"],
            recommendations={
                "rituals": synthesis_result["personalized_rituals"],
                "crystals": synthesis_result["recommended_crystals"],
                "affirmations": synthesis_result["affirmations"]
            }
        )
        db.add(reading)
        db.commit()
        full_payload["reading_id"] = reading.id

    return full_payload

@router.get("/pdf/{reading_id}")
def download_reading_pdf(reading_id: int, db: Session = Depends(get_db)):
    reading = db.query(Reading).filter(Reading.id == reading_id).first()
    if not reading:
        raise HTTPException(status_code=404, detail="Reading record not found.")

    pdf_url = reading.ai_interpretation.get("pdf_url") if reading.ai_interpretation else None
    if not pdf_url:
        raise HTTPException(status_code=404, detail="PDF report not yet compiled for this reading.")

    filename = Path(pdf_url).name
    filepath = settings.REPORTS_DIR / filename
    if not filepath.exists():
        raise HTTPException(status_code=404, detail="PDF report file is missing from archive.")

    return FileResponse(str(filepath), media_type="application/pdf", filename=f"Spiritual_Dossier_{reading_id}.pdf")
