from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.user import User, UserProfile, UserRole
from app.schemas.user import (
    UserCreate, UserLogin, UserResponse, TokenResponse, UserProfileUpdate, UserProfileResponse
)
from app.services.auth_service import (
    verify_password, get_password_hash, create_access_token, get_current_user
)

router = APIRouter(prefix="/auth", tags=["Authentication & Profile"])

@router.post("/register", response_model=TokenResponse)
def register(user_in: UserCreate, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.email == user_in.email.lower()).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A seeker with this cosmic email is already registered."
        )

    user = User(
        email=user_in.email.lower(),
        hashed_password=get_password_hash(user_in.password),
        full_name=user_in.full_name,
        role=user_in.role or UserRole.USER.value,
        is_active=True
    )
    db.add(user)
    db.flush()

    profile = UserProfile(
        user_id=user.id,
        age_group="25-34",
        interests=["Tarot", "Palmistry", "Astrology", "Meditation"],
        spiritual_goals=["Deepen Self-Awareness", "Align with Higher Purpose"],
        reading_preferences={"preferred_spread": "celtic_cross", "deck_theme": "rider_waite"},
        bio="Seeker of inner light and ancient esoteric wisdom."
    )
    db.add(profile)
    db.commit()
    db.refresh(user)

    token = create_access_token({"sub": str(user.id), "email": user.email, "role": user.role})
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "role": user.role,
            "profile": {
                "age_group": profile.age_group,
                "interests": profile.interests,
                "spiritual_goals": profile.spiritual_goals,
                "reading_preferences": profile.reading_preferences,
                "bio": profile.bio,
                "avatar_url": profile.avatar_url
            }
        }
    }

@router.post("/login", response_model=TokenResponse)
def login(user_in: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == user_in.email.lower()).first()
    if not user or not verify_password(user_in.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid celestial credentials."
        )

    token = create_access_token({"sub": str(user.id), "email": user.email, "role": user.role})
    
    profile_data = {}
    if user.profile:
        profile_data = {
            "age_group": user.profile.age_group,
            "interests": user.profile.interests,
            "spiritual_goals": user.profile.spiritual_goals,
            "reading_preferences": user.profile.reading_preferences,
            "bio": user.profile.bio,
            "avatar_url": user.profile.avatar_url
        }

    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "role": user.role,
            "profile": profile_data
        }
    }

@router.get("/me")
def get_me(current_user: User = Depends(get_current_user)):
    profile_data = {}
    if current_user.profile:
        profile_data = {
            "age_group": current_user.profile.age_group,
            "interests": current_user.profile.interests,
            "spiritual_goals": current_user.profile.spiritual_goals,
            "reading_preferences": current_user.profile.reading_preferences,
            "bio": current_user.profile.bio,
            "avatar_url": current_user.profile.avatar_url
        }
    return {
        "id": current_user.id,
        "email": current_user.email,
        "full_name": current_user.full_name,
        "role": current_user.role,
        "is_active": current_user.is_active,
        "profile": profile_data
    }

@router.put("/profile", response_model=UserProfileResponse)
def update_profile(
    profile_in: UserProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    profile = current_user.profile
    if not profile:
        profile = UserProfile(user_id=current_user.id)
        db.add(profile)

    update_data = profile_in.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(profile, field, value)

    db.commit()
    db.refresh(profile)
    return profile
