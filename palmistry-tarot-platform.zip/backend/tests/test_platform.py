import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.database import Base, engine, SessionLocal
from app.data.seed_data import seed_database

client = TestClient(app)

@pytest.fixture(scope="session", autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    seed_database(db)
    db.close()

def test_health_check():
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["tarot_engine"] == "78_cards_loaded"

def test_auth_login_seeker():
    response = client.post("/api/auth/login", json={
        "email": "seeker@spiritual.ai",
        "password": "seeker123"
    })
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["user"]["email"] == "seeker@spiritual.ai"

def test_tarot_cards_catalog():
    response = client.get("/api/tarot/cards")
    assert response.status_code == 200
    cards = response.json()
    assert len(cards) == 78

def test_tarot_spread_draw():
    response = client.post("/api/tarot/spread", json={
        "spread_type": "three_card",
        "question": "What guidance is present for my spiritual growth?"
    })
    assert response.status_code == 200
    data = response.json()
    assert len(data["drawn_cards"]) == 3
    assert "dimension_scores" in data
    assert "dominant_element" in data

def test_palm_sample_analysis():
    response = client.get("/api/palm/sample")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"
    assert "features" in data
    assert "lines" in data["features"]
    assert "heart_line" in data["features"]["lines"]
    assert "head_line" in data["features"]["lines"]
    assert "life_line" in data["features"]["lines"]

def test_spiritual_synthesis_generate():
    response = client.post("/api/synthesis/generate", json={
        "zodiac_sign": "Scorpio",
        "life_path_number": 7,
        "spiritual_question": "How can I align my higher destiny?"
    })
    assert response.status_code == 200
    data = response.json()
    assert "dimension_scores" in data
    assert "overall_harmony_score" in data
    assert "personalized_rituals" in data
    assert "pdf_download_url" in data

def test_oracle_daily_prophecy():
    response = client.get("/api/oracle/daily")
    assert response.status_code == 200
    data = response.json()
    assert "planetary_hour" in data
    assert "rune_symbol" in data
    assert "daily_card" in data

def test_oracle_chat():
    response = client.post("/api/oracle/chat", json={
        "message": "What is the spiritual meaning of my heart line curve?"
    })
    assert response.status_code == 200
    data = response.json()
    assert "reply" in data
    assert len(data["reply"]) > 20
    assert "suggested_questions" in data
