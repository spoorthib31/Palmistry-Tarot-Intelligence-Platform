# ✨ AI-Powered Palmistry and Tarot Intelligence Platform for Personalized Spiritual Insights

> An enterprise-grade, multi-modal spiritual intelligence platform harmonizing ancient Hermetic chiromancy, the 78-card sacred Tarot oracle, Western astrology, and Pythagorean numerology with modern computer vision and symbolic neural intelligence.

---

## 🌌 Platform Overview & Architecture

```
                                  MYSTIC INTELLIGENCE PLATFORM
                                 ==============================

   [ ✋ PalmScan AI ]            [ 🔮 Tarot Sanctuary ]          [ 📜 Cosmic Blueprint ]
   • Webcam / Photo Vision        • Full 78-Card Rider-Waite      • 7-Dimension Score Matrix
   • Line Contour Detection       • Upright/Reversed Dynamics     • Holistic Soul Synthesis
   • Heart, Head, Life & Fate     • Celtic Cross & Trinity        • Downloadable PDF Dossier
   • Mounts & Hand Typology       • AI Spread Interpretation      • Prescribed Daily Rituals
             │                                │                               │
             └────────────────────────────────┼───────────────────────────────┘
                                              ▼
                             ┌──────────────────────────────────┐
                             │    AI Mystic Advisor: Aurelia    │
                             │  • Conversational Spiritual AI   │
                             │  • Context-Aware Reading Memory  │
                             │  • Text-to-Speech Prophecy Audio │
                             │  • 432Hz Ambient Soundscape      │
                             └──────────────────────────────────┘
```

---

## 🔮 Key Features

1. **AI-Powered Palmistry Intelligence (PalmScan AI)**
   - **Live Webcam Alignment & Image Upload**: Point your hand at the camera or upload a photo.
   - **Computer Vision Extraction**: Detects the 4 major lines (*Heart Line*, *Head Line*, *Life Line*, *Fate Line*, and *Sun Line*) with clarity scores, curvature analysis, and depth.
   - **Sacred Mounts & Elemental Hand Typology**: Analyzes Mounts of Venus, Jupiter, Saturn, Apollo, Mercury, and Luna, identifying Earth, Air, Fire, or Water hand typology.
   - **Glowing Topography Overlay**: Visual feedback canvas with toggleable neon line paths.

2. **Interactive 3D Tarot Sanctuary**
   - **Full 78-Card Esoteric Encyclopedia**: 22 Major Arcana + 56 Minor Arcana (Wands, Cups, Swords, Pentacles).
   - **Multiple Interactive Spreads**:
     - *Single Card Oracle* (Daily spark)
     - *Trinity Spread* (Past • Present • Future)
     - *Mind • Body • Spirit Alignment*
     - *Soul Connection Alchemy* (5-Card Love & Relationship spread)
     - *Career & Sovereign Destiny Spread* (5-Card Vocation spread)
     - *Sacred Celtic Cross* (10-Card Comprehensive Life Reading)
   - **3D Interactive Card Physics**: Tap to flip, upright/reversed mechanics, and deep esoteric lore modals.

3. **Multi-Modal Spiritual Synthesis & Cosmic Blueprint**
   - Blends Palmistry + Tarot + Astrological Zodiac + Numerology Life Path.
   - **7-Dimension Guidance Scoring Matrix**:
     1. Vitality & Somatic Prana
     2. Mental Clarity & Strategic Insight
     3. Emotional Depth & Relational Harmony
     4. Career Destiny & Sovereign Ambition
     5. Spiritual Connection & Higher Intuition
     6. Financial Flow & Material Abundance
     7. Creative Radiance & Magnetism
   - **Downloadable Mystical PDF Dossier**: Formatted report generated via ReportLab.
   - **Prescribed Rituals & Crystal Remedies**: Tailored daily habits and crystal allies.

4. **Conversational AI Mystic Chamber ("Aurelia")**
   - Context-aware oracle with memory of your active palm reading, tarot spreads, and astrological signs.
   - **Text-to-Speech (TTS) Prophecy Voice**: Spoken prophecies generated via gTTS.
   - **432Hz Harmonic Engine**: Synthesizes continuous 432Hz/528Hz cosmic crystal drone audio in real-time via Web Audio API.

5. **Spiritual Journal & Consultant Workspace**
   - **Seeker Diary**: Review past readings, score evolution, and ratings.
   - **Consultant Studio**: Specialized dashboard for professional Tarot Readers & Spiritual Consultants to review client dossiers and publish expert annotations.

---

## 🚀 Quick Start (Running in VS Code)

### Option A: One-Click Startup Script (Recommended)

Simply double-click or run:
```bash
run.bat
```
*(On macOS/Linux, run `./run.sh` or `pwsh ./run.ps1`)*

This script automatically verifies all dependencies, launches the FastAPI backend and Vite frontend in parallel, and opens your default browser at `http://localhost:5173`.

---

### Option B: Running from VS Code Run & Debug

1. Open this project folder in **VS Code**:
   ```bash
   code .
   ```
2. Press `Ctrl+Shift+D` (or click **Run and Debug** on the sidebar).
3. Select **"🌟 Full Stack: Palmistry & Tarot Platform"** from the dropdown.
4. Press `F5` to start both Backend and Frontend with integrated debugging.

---

### Option C: Manual Terminal Execution

#### 1. Backend Service (FastAPI)
```bash
cd backend
pip install -r requirements.txt
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```
*Backend runs on `http://127.0.0.1:8000` (Interactive Swagger docs at `http://127.0.0.1:8000/docs`)*

#### 2. Frontend Application (React + Vite)
```bash
cd frontend
npm install
npm run dev
```
*Frontend runs on `http://localhost:5173`*

---

## 🔑 Pre-Seeded Demo Accounts

You can log in instantly using the **1-Click Demo Buttons** inside the portal modal, or use these credentials:

| Role | Email | Password | Access / Capabilities |
| :--- | :--- | :--- | :--- |
| **Seeker (Client)** | `seeker@spiritual.ai` | `seeker123` | Personal palm scans, tarot draws, synthesis dossier, journal |
| **Spiritual Consultant** | `oracle@spiritual.ai` | `oracle123` | Seeker client queue, consultant review notes, ratings |

---

## 🧪 Automated Testing

Run the comprehensive pytest suite:
```bash
cd backend
python -m pytest tests/test_platform.py -v
```

All 8 automated tests verify:
- Backend Health & Diagnostics
- Seeker & Consultant Authentication
- 78 Tarot Cards Catalog & Spread Calculations
- Computer Vision Palmistry Line & Mount Extraction
- Spiritual Blueprint Synthesis & PDF Report Generation
- Daily Rune & Planetary Hour Guidance
- AI Oracle Conversational Engine

---

## 🛠️ Technology Stack

- **Backend**: Python 3.10+, FastAPI, SQLAlchemy 2.0, SQLite, Pydantic v2, Pillow, NumPy, ReportLab, gTTS, Pytest.
- **Frontend**: React 18, Vite, TypeScript, Tailwind CSS, Lucide React, HTML5 Canvas, Web Audio API.
- **AI Engine**: Hybrid symbolic esoteric knowledge graph + Computer Vision contour analysis + optional Gemini/OpenAI API plug-in.

---

*“As above, so below; as within, so without.” — The Emerald Tablet*
